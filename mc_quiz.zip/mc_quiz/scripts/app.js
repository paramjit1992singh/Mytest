var questionLoad;
var questionIndex;
var index = 0;
var instruction = ["Click on a Checkbox."];
var clickButton = ["Check Answer"];
var app = angular.module('myApp', []);

app.controller('myCtrl', function ($scope) {
    $scope.loadQuestion = function (index) {
        $scope.imageSrc = "images/" + questionLoad.quizQuestions[index].imageName;
        console.log($scope.imageSrc);
        $scope.instructionText = instruction[0];
        $scope.questionText = questionLoad.quizQuestions[index].question;
        $scope.option1 = questionLoad.quizQuestions[index].options[0];
        $scope.option2 = questionLoad.quizQuestions[index].options[1];
        $scope.option3 = questionLoad.quizQuestions[index].options[2];
        $scope.option4 = questionLoad.quizQuestions[index].options[3];
        $scope.clickButton = clickButton[0];
    };

    $.ajax({
        url: 'data/data.json',
        dataType: 'json',
        async: false,
        success: function (data) {
            questionLoad = data;
            console.log(questionLoad);
            $scope.loadQuestion(0);
        }
    });



});


$(document).ready(function () {

});