$(document).ready(function () {
    var $el;
    var html;
    var txt;
    var txtLen;
    var timeOut;
    var char = 0;

    $(document).on('keydown', function () {
        $("body").addClass('using-key');
    });

    $(document).on('mousedown', function () {
        $("body").removeClass('using-key');
    });

    $('.mag').on('keypress', function (e) {
        if (e.which == 13) {
            $(this).click();
        }
    });

    $('.mag').on('click', function () {
        if ($(this).hasClass("glass1")) {
            $el = $('#map-1 .typing');
            html = $.trim($(".mag1Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay1");
        }
        if ($(this).hasClass("glass2")) {
            $el = $('#map-2 .typing');
            html = $.trim($(".mag2Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay2");
        }
        if ($(this).hasClass("glass3")) {
            $el = $('#map-3 .typing');
            html = $.trim($(".mag3Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay3");
        }
        if ($(this).hasClass("glass4")) {
            $el = $('#map-4 .typing');
            html = $.trim($(".mag4Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay4");
        }
        if ($(this).hasClass("glass5")) {
            $el = $('#map-5 .typing');
            html = $.trim($(".mag5Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay5");
        }
        if ($(this).hasClass("glass6")) {
            $el = $('#map-6 .typing');
            html = $.trim($(".mag6Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay6");
        }
        if ($(this).hasClass("glass7")) {
            $el = $('#map-7 .typing');
            html = $.trim($(".mag7Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay7");
        }
        if ($(this).hasClass("glass8")) {
            $el = $('#map-8 .typing');
            html = $.trim($(".mag8Text").html());
            $(".overlay").removeClass("overlay1");
            $(".overlay").removeClass("overlay2");
            $(".overlay").removeClass("overlay3");
            $(".overlay").removeClass("overlay4");
            $(".overlay").removeClass("overlay5");
            $(".overlay").removeClass("overlay6");
            $(".overlay").removeClass("overlay7");
            $(".overlay").removeClass("overlay8");
            $(".overlay").addClass("overlay8");
        }

        $(".mag").hide();
        $(".overlay").show();
        $(".map-title, .map-desc, .v-line, .h-line").hide();
        $('#' + $(this).data('map-id')).show(500);


        txtLen = html.length;
        timeOut;
        char = 0;
        $el.text('|');
        typeIt();
    });

    $(document).on('keydown', function (event) {
        if (event.key == "Escape") {
            $(".overlay").click();
        }
    });

    $(".overlay").on("click", function () {
        $(".mag").show();
        $(".universal_map").fadeOut('fast');
        $(".overlay").hide();
        $(".map-title, .map-desc, .v-line, .h-line").show();
        clearTimeout(timeOut);

    });

    $(".universal_map").on("click", function () {
        $(this).fadeOut();
        $(".mag").show();
        $(".overlay").hide();
        $(".map-title, .map-desc, .v-line, .h-line").show();
        clearTimeout(timeOut);


    });

    function typeIt() {
        var humanize = Math.round(Math.random() * (100 - 50)) + 50;
        timeOut = setTimeout(function () {
            char++;
            var type = html.substring(0, char);
            //console.log(type);
            $el.html(type + '|');
            typeIt();

            if (char == txtLen) {
                $el.html($el.html().slice(0, -1)); // remove the '|'
                clearTimeout(timeOut);
            }

        }, humanize);
    }


//    var originalWidth = $(window).width();
//    var originalWidthTime = new Date();
//    $(window).resize(function (e) {
//        var newTime = new Date();
//        /*if (newTime - originalWidthTime < 100)
//         return;*/
//        var newWidth = $(window).width();
//        var percentageChange = 100 - (newWidth / originalWidth) * 100;
//        var scaleVal = (percentageChange / 100) * 1;
//        console.log("percentageChange: " + percentageChange);
//        console.log("scaleVal", scaleVal);
//        if (newWidth < 1000) {
//            $('.zoomContainer').css({backgroundSize: (100 + percentageChange * 1.5) + "%" + ' ' + 100 + "%"});
//        } else {
//            $('.zoomContainer').css({backgroundSize: 100 + percentageChange + "%" + ' ' + 100 + "%"});
//        }
//    }).resize();

});


//
//document.onreadystatechange = function () {
//    var state = document.readyState
//    if (state == 'interactive') {
//        document.getElementById('container').style.visibility = "hidden";
//    } else if (state == 'complete') {
//        setTimeout(function () {
//            document.getElementById('interactive');
//            document.getElementById('load').style.visibility = "hidden";
//            document.getElementById('container').style.visibility = "visible";
//        }, 1150);
//    }
//}

$(document).ready(function () {
    //if ($(window).width() > 1024) {
        $(".map-wrapper").mousemove(function (event) {
            var pageCoords = "( " + event.pageX + ", " + event.pageY + " )";
            $(".h-line").css('top', event.pageY + 'px');
            $(".v-line").css('left', event.pageX + 'px');

        });
    //}
});