var totalBlocks = 10;
var interval = 20;
var noOfValuesThatCanBeShownOnScale = 4;
var noOfBlocksInBlueGreenContainer = 3;
var answerArray = [];
var attempt = 0;
var blocksInTheBeaker = [], blocksInBlueContainer = [], blocksInGreenContainer = [];
var nextButtonClick = 0;
var messages = ["Place the labels in the correct positions on the scale.",
    "Click the 'Check' button to find out if you have positioned the labels correctly.",
    "Well done! You have placed all the labels correctly. Click 'Next'.",
    "Some of the labels are not in the right places. Look again and talk about where to put them.",
    "None of the labels are in the right places. Look again and talk about where to put them.",
    "Some of the labels are still not in the right places. The ones that are correct have been ticked. Look again and talk about where to move the rest of the labels.",
    "Some of your labels are still not in the right places. The ones that are correct have been ticked. Click 'Next' to see the correct answer.",
    "None of the labels are in the right places. Click 'Next' to see the correct answer.",
    "How much water is in the container? Click on the correct volume.",
    "How much water is in the container?",
    "Click the 'Check' button to see if your answer is right."
];
$(document).ready(function () {
//    //test
//    nextButtonClick++;
//    nextProblem();
//
//    //test

    var totalValuesArray = [];

    //alert(messages[0]);

    for (var i = 1; i <= totalBlocks; i++) {
        totalValuesArray.push(interval * i);
    }

    //console.log("totalValuesArray: " + totalValuesArray);

    do {
        blocksInTheBeaker[blocksInTheBeaker.length] = totalValuesArray.splice(Math.floor(Math.random() * totalValuesArray.length), 1)[0];
    } while (blocksInTheBeaker.length < noOfValuesThatCanBeShownOnScale);

    blocksInTheBeaker.sort(function (a, b) {
        return parseInt(a) - parseInt(b);
    });

//    console.log("blocksInTheBeaker: " + blocksInTheBeaker);
//    console.log("totalValuesArray: " + totalValuesArray);


    for (var i = totalBlocks; i > 0; i--) {
        if ($.inArray((i * interval), blocksInTheBeaker) !== -1) {
            $(".beaker").append('<div class="normalBlock">' + (i * interval) + '</div>');
        } else {
            $(".beaker").append('<div class="droppable" dropTarget="' + (i) + '"></div>');
        }
    }

//    console.log("totalValuesArray: " + totalValuesArray);
//    console.log("totalValuesArray.length: " + totalValuesArray.length);

    var i = 1, newItem;
    if (totalValuesArray.length < (noOfBlocksInBlueGreenContainer * 2)) {
        while (totalValuesArray.length < (noOfBlocksInBlueGreenContainer * 2)) {
            newItem = i * (totalBlocks - totalValuesArray.length) * (interval + 5);
            totalValuesArray.indexOf(newItem) === -1 ? totalValuesArray.push(newItem) : console.log("");
            i++;
        }
    }


//    console.log("totalValuesArray: " + totalValuesArray);
//    console.log("totalValuesArray.length: " + totalValuesArray.length);

    do {
        blocksInBlueContainer[blocksInBlueContainer.length] = totalValuesArray.splice(Math.floor(Math.random() * totalValuesArray.length), 1)[0];
    } while (blocksInBlueContainer.length < noOfBlocksInBlueGreenContainer);

    do {
        blocksInGreenContainer[blocksInGreenContainer.length] = totalValuesArray.splice(Math.floor(Math.random() * totalValuesArray.length), 1)[0];
    } while (blocksInGreenContainer.length < noOfBlocksInBlueGreenContainer);

//    console.log("blocksInBlueContainer: " + blocksInBlueContainer);
//    console.log("blocksInGreenContainer: " + blocksInGreenContainer);
//    console.log("totalValuesArray: " + totalValuesArray);

    for (var i = 0; i < noOfBlocksInBlueGreenContainer; i++) {
        $(".blueContainer").append('<div id="normalBlock' + (i) + '" class="normalBlock"><div class="draggable draggableBlue item" tabindex=0 target="' + (i) + '">' + blocksInBlueContainer[i] + '</div></div>');
        $(".greenContainer").append('<div id="normalBlock' + (i + noOfBlocksInBlueGreenContainer) + '" class="normalBlock"><div class="draggable draggableGreen item" tabindex=0 target="' + (i + noOfBlocksInBlueGreenContainer) + '">' + blocksInGreenContainer[i] + '</div></div>');
    }


    $(".blueContainer .draggable, .greenContainer .draggable").draggable({
        containment: 'body',
        cursor: 'move',
        revert: function (is_valid_drop) {
            console.log("is_valid_drop = " + is_valid_drop);
            if (!is_valid_drop) {
                console.log("revert triggered");

                if ($(this).parent().hasClass("droppable")) {
                    var tar = $(this).attr("target");
                    $("#normalBlock" + tar).append($(this)).show('slow');
                }

                checkAnswer();
                return true;
            }
        },
        start: function (event, ui) {
            $(this).css({"z-index": 1});
            console.log("drag start");
        },
        stop: function (event, ui) {
            $(this).css({"z-index": 0});
            console.log("drag stop");
        }
    });

    $(".beaker .droppable").droppable({
        tolerance: "intersect",
        greedy: true,
        accept: function (drag) {
            return true;
        }, drop: function (event, ui) {
            //console.log("called----");
            if ($(this).children().length > 0) {
                $(this).find(".draggable").each(function (i) {
                    var tar = $(this).attr("target");
                    $("#normalBlock" + tar).append($(this)).show('slow');
                });
            }

            var dropTarget = $(this).attr("dropTarget");
            var target = $(ui.draggable).attr("target");

            //console.log("dropTarget: " + dropTarget);
            //console.log("target: " + target);

            $(this).append(ui.draggable);
            ui.draggable.position({of: $(this), my: 'left top', at: 'left top'});

            checkAnswer();

        }
    });

    function checkAnswer() {
        answerArray = [];
        $(".beaker").find('.droppable .draggable, .normalBlock').each(function (i) {
            answerArray.push(parseInt($(this).html()));
        });

//        console.log("answerArray: " + answerArray);
//        console.log("answerArray.length: " + answerArray.length);

        if (answerArray.length < totalBlocks) {
            $(".checkButton").hide();
        } else if (parseInt(answerArray.length) === parseInt(totalBlocks)) {
            $(".checkButton").show();
            alert(messages[1]);
        }
    }
    ;


});

function checkProblem() {
    console.log("checkProblem");
    attempt++;
    console.log("attempt: " + attempt);
    var done = true;
    var isDescending = true;
    for (var i = 0, l = answerArray.length - 1; i < l; i++)
    {
        isDescending = isDescending && (answerArray[i] > answerArray[i + 1]);
    }

    if (isDescending)
    {
        console.log('Descending');
        done = true;
        console.log('done: ' + done);
        $(".checkButton").hide();
        $(".nextButton").show();

        alert(messages[2]);
        $(".beaker").find('.droppable .draggable, .normalBlock').each(function (i) {
            if ($(this).hasClass("draggable")) {
                $(this).draggable({disabled: true});
                $(this).attr('tabindex', '-1').click(false);
                if (attempt === 3) {
                    $(this).append('<span class="tick" onfocus="this.blur();">&#10003;</span>');
                }
            }
        });

        nextButtonClick++;

    } else {
        done = false;
        console.log('done: ' + done);
        if (attempt === 1) {
            $(".checkButton").hide();
            alert("first wrong attempt: " + attempt);

            var anotherArray = [];
            $(".beaker").find('.droppable .draggable').each(function (i) {
                anotherArray.push(parseInt($(this).html()));
            });

            console.log("anotherArray: " + anotherArray);
            var newArray = JSON.parse(JSON.stringify(anotherArray));
            console.log("newArray: " + newArray);
            newArray.sort(function (a, b) {
                return b - a;
            });
            console.log("newArray: " + newArray);

            var missMatchCount = 0;

            for (var i = 0; i < anotherArray.length; i++) {
                if (newArray[i] !== anotherArray[i]) {
                    missMatchCount++;
                }
            }

            console.log("missMatchCount: " + missMatchCount);
            console.log("anotherArray.length: " + anotherArray.length);

            if (missMatchCount === anotherArray.length) {
                alert(messages[4]);
            } else {
                alert(messages[3]);
            }

        } else if (attempt === 2) {
            alert("second wrong attempt: " + attempt);
            $(".checkButton").hide();

            console.log("answerArray: " + answerArray);
            var newArray = JSON.parse(JSON.stringify(answerArray));
            console.log("newArray: " + newArray);
            newArray.sort(function (a, b) {
                return b - a;
            });
            console.log("newArray: " + newArray);

            var atLeastOne = false;

            for (var i = 0; i < answerArray.length; i++) {
                if (newArray[i] === answerArray[i]) {
                    var index = i;
                    $(".beaker").find('.droppable .draggable, .normalBlock').each(function (i) {
                        console.log("i: " + i);
                        if (index === i) {
                            if ($(this).hasClass("draggable")) {
                                console.log("draggable disabled at :" + i);
                                $(this).draggable({disabled: true});
                                $(this).attr('tabindex', '-1').click(false);
                                $(this).append('<span class="tick" onfocus="this.blur();">&#10003;</span>');
                                atLeastOne = true;
                            }

                        }

                    });

                }
            }

            if (atLeastOne) {
                alert(messages[5]);
            } else {
                alert(messages[4]);
            }

        } else if (attempt === 3) {
            alert("third wrong attempt: " + attempt);
            $(".checkButton").hide();
            $(".nextButton").show();

            console.log("answerArray: " + answerArray);
            var newArray = JSON.parse(JSON.stringify(answerArray));
            console.log("newArray: " + newArray);
            newArray.sort(function (a, b) {
                return b - a;
            });
            console.log("newArray: " + newArray);

            var atLeastOne = false;

            for (var i = 0; i < answerArray.length; i++) {
                if (newArray[i] === answerArray[i]) {
                    var index = i;
                    $(".beaker").find('.droppable .draggable, .normalBlock').each(function (i) {
                        console.log("i: " + i);
                        if (index === i) {
                            if ($(this).hasClass("draggable") && !$(this).children().hasClass("tick")) {
                                console.log("draggable disabled at :" + i);
                                $(this).draggable({disabled: true});
                                $(this).attr('tabindex', '-1').click(false);
                                $(this).append('<span class="tick" onfocus="this.blur();">&#10003;</span>');
                            }

                            if ($(this).hasClass("draggable")) {
                                atLeastOne = true;
                            }

                        }
                    });
                }
            }

            if (atLeastOne) {
                alert(messages[6]);
            } else {
                alert(messages[7]);
            }


        } else {

        }
    }

}


function nextProblem() {
    nextButtonClick++;
    console.log("nextProblem");
    if (nextButtonClick === 1) {
        var newArray = JSON.parse(JSON.stringify(answerArray));
        console.log("newArray: " + newArray);
        newArray.sort(function (a, b) {
            return b - a;
        });
        console.log("newArray: " + newArray);
        console.log("blocksInTheBeaker: " + blocksInTheBeaker);
        console.log("blocksInBlueContainer: " + blocksInBlueContainer);
        console.log("blocksInGreenContainer: " + blocksInGreenContainer);

        $(".beaker").html("");

        for (var i = 0; i < newArray.length; i++) {

            if ($.inArray(newArray[i], blocksInTheBeaker) !== -1) {
                $(".beaker").append('<div class="normalBlock">' + newArray[i] + '</div>');
            } else if ($.inArray(newArray[i], blocksInBlueContainer) !== -1) {
                $(".beaker").append('<div class="blueBlock">' + newArray[i] + '</div>');
            } else if ($.inArray(newArray[i], blocksInGreenContainer) !== -1) {
                $(".beaker").append('<div class="greenBlock">' + newArray[i] + '</div>');
            }

        }
    } else if (nextButtonClick === 2) {
        $(".checkButton").hide();
        $(".nextButton").hide();

        var newArray = JSON.parse(JSON.stringify(answerArray));
        console.log("newArray: " + newArray);
        newArray.sort(function (a, b) {
            return b - a;
        });
        console.log("newArray: " + newArray);
        console.log("blocksInTheBeaker: " + blocksInTheBeaker);
        console.log("blocksInBlueContainer: " + blocksInBlueContainer);
        console.log("blocksInGreenContainer: " + blocksInGreenContainer);

        $(".beaker").html("");
        $(".beaker").append("<div class='waterLevel'></div>");

        for (var i = 0; i < newArray.length; i++) {

            if ($.inArray(newArray[i], blocksInTheBeaker) !== -1) {
                $(".beaker").append('<div class="normalBlock">' + newArray[i] + '</div>');
            } else if ($.inArray(newArray[i], blocksInBlueContainer) !== -1) {
                $(".beaker").append('<div class="blueBlock">' + newArray[i] + '</div>');
            } else if ($.inArray(newArray[i], blocksInGreenContainer) !== -1) {
                $(".beaker").append('<div class="greenBlock">' + newArray[i] + '</div>');
            }

        }

        $(".blueContainer").hide();
        $(".greenContainer").hide();
        $(".questionSectionContainer").show();
        $(".beaker").css("float", "right");
        $(".mainContainer").css("margin", "0 15%");
        $(".questionSectionContainer .question").html(messages[9]);

        var randomNumber = randomIntFromInterval(3, 9) * interval;
        var optionArray = [randomNumber - interval, randomNumber, randomNumber + interval, randomNumber + 5];
        console.log("randomNumber: " + randomNumber);
        console.log("optionArray: " + optionArray);
        optionArray.sort(function () {
            return 0.5 - Math.random();
        });
        console.log("optionArray: " + optionArray);

        var correctAnswer = optionArray[randomIntFromInterval(0, 3)];
        console.log("correctAnswer: " + correctAnswer);

        $(".questionSectionContainer .options").find('.questionAnswerButton').each(function (i) {
            $(this).attr("value", optionArray[i]);
            $(this).html(optionArray[i] + " ml");
        });

        $(".questionSectionContainer .options .questionAnswerButton").click(function () {
            $(".questionSectionContainer .options .questionAnswerButton").removeClass("selected");
            $(this).addClass("selected");

        });


//test
        var beakerHeight = $(".beaker").outerHeight();
        console.log("beakerHeight: " + beakerHeight);

        var correctAnswerHeight = 0;
        var remainingHeightPercent = 0;

        $(".beaker").find('.normalBlock,.blueBlock,.greenBlock').each(function (i) {
            correctAnswerHeight += $(this).outerHeight();
            if ($(this).html() == correctAnswer) {
                console.log("correctAnswerHeight: " + correctAnswerHeight);

                remainingHeightPercent = ((beakerHeight - correctAnswerHeight) / beakerHeight) * 100;
                console.log("remainingHeightPercent: " + remainingHeightPercent);



                return false;
            }
        });

        $(".beaker").css("background", "linear-gradient(to top, blue " + 70 + "%,rgba(0,0,0,0) 0%);");

    } else {

    }


}


function randomIntFromInterval(min, max)
{
    return Math.floor(Math.random() * (max - min + 1) + min);
}