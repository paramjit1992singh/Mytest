$(document).ready(function () {
    var totalBlocks = 10;
    //var upperLimit = 200;
    var interval = 20;
    var noOfBlocksInBlueGreenContainer = 3;
    var totalValuesArray = [];
    var blocksInBlueContainer = [], blocksInGreenContainer = [];

    for (var i = 1; i <= totalBlocks; i++) {
        totalValuesArray.push(interval * i);
    }

    do {
        blocksInBlueContainer[blocksInBlueContainer.length] = totalValuesArray.splice(Math.floor(Math.random() * totalValuesArray.length), 1)[0];
    } while (blocksInBlueContainer.length < noOfBlocksInBlueGreenContainer);

    do {
        blocksInGreenContainer[blocksInGreenContainer.length] = totalValuesArray.splice(Math.floor(Math.random() * totalValuesArray.length), 1)[0];
    } while (blocksInGreenContainer.length < noOfBlocksInBlueGreenContainer);

    console.log("blocksInBlueContainer: " + blocksInBlueContainer);
    console.log("blocksInGreenContainer: " + blocksInGreenContainer);
    console.log("totalValuesArray: " + totalValuesArray);

    for (var i = 0; i < noOfBlocksInBlueGreenContainer; i++) {
        $(".blueContainer").append('<div class="normalBlock"><div class="draggable item" tabindex=0 data-id="item' + (i + 1) + '">' + blocksInBlueContainer[i] + '</div></div>');
        $(".greenContainer").append('<div class="normalBlock"><div class="draggable item" tabindex=0 data-id="item' + (i + 1) + '">' + blocksInGreenContainer[i] + '</div></div>');
    }

    for (var i = totalBlocks; i > 0; i--) {
        if ($.inArray((i * interval), totalValuesArray) !== -1) {
            $(".beaker").append('<div class="normalBlock">' + (i * interval) + '</div>');
        } else {
            $(".beaker").append('<div class="droppable"></div>');
        }
    }

    $(".blueContainer .draggable, .greenContainer .draggable").draggable({
        containment: 'body',
        cursor: 'move',
        revert: function (event, ui) {
//            console.log("is_valid_drop = " + is_valid_drop);
//            if (!is_valid_drop) {
//                console.log("revert triggered");
//                return true;
//            }
            $(this).data("uiDraggable").originalPosition = {
                top: 0,
                left: 0
            };
            return !event;
        },
        start: function (event, ui) {
            $(this).css({"z-index": 1});
        },
        stop: function (event, ui) {
            $(this).css({"z-index": 0});
        }
    });

    $(".beaker .droppable").droppable({
        tolerance: "intersect",
        accept: function (drag) {
//            var dropId = $(this).attr('data-id');
//            var dragId = $(drag).attr('data-id');
//            return dropId === dragId;
            return true;
        }, drop: function (event, ui) {
            ui.draggable.position({of: $(this), my: 'left top', at: 'left top'});
        }
    });


});