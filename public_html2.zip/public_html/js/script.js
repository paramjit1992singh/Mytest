document.getElementById('links1row').onclick = function (event) {
    event = event || window.event;
    var target = event.target || event.srcElement,
            link = target.src ? target.parentNode : target,
            options = {
                index: link,
                event: event
            },
    links = this.getElementsByTagName('a');
    //alert("links: " + event.srcElement);
    blueimp.Gallery(links, options);
};


var number_of_pagesFormed = 0;
var currentPage = 1;


$(document).ready(function () {
    var folderNames = [];
    var imagesNames = [];
    var thumbnailImage = [];
    var imageMetaTag = [];
    var thumbnailImageMetaTag = [];

    $.ajax({
        type: "GET",
        url: "xml/data.xml",
        dataType: "xml",
        async: false,
        success: function (xml) {

            $(xml).find('images').each(function (i) {

                console.log("images for :" + $(this).attr("for"));
                folderNames.push($(this).attr("for"));
                imagesNames[i] = [];
                thumbnailImage[i] = [];
                imageMetaTag[i] = [];
                thumbnailImageMetaTag[i] = [];

                $(this).find('image').each(function (j) {


                    imagesNames[i].push($(this).html());
                    imageMetaTag[i].push($(this).attr("metaTag"));


                });

                $(this).find('thumbnailImage').each(function (j) {


                    thumbnailImage[i].push($(this).html());
                    thumbnailImageMetaTag[i].push($(this).attr("metaTag"));

                });

                console.log("imagesNames :" + imagesNames[i]);
                console.log("thumbnailImage :" + thumbnailImage[i]);
                console.log("imageMetaTag :" + imageMetaTag[i]);
                console.log("thumbnailImageMetaTag :" + thumbnailImageMetaTag[i]);


            });



        },
        error: function () {

            alert("An error occurred while processing XML file.");

        }
    });

    console.log("folderNames: " + folderNames);

//    var data = [["http://placehold.it/400x400&text=Photo+1", "http://placehold.it/400x400&text=Photo+2", "http://placehold.it/400x400&text=Photo+3", "http://placehold.it/400x400&text=Photo+4"],
//    ["http://placehold.it/400x400&text=Photo+5", "http://placehold.it/400x400&text=Photo+6", "http://placehold.it/400x400&text=Photo+7", "http://placehold.it/400x400&text=Photo+8"],
//    ["http://placehold.it/400x400&text=Photo+9", "http://placehold.it/400x400&text=Photo+10", "http://placehold.it/400x400&text=Photo+11", "http://placehold.it/400x400&text=Photo+12"],
//    ["http://placehold.it/400x400&text=Photo+13", "http://placehold.it/400x400&text=Photo+14", "http://placehold.it/400x400&text=Photo+15", "http://placehold.it/400x400&text=Photo+16"]
//    ];
//    var dataThumb = [["http://placehold.it/100x100&text=Thumbnail-1", "http://placehold.it/100x100&text=Thumbnail-2", "http://placehold.it/100x100&text=Thumbnail-3", "http://placehold.it/100x100&text=Thumbnail-4"],
//    ["http://placehold.it/100x100&text=Thumbnail-5", "http://placehold.it/100x100&text=Thumbnail-6", "http://placehold.it/100x100&text=Thumbnail-7", "http://placehold.it/100x100&text=Thumbnail-8"],
//    ["http://placehold.it/100x100&text=Thumbnail-9", "http://placehold.it/100x100&text=Thumbnail-10", "http://placehold.it/100x100&text=Thumbnail-11", "http://placehold.it/100x100&text=Thumbnail-12"],
//    ["http://placehold.it/100x100&text=Thumbnail-13", "http://placehold.it/100x100&text=Thumbnail-14", "http://placehold.it/100x100&text=Thumbnail-15", "http://placehold.it/100x100&text=Thumbnail-16"]];

    var data = imagesNames;
    var dataThumb = thumbnailImage;

    $(".divData").click(function () {

        var target2 = $(this).attr("target");
        //alert("target: " + target2);
        target2 = target2 - 1;

        $("#links1row").html(" ");
        $(".controls").remove();

        for (var i = 0; i < data[target2].length; i++) {

            $("#links1row").append("<div class='connect-cat name' metaTag='" + imageMetaTag[target2][i] + "'><a href='images/" + data[target2][i] + "' title=''><div class='floatLeft thumbs'><img src='images/" + dataThumb[target2][i] + "'  alt='Banana1' class='img-thumbnail' style='width:400px;height:200px;'></div></a></div>");
        }

        $("#links1row").append("<div class='clear'></div>")
        pagination();

    });

    $("#box").on('keyup', function () {
        var matcher = new RegExp($(this).val(), 'gi');
        $('.connect-cat').show().not(function () {
            //return matcher.test($(this).find('.name, .category').text())
            return matcher.test($(this).attr('metaTag'));
        }).hide();
       
    });


    /*$("#box").keyup(function () {
     var value = this.value;
     $(".connect-cat").find(".name").each(function (index) {
     if (index === 0)
     return;
     //var id = $(this).find("td").first().text();
     var id = $(this).attr('metaTag');
     alert("id: " + id);
     $(this).toggle(id.indexOf(value) !== -1);
     });
     });*/




    function pagination() {
        var show_per_page = 5;
        var number_of_items = $('#links1row').children('div').size() - 1;
        //alert("number_of_items: " + number_of_items);
        var number_of_pages = Math.ceil(number_of_items / show_per_page);
        number_of_pagesFormed = number_of_pages;
        //alert("number_of_pagesFormed: " + number_of_pagesFormed);

        $('.marketing1').append('<div class=controls></div><input id=current_page type=hidden><input id=show_per_page type=hidden>');
        $('#current_page').val(0);
        $('#show_per_page').val(show_per_page);

        var navigation_html = '<a class="prev" onclick="previous()">Prev</a>';
        var current_link = 0;
        while (number_of_pages > current_link) {
            navigation_html += '<a class="page" onclick="go_to_page(' + current_link + ')" longdesc="' + current_link + '">' + (current_link + 1) + '</a>';
            current_link++;
        }
        navigation_html += '<a class="next" onclick="next()">Next</a>';

        $('.controls').html(navigation_html);
        $('.controls .page:first').addClass('active');

        $('#links1row').children().css('display', 'none');
        $('#links1row').children().slice(0, show_per_page).css('display', 'block');
        $(".prev").addClass("disable");

        if (number_of_pagesFormed == 1) {
            $(".prev").addClass("disable");
            $(".next").addClass("disable");
        }


    }






});




function go_to_page(page_num) {
    var show_per_page = parseInt($('#show_per_page').val(), 0);

    start_from = page_num * show_per_page;

    end_on = start_from + show_per_page;

    $('#links1row').children().css('display', 'none').slice(start_from, end_on).css('display', 'block');

    $('.page[longdesc=' + page_num + ']').addClass('active').siblings('.active').removeClass('active');

    $('#current_page').val(page_num);
}



function previous() {

    //alert("currentPage: " + currentPage);

    if (currentPage == 2) {
        $(".prev").addClass("disable");
    }

    new_page = parseInt($('#current_page').val(), 0) - 1;
    //if there is an item before the current active link run the function
    if ($('.active').prev('.page').length == true) {
        currentPage--;
        $(".next").removeClass("disable");
        go_to_page(new_page);
    }

}

function next() {

    //alert("currentPage: " + currentPage);
    if (currentPage == number_of_pagesFormed - 1) {
        $(".next").addClass("disable");
    }

    new_page = parseInt($('#current_page').val(), 0) + 1;
    //if there is an item after the current active link run the function
    if ($('.active').next('.page').length == true) {
        currentPage++;
        $(".prev").removeClass("disable");
        go_to_page(new_page);
    }

}
