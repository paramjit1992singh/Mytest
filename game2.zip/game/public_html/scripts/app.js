var questionLoad;
var questionIndex;
var isReview=0;


// Listen for resize changes

$(document).ready(function(){
    $("#startButton").on("click", function(){
        $('#startScreen').addClass('hidden');
        $('#questionModule').removeClass('hidden');

    });
    
});