var app = angular.module('myApp', []);

app.controller('myCtrl', ['$scope', '$http', '$document', '$rootScope', function ($scope, $http, $document, $rootScope) {

  $scope.datavalue = {};
  $rootScope.datalength;
  $scope.ans = [];
  $scope.ansval = [];
    $scope.sta=true;
   $scope.que=false;  

  $scope.buttonsta=function(){
     $scope.que=true;
      $scope.sta=false;
      //listenToClick();
  setTimeout(listenToClick, 0);
 // resizeCanvas();

  }

//console.log($scope.que);

  $http.get("./data/data.json").then(function (response) {
    $scope.datavalue = response.data;
    // console.log($scope.datavalue);
    $rootScope.datalength = $scope.datavalue.data.QuestionAnswer.length;

  });
  var lastSelection;
  var p = 0;
  var canvasPoints = [];
  var canvas = null;
  var bounds = null;
  var ctx = null;
  drag = false;
  var startX = 0;
			var startY = 0;
			var mouseX = 0;
			var mouseY = 0;
			var existingLines = [];
   var idarr = [];



  function listenToClick() {
    var rows = document.getElementById('divId1').querySelectorAll('.row');
    var cols, col, row;
   
     
     $('.selectedwrong').css("cursor", "pointer");  
    $('.selectedwrongleft').css("cursor", "pointer");  
    var lineBegine = document.getElementById('divId1').querySelectorAll('.Linebigine')
    for (col = 0; col < lineBegine.length; col++) {   

       var element = $(lineBegine[col]);
        if(element.hasClass('correctright')  ){
          console.log("enter");
           var old_element = element[0];
          var new_element = old_element.cloneNode(true);
          old_element.parentNode.replaceChild(new_element, old_element);
            
        }else{

              lineBegine[col].addEventListener('mousedown', mouseDown.bind({
                // row: row,
                // col: col,
              element: lineBegine[col]
            }), false);
            
              lineBegine[col].addEventListener('touchstart', mouseDown.bind({
                // row: row,
                // col: col,
              element: lineBegine[col]
              }), false);
        }
    }    
    var lineDrop = document.getElementById('divId1').querySelectorAll('.LineDrop')
    for (col = 0; col < lineDrop.length; col++) {   

       var element = $(lineDrop[col]);
       if(element.hasClass('correct')){
          console.log("enter1");
          var old_element =element[0];
          var new_element = old_element.cloneNode(true);
          old_element.parentNode.replaceChild(new_element, old_element);        
        
        }else{
            lineDrop[col].addEventListener('mouseup', mouseUp.bind({
              // row: row,
              // col: col,
              element: lineBegine[col]
            }), false);
             lineDrop[col].addEventListener('touchend', mouseUp.bind({
              // row: row,
              // col: col,
              element: lineBegine[col]
            }), false);

              element.children('.round-pointer-left').css("border-color","#000000");
            element.children('.round-pointer-left').empty();
        }
    }    
 
    canvas = document.getElementById("connection-canvas");

    canvas.onmousemove = onmousemove;
    canvas.ontouchmove=handleTouchmove;
    //$('#connection-canvas').on("mousemove touchmove", onmousemove);
    //$('#connection-canvas').bind("touchmove", onmousemove());
    //canvas.ontouchmove=onmousemove;
    //$('.circle').each.bind('touchmove',onmousemove);
    canvas.onmouseup = onmouseup;
    bounds = canvas.getBoundingClientRect();
    console.log(bounds);
    ctx = canvas.getContext("2d");
    var width=$('#divId1').width();
    ctx.canvas.width = width;
    ctx.canvas.height = window.innerHeight;
   
    console.log(width);
    //bounds = canvas.getBoundingClientRect();

 

  }
   var canvasPoints = [];
    canvasPoints.question=[];
  canvasPoints.answer=[];
  function onmouseup(e){
    ctx.clearRect(0, 0, window.innerWidth, window.innerWidth);
    //draw();
    drag = false
    console.log("sdffssdffd")
    console.log(existingLines)
       ctx.strokeStyle = "black";
    ctx.lineWidth = 5;
    ctx.beginPath();
      for (var i = 0; i < existingLines.length; ++i) {
      var line = existingLines[i];
      ctx.moveTo(line.startX,line.startY);
      ctx.lineTo(line.endX,line.endY);
      ctx.stroke();
    }
  }
  function onmousemove(e) {
     
      if (drag) {
        mouseX = e.clientX - bounds.left;
        mouseY = e.clientY - bounds.top;
       // console.log("mousex-"+ mouseX);
     //   console.log("mousey"+ mouseY);
       
        draw();
      }
  }
   function handleTouchmove(e){
    event.preventDefault(); // we don't want to scroll
   
      if (drag) {
        mouseX = parseInt(e.touches[0].clientX - bounds.left);
        mouseY = parseInt(e.touches[0].clientY - bounds.top);
        //console.log("mousex-"+ mouseX);
        //console.log("mousey"+ mouseY);
        draw();
      }
    }
   
  function mouseDown(event) {
   
    if (!drag) {
      console.log(getPoint(event.target).x)
      startX = getPoint(event.target).x;
      startY = getPoint(event.target).y;
      qid=event.target.id;
       qtext=event.target.innerText;

      for(i=0;i<existingLines.length;i++){
          if (existingLines[i].qid == event.target.id) {
        
           existingLines.splice(i,1);
           break;
        }
      }
       
      

      console.log(existingLines);
      drag = true;
    }

}

function mouseUp(event) {
  console.log("entermouse up");
 if(drag){
  mouseX = getPoint(event.target).x;
  mouseY = getPoint(event.target).y;
  var aid=event.target.id;
  existingLines.push({
    qtext:qtext,
    qid:qid,
    aid:aid,
    startX: startX,
    startY: startY,
    endX: mouseX,
    endY: mouseY
   
  });
  draw();
  drag = false;
$('.box-right').removeClass('selectcol');
  $('.box-right').children('.round-pointer-left').removeClass('round-border-color');

     for (var i = 0; i < existingLines.length; i++) {
             
              var id = "#" + existingLines[i].aid;
              var el=$(id);
              if(!el.hasClass('correct')  ){
             
              $(id).addClass("selectcol");
               $(id).children('.round-pointer-left').addClass("round-border-color");
              }

     }

    if ($rootScope.datalength == existingLines.length) {

      $scope.$apply(function () {
        $scope.buttonflg = true;
        $scope.buttonreviewflg = false;
        $scope.buttonworng = false;
        $scope.ansarray = [];
        $scope.resultarr = existingLines; 
        $scope.goodans = false;     

      });
       draw();
    }
  
 }
  
}

  function draw() {
   // ctx.fillStyle = "#fff";
    
    //ctx.fillRect(0,0,window.innerWidth,window.innerHeight);
    ctx.clearRect(0, 0, window.innerWidth, window.innerWidth);
    ctx.strokeStyle = "#AD762A";
    ctx.lineWidth = 5;
    ctx.beginPath();
    
    for (var i = 0; i < existingLines.length; ++i) {
      var line = existingLines[i];
      ctx.moveTo(line.startX,line.startY);
      ctx.lineTo(line.endX,line.endY);
    }
    
    ctx.stroke();
    
    if (drag) {
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 5;
      ctx.fillStyle='#000000';
      ctx.beginPath();
      ctx.moveTo(startX,startY);
      ctx.lineTo(mouseX,mouseY);

      ctx.arc(mouseX, mouseY, 16, 0, 2 * Math.PI,false);
      
      ctx.stroke();
      ctx.fill();
    }
  }


  var question = null;
  var answer = null;

  // This is fired when a answer-container is clicked.

  function getPoint(arg) {
   // console.log(arg);
    var roundPointer = arg.lastElementChild;
    return {
      y: arg.offsetTop + roundPointer.offsetTop + roundPointer.offsetHeight / 2,
      x: arg.offsetLeft + roundPointer.offsetLeft + roundPointer.offsetWidth / 2,
      text: arg.innerText,
      id: arg.id,
      flg: 0
    };
  }


 
  
 


  $scope.checkans = function (qusarr) {
    $scope.valuecheck_arr = existingLines;
    $scope.result_arr = qusarr;
    console.log($scope.valuecheck_arr);
    console.log($scope.result_arr);
    
    for (var i = 0; i < $scope.valuecheck_arr.length; i++) {


      var idleft = "#" + $scope.valuecheck_arr[i].qid;
      var idright = "#" + $scope.valuecheck_arr[i].aid;
         $('.box-right').removeClass('selectcol');
        $('.box-right').children('.round-pointer-left').removeClass('round-border-color');
        

      console.log("ok");
     

      for(var j=0;j<$scope.result_arr.length;j++){
            if ($scope.result_arr[j].mathAns == $scope.valuecheck_arr[i].aid && $scope.result_arr[j].mathQues == $scope.valuecheck_arr[i].qtext) {

              console.log("match");
              
              $(idright).addClass("correct");
              $(idright).children('.round-pointer-left').html('<i class="fa fa-check icon-position"></i>').css({"color":"green","border-color":"green"});
               $(idright).removeClass('selectedwrong');
              $(idleft).addClass("correctright");
              $scope.ansarray.push($scope.valuecheck_arr[i]);                            
                 drawLine($scope.valuecheck_arr[i],"correct");
                   j=$scope.result_arr.length;

            } else {
                console.log("woring");
              $(idright).addClass("selectedwrong");
               $(idleft).addClass("selectedwrongleft");
                $(idright).children('.round-pointer-left').html('<i class="fas fa-times icon-position"></i>').css({"color":"red","border-color":"red"});
                 drawLine($scope.valuecheck_arr[i],"wrong");
            
            }
        }
      // leftEl = rightEl = null;  

       if (i == $scope.valuecheck_arr.length - 1) {
        console.log("enter");

        $scope.buttonreviewflg = true;
       // $scope.desable = true;
       $scope.buttonworng = true;
       $scope.buttonflg = false;
         removebind();

      } else {
        $scope.buttonreviewflg = false;
       // $scope.desable = false;
       $scope.buttonworng = false;
       $scope.buttonflg = true;
       
      }


    }



  }

   $scope.review = function (answerarr, ansval) {
     listenToClick();
    console.log("review");
    $scope.buttonworng = false;
    $scope.ans = answerarr;
    $scope.ansval = ansval;
    //canvasPoints = $scope.ans;
    existingLines=$scope.ans;
    console.log(existingLines);
    console.log($scope.ansval);

    var canvas = document.getElementById("connection-canvas");
    var ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    $('.box-right').css("background-color", "");      

    $('.box-right').removeClass('selectedwrong');
  $('.box-right').removeClass('selectedwrongleft');

      $('.correctright').css("cursor", "no-drop");  
              $('.correct').css("cursor", "no-drop");  
    //var rows = document.getElementById('divId1').querySelectorAll('.row'),
    var correctans=0;
    for (var i = 0; i < existingLines.length; i++) {

       var idleft = "#" + existingLines[i].qid;
      var idright = "#" +existingLines[i].aid;

      drawLine(existingLines[i],"correct");
      //$(idright).addClass("selected");

    // canvasPoints[i].question.flg = 1;
     // canvasPoints[i].answer.flg = 1;
     correctans++;
    }

     if ($rootScope.datalength == correctans) {
        $scope.goodans = true;
     }else{

    $scope.buttonreviewflg = false;
    //$scope.desable = false;
    $scope.buttonflg = false;  
     $scope.goodans = false;
  //  listenToClick_check();
     }


  }

  //====================================
//drawLine
function drawLine(arr,val) {
    var canvas = document.getElementById("connection-canvas");
    var ctx = canvas.getContext("2d");
     var line = arr;    
     var c=val;

     if(c=="correct"){
       ctx.strokeStyle = 'green';
     }else if(c=="wrong"){
        ctx.strokeStyle = 'red';
     }else{
       ctx.strokeStyle ='#000000';
     }

    ctx.beginPath();
     ctx.moveTo(line.startX,line.startY);
      ctx.lineTo(line.endX,line.endY);
    
   
    ctx.lineWidth = 5;
    ctx.stroke();
  }

  //==============================

//remove bind
function removebind(){
    var canvas = document.getElementById("connection-canvas");
    var ctx = canvas.getContext("2d");
    bounds = canvas.getBoundingClientRect();
    var rows = document.getElementById('divId1').querySelectorAll('.row'),
      row;
    var cols, col;
     $('.correctright').css("cursor", "no-drop");  
    $('.correct').css("cursor", "no-drop");  
     $('.selectedwrong').css("cursor", "no-drop");  
    $('.selectedwrongleft').css("cursor", "no-drop");  

    for (row = 0; row < rows.length; row++) {
      cols = rows[row].children;

      for (col = 0; col < cols.length; col++) {  
        
           var element = $(cols[col]);
    //if(element.hasClass('correct')  ){

           
          var old_element = element[0];
          var new_element = old_element.cloneNode(true);
          old_element.parentNode.replaceChild(new_element, old_element);
        
      //  }
       // else if(element.hasClass('correctright')){
         // var old_element =element[0];
        //  var new_element = old_element.cloneNode(true);
        //  old_element.parentNode.replaceChild(new_element, old_element);
      //  }



      }
    }
  }


  //

  //====================================


   $scope.rload=function(){
    console.log("enter reset");
    location.reload();
    //$scope.buttonsta();
  }

}]);


