var optionDown = false;
var accDragType = '';
var accDragId = 0;
var accDragText = '';
var currentFocus;
var accValue = 0;
var accIndex = 0;
var rows = 0, cols = 0, questions, answers, totalCells, questionsSingleArray = [], answersSingleArray = [];

$(document).ready(function () {

    var questionLoad;
    var questionIndex;
    var message = false;
    var datavalue;
    var flagcheck = false;
    var result = document.getElementById("ans-description");

    $.ajax({
        type: 'GET',
        url: './data/data.json',
        data: {get_param: 'value'},
        async: false,
        dataType: 'json',
        success: function (response) {

            datavalue = response;
            var datalength = datavalue.data.Questions.length;
            rows = response.data.rows;
            cols = response.data.cols;
            questions = response.data.Questions;
            answers = response.data.Answers;
            console.log("questions: " + questions);
            console.log("answers: " + answers);
            $(".title-description").html(response.data.description);
            loadQuestion();

            $('.title').focus();

        }
    });


    function loadQuestion() {

        //alert("hii");

        var html = '';
        var index = 0;
        totalCells = rows * cols;
        for (var i = 0; i < rows; i++) {
            html += '<div class="row">';
            for (var j = 0; j < cols; j++) {
                html += "<div id='droppable" + index + "' class='col-lg-3 col-md-3 col-sm-3 col-xs-3 text-center droppable' cont='dropdrag" + index + "' accIndex=" + index + "  accValue=" + answers[i][j] + " tabindex='0'><div class='column draggable' cont='dropdrag" + index + "' value=" + answers[i][j] + ">" + questions[i][j] + "</div></div>";
                index++;
                questionsSingleArray.push(questions[i][j]);
                answersSingleArray.push(answers[i][j]);
            }
            html += ("</div>");
        }
        $('.main-container').html(html);

        //MathJax.Hub.Queue(["Typeset", MathJax.Hub]);

        makeDraggable();

        $('.container .centered .test .main-container .droppable').droppable({
            hoverClass: 'hoverClass',
            tolerance: "intersect",
            drop: function (event, ui) {

                //console.log("parseFloat($(ui.draggable).attr(value)): " + parseFloat($(ui.draggable).attr("value")));
                //console.log("parseFloat($(this).attr(accvalue)): " + parseFloat($(this).attr("accvalue")));

                if (parseFloat($(ui.draggable).attr("value")) === parseFloat($(this).attr("accvalue"))) {
                    console.log("parent", $(ui.draggable).parent().attr("id"));
                    console.log("droppable", $(this).attr("id"));
                    if ($(ui.draggable).parent().attr('id') != $(this).attr('id')) {
                        $(ui.draggable).draggable("disable").addClass("correct").html("<span class='green'>&#x2714;</span>");
                        $(this).children().draggable("disable").addClass("correct").html("<span class='green'>&#x2714;</span>");


//                        totalCells -= 2;
//                        if (totalCells == 0) {
//                            $("#info1").text("Congratulations completed successfully");
//                            alert("completed");
//                        }


                    } else {
                        return false;
                    }

                } else {
                    return false;
                }


            }
        });

        function makeDraggable() {
            $('.container .centered .test .main-container .droppable .draggable').draggable({
                zIndex: 99999,
                cursor: "move",
                containment: ".container .centered .test .main-container",
                scroll: false,
                revert: true,
                revertDuration: 0
            });
        }

    }



    document.body.addEventListener('keydown', function (e) {
        if (e.which == 9 || e.keycode == 9) {
            document.body.classList.add('using-key');
        } else if (e.which == 58 || e.keyCode == 58) {
            optionDown = true;
        } else {
            document.body.classList.remove('using-key');
        }
    });
    document.body.addEventListener('keyup', function (e) {
        optionDown = false;
    });
    document.body.addEventListener('mousedown', function () {
        document.body.classList.remove('using-key');
    });


});

$(function () {

    setTimeout(function () {
        $("#popup").hide();
        var userSelection = document.getElementsByClassName('droppable');

        console.log(userSelection);

        for (var i = 0; i < userSelection.length; i++) {
            (function (index) {
                userSelection[index].addEventListener("keydown", function (e) {
                    console.log("Clicked index: " + index);
                    if ((e.altKey && e.keyCode == 53) || (optionDown && (e.which == 23 || e.keyCode == 23))) {
                        var elem = this;
                        currentFocus = $(this);
                        accIndex = $(elem).attr("accIndex");
                        accValue = $(elem).attr("accValue");
                        console.log(currentFocus);
                        console.log("accIndex: " + accIndex);
                        console.log("accValue: " + accValue);

                        $("#accpop").html("");
                        var first = true;
                        for (var k = 0; k < answersSingleArray.length; k++) {
                            if (k != accIndex) {
                                if (first) {
                                    $("#accpop").append('<li id="' + k + '" aria-label="' + answersSingleArray[k] + '" data-value="' + answersSingleArray[k] + '" data-type="' + questionsSingleArray[k] + '" tabindex="-1" class="active">' + answersSingleArray[k] + '</li>');
                                    first = false;
                                } else {
                                    $("#accpop").append('<li tabindex="-1" id="' + k + '" aria-label="' + answersSingleArray[k] + '" data-value="' + answersSingleArray[k] + '" data-type="' + questionsSingleArray[k] + '" class="">' + answersSingleArray[k] + '</li>');
                                }
                            }
                        }

                        var width = $(this).outerWidth();
                        //$(this).attr('aria-grabbed','true');
                        var coords = elem.getBoundingClientRect();
                        $("#popup").css({
                            top: coords.top - 150 + "px",
                            left: (coords.left + width + 10) + "px"
                        }).show().find('li').first().focus();

                        $('#popup ul>li').on('keydown', function (e) {
                            if (e.which == 13 || e.keyCode == 13) {
                                var elm = this;
                                console.log(elm);
                                var dataValue = elm.dataset.value;
                                //alert("dataValue: " + dataValue);
                                if (accValue == dataValue) {
                                    $("#info1").text("That’s correct!");
                                    $('.container .centered .test .main-container .droppable').each(function (i, obj) {
                                        //test
                                        if ($(this).attr("accvalue") == accValue) {
                                            $(this).find(".draggable").each(function () {
                                                $(this).draggable("disable").addClass("correct").html("<span class='green'>&#x2714;</span>");
                                                $(this).parent().removeClass("droppable").addClass("droppable1").removeAttr("accvalue").removeAttr("accindex").removeAttr("tabindex");
                                                $("#popup").hide();
                                                rows--;
                                                cols--;
                                                answersSingleArray = jQuery.grep(answersSingleArray, function (value) {
                                                    return value != accValue;
                                                });

                                                $('.container .centered .test .main-container .droppable').each(function (i, obj) {
                                                    $(this).attr("accindex", i);
                                                });

                                                totalCells -= 2;

                                                if (totalCells == 0) {
                                                    $("#info1").text("Congratulations completed successfully");
                                                    alert("completed");
                                                }

                                            });
                                        }
                                    });

                                } else {
                                    $("#info1").text("That’s incorrect!");
                                }

                            } else if (e.which == 9 || e.keyCode == 9) {
                                $('#accpop').attr('aria-hidden', 'true');
                                $('.draggable-para').attr('tabindex', '0');
                                $('#firstPlace').attr('tabindex', '-1');
                                $('#secondPlace').attr('tabindex', '-1');
                                $('#thirdPlace').attr('tabindex', '-1');
                                $('#fourthPlace').attr('tabindex', '-1');
                                $("#popup").hide();
                                $('#info1').text('');
                                currentFocus.focus();
                            }
                        });

                        var lilength = $('#popup ul>li').length;
                        $('div#popup').on('focus', 'li', function () {
                            $this = $(this);
                            $this.addClass('active').siblings().removeClass();
                            $this.closest('div.container').scrollTop($this.index() * $this.outerHeight());
                        }).on('keydown', 'li', function (e) {
                            $this = $(this);
                            if (e.keyCode == 40) {
                                if ($this.next('li').length > 0) {
                                    $this.next().focus();
                                } else {
                                    $('div#popup').find('li').first().focus();
                                }
                                return false;
                            } else if (e.keyCode == 38) {
                                if ($this.prev().length > 0) {
                                    $this.prev().focus();
                                } else {
                                    $('div#popup').find('li:nth-child(' + lilength + ')').focus();
                                }
                                return false;
                            }
                        }).find('li').first().focus();

                    }
                });
            })(i);
        }
    }, 500);


});