 <?php

if(isSet($_POST['textcontent']))

{
$textcontent=$_POST['textcontent'];
// Sql data insert values into comment table

}

?>

<?php
$dbHost = 'localhost'; 
$dbUsername = 'root';
$dbPassword = '';
$dbDatabase = 'testdb';
$db = mysql_connect($dbHost, $dbUsername, $dbPassword) or die ("Unable to connect to Database Server.");
mysql_select_db ($dbDatabase, $db) or die ("Could not select database.");
$sql = mysql_query('INSERT INTO `messages`(`msg`, `msg_id`) VALUES ('."$textcontent".','."$textcontent".')');

?>


<div class="load_comment"><?php echo $textcontent; ?></div>

 


