<script src="js/jquery-1.12.3.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        alert("hii");
        var projectId = ["projectId1", "projectId2"];
        //alert("projectId: " + projectId);

        $.ajax({
            url: 'create_thumbs.php',
            data: {projectId: JSON.stringify(projectId)},
            type: 'post',
            success: function (output) {
                alert(output);
            }
        });


    });

</script>

<?php
?>
