<?php

$array = json_decode($_POST['projectId']);

//echo 'array: ' . $array[0];

function createThumbs($pathToImages, $pathToThumbs, $thumbWidth) {
    //chmod($pathToImages, 0777);
    chmod($pathToThumbs, 0777);
//    echo 'pathToImages:::' . $pathToImages;
    //echo 'pathToThumbs:::::' . $pathToThumbs;
    $dir = opendir($pathToImages);
    //chmod($dir, 0777);
    while (false !== ($fname = readdir($dir))) {
        // parse path for the extension
        $info = pathinfo($pathToImages . $fname);
        // continue only if this is a JPEG image
        if (strtolower($info['extension']) == 'jpg') {
            echo "Creating thumbnail for {$fname} <br />";

            // load image and get image size
            $img = imagecreatefromjpeg("{$pathToImages}{$fname}");
            $width = imagesx($img);
            $height = imagesy($img);

            // calculate thumbnail size
            $new_width = $thumbWidth;
            $new_height = floor($height * ( $thumbWidth / $width ));

            // create a new tempopary image
            $tmp_img = imagecreatetruecolor($new_width, $new_height);

            // copy and resize old image into new image
            imagecopyresized($tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

            // save thumbnail into a file
            imagejpeg($tmp_img, "{$pathToThumbs}{$fname}");
            chmod("{$pathToThumbs}{$fname}", 0777);
        }
    }
    // close the directory
    closedir($dir);
}

function createGallery($pathToImages, $pathToThumbs) {
    echo "Creating gallery.html <br />" . $pathToThumbs;

    $output = "<html>";
    $output .= "<head><title>Thumbnails</title></head>";
    $output .= "<body>";
    $output .= "<table cellspacing=\"0\" cellpadding=\"2\" width=\"500\">";
    $output .= "<tr>";

    // open the directory
    $dir = opendir($pathToThumbs);

    $j = 1;
    $counter = 0;
    // loop through the directory
    while (false !== ($fname = readdir($dir))) {
        // strip the . and .. entries out
        $pathToImages = "uploads/projectId";
        $pathToImages = $pathToImages . $j . '/images/';
        if ($fname != '.' && $fname != '..') {
            $output .= "<td valign=\"middle\" align=\"center\"><a href=\"{$pathToImages}{$fname}\">";
            $output .= "<img src=\"{$pathToThumbs}{$fname}\" border=\"0\" />";
            $output .= "</a></td>";

            $counter += 1;
            if ($counter % 4 == 0) {
                $output .= "</tr><tr>";
            }
        }
        $j++;
    }
    // close the directory
    closedir($dir);

    $output .= "</tr>";
    $output .= "</table>";
    $output .= "</body>";
    $output .= "</html>";

    // open the file
    //$file = "gallery.html";
    $file = "gallery.php";
    $fhandle = fopen($file, "w");
    // write the contents of the $output variable to the file
    fwrite($fhandle, $output);
    // close the file
    fclose($fhandle);
    chmod($file, 0777);
}

$demoId = 1;
for ($i = 0; $i < count($array); $i++) {

    if (!file_exists('thumbs/demoId' . $demoId)) {
        mkdir("thumbs/demoId$demoId", 0777, true);
    }

    createThumbs("uploads/$array[$i]/images/", "thumbs/demoId$demoId/", 200);
}


createGallery("uploads/projectId", "thumbs/demoId$demoId/");
//https://alexcican.com/post/how-to-remove-php-html-htm-extensions-with-htaccess/
//http://stackoverflow.com/questions/5831683/how-to-hide-php-from-address-bar
//http://www.codechewing.com/library/hide-file-name-extensions-in-internet-address-bar/
?>