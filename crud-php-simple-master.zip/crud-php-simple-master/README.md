Simple Create, Read, Update, Delete (CRUD) in PHP & MySQL
========

A simple and basic system to add, edit, delete and view using PHP and MySQL. 

Blog Article: [Very simple add, edit, delete, view in PHP & MySQL](http://blog.chapagain.com.np/very-simple-add-edit-delete-view-in-php-mysql/)

SQL script to create database and tables is present in **database.sql** file.

