<?php

// put your code here
require 'db.php';
$i = 1;

$sql = "SELECT * FROM stockDetails ORDER BY Ticker ASC ";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while ($row = mysqli_fetch_assoc($result)) {
        if ($i % 2 != 0)
            echo '<div class="tr">';
        else
            echo '<div class="tr alternate-row">';

        echo "
                                                      <div class='td floatLeft'>" . $row['Google_Stock_Id'] . "	</div>

                                                      <div class='td floatLeft'>" . $row['Ticker'] . "(" . $row['Ticker'] . ")	</div>
                                                      <div class='td floatLeft'>" . $row['Exchange_Name'] . "</div>
                                                      <div class='td floatLeft'>" . $row['Last_Current_Price'] . "</div>
                                                      <div class='td floatLeft'>" . $row['Currency'] . "</div>
                                                      <div class='td floatLeft'>" . $row['Start_Price'] . "</div>
                                                      <div class='td floatLeft'>" . $row['Last_Trade_Time'] . "</div>
                                                      <div class='td floatLeft'>" . $row['Last_Trade_Date'] . "</div>
                                                      <div class='td floatLeft'>" . $row['Change_Value'] . "</div>
                                                      <div class='td floatLeft'>" . $row['Change_Percentage'] .' %'. "</div>";
        //echo '<td><img src="images/chart.png" border="0" onclick="showtrail(\'http://chart.finance.yahoo.com/t?s=' . $row['name'] . '\', \'Live Chart\',90,530)" onmouseover="showtrail(\'http://chart.finance.yahoo.com/t?s=' . $row['name'] . '\', \'Live Chart\',90,530)" onmouseout="hidetrail()"></td>';
        echo "<div class='td floatLeft'><a href='http://www.google.com/finance?client=ig&q=" . $row['Ticker'] . "' target='_blank'>
                                                      Analytics</a></div>
                                                      <div class='td floatLeft chart popup-link-1' data=" . $row['Ticker'] . ">Chart</div>
                                                      <div class='td floatLeft options-width'>
                                                      <a href='cbuy.php?stock=" . $row['Ticker'] . "&p=home&rate=" . $row['Last_Trade_Date'] . "' title='Current Buy' class='icon-1 info-tooltip'/>
                                                      <a href='csell.php?stock=" . $row['Ticker'] . "&p=home&rate=" . $row['Last_Trade_Date'] . "' title='Current Sell' class='icon-2 info-tooltip'/>
                                                      <a href='buy.php?stock=" . $row['Ticker'] . "&p=home' title='Buy' class='icon-3 info-tooltip'/>
                                                      <a href='sell.php?stock=" . $row['Ticker'] . "&p=home' title='Sell' class='icon-4 info-tooltip'/>

                                                      </div>
<div class='clear'></div>                                                      
</div>
                                                      ";
        $i++;
    }
} else {
    echo "0 results";
}
?>

