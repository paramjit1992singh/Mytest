$(document).ready(function () {
    $('body').append('<div id="blackout2"><div id="loading"></div></div>');
    $('#loading').html('<img src="css/default.gif">');
    //alert("hii");
    centerBox2();
    $('#blackout2').show();
    //setInterval("stockMarket();", 1000);  ///////// 10 seconds
    setTimeout("stockMarket();", 1);  ///////// 10 seconds

    function centerBox2() {
        var winWidth = $(window).width();
        var winHeight = $(document).height();
        $('#blackout2').css({'width': winWidth + 'px', 'height': winHeight + 'px'});

        return false;
    }

    $(function () {
        stockMarket = function () {

            $.ajax({
                url: 'updateStockMarketData.php',
                success: function (data) {
                    //alert("data: "+data);

                    //setInterval("getStockMarketData();", 5000);
                    getStockMarketData();
                }
            });


        }


        getStockMarketData = function () {

            $.ajax({
                url: 'getStockMarketData.php',
                success: function (data) {
                    //alert("data: "+data);

                    $(".trParent").html(data);

                    $('#blackout2').hide();

                    $(".chart").click(function () {
                        var data = $(this).attr("data");
                        //alert("clicked: " + data);
                        $(".chartHeader").html("Stock Market Chart For: " + data);
                        $(".chartImage").attr("src", "");
                        $(".chartImage").attr("src", "https://www.google.com/finance/getchart?q=" + data + "&p=20Y&i=86400");
                    });



                    $('body').append('<div id="blackout"></div>');

                    var boxWidth = 400;



                    function centerBox() {

                        var winWidth = $(window).width();
                        var winHeight = $(document).height();
                        var scrollPos = $(window).scrollTop();

                        var disWidth = (winWidth - boxWidth) / 2
                        var disHeight = scrollPos + 150;

                        $('.popup-box').css({'width': 540 + 'px', 'left': 364.5 + 'px', 'top': disHeight + 'px'});
                        $('#blackout').css({'width': winWidth + 'px', 'height': winHeight + 'px'});

                        return false;
                    }


                    $(window).resize(centerBox);
                    $(window).scroll(centerBox);
                    centerBox();

                    $('[class*=popup-link]').click(function (e) {

                        /* Prevent default actions */
                        e.preventDefault();
                        e.stopPropagation();

                        /* Get the id (the number appended to the end of the classes) */
                        var name = $(this).attr('class');
                        var id = name[name.length - 1];
                        var scrollPos = $(window).scrollTop();

                        /* Show the correct popup box, show the blackout and disable scrolling */
                        $('#popup-box-' + id).show();
                        $('#blackout').show();
                        $('html,body').css('overflow', 'hidden');

                        /* Fixes a bug in Firefox */
                        $('html').scrollTop(scrollPos);
                    });
                    $('[class*=popup-box]').click(function (e) {
                        /* Stop the link working normally on click if it's linked to a popup */
                        e.stopPropagation();
                    });

                    $('.close').click(function () {
                        var scrollPos = $(window).scrollTop();
                        /* Similarly, hide the popup and blackout when the user clicks close */
                        $('[id^=popup-box-]').hide();
                        $('#blackout').hide();
                        $("html,body").css("overflow", "auto");
                        $('html').scrollTop(scrollPos);
                    });







                }
            });


        }


    });






});

