<?php

error_reporting(E_ALL ^ E_NOTICE);
require 'db.php';
$sql = "SELECT Ticker FROM stockDetails WHERE 1";
$result = mysqli_query($conn, $sql);
$tickerArray = array();

function clean($string) {
    $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

    return preg_replace('/[^A-Za-z0-9-+.:\-]/', '', $string); // Removes special chars.
}

if (mysqli_num_rows($result) > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
        $tickerArray[] = $row['Ticker'];
    }

    $var = '';
    $tickerString = implode(',', $tickerArray);
    $recordName_array = array();
    $recordValue_array = array();

    $data = file_get_contents('http://finance.google.com/finance/info?client=ig&q=' . $tickerString);
    $data = substr($data, 3, strlen($data));
    //echo $data;
    $jsonIterator = new RecursiveIteratorIterator(
            new RecursiveArrayIterator(json_decode($data, TRUE)), RecursiveIteratorIterator::SELF_FIRST);

    $i = 0;
    //$recordName_array[$i] = array();
    foreach ($jsonIterator as $key => $val) {
        if (is_array($val)) {
            //echo "key::::$key:\n";
        } else {
            //echo "$key => $val\n";
            $recordName_array[] = $key;
            $recordValue_array[] = $val;
        }
    }



    $recordName_array = array_chunk($recordName_array, 16);
    $recordValue_array = array_chunk($recordValue_array, 16);


    for ($k = 0; $k < count($tickerArray); $k++) {
        $sql2 = '';

        if ($recordValue_array[$k][2] == 'NASDAQ' || $recordValue_array[$k][2] == 'NYSE' || $recordValue_array[$k][2] == 'AMEX') {

            $sql2 = "UPDATE stockDetails SET Google_Stock_Id='" . $recordValue_array[$k][0] . "'"
                    . ", Exchange_Name='" . $recordValue_array[$k][2] . "'"
                    . ", Last_Price='" . $recordValue_array[$k][3] . "'"
                    . ", Currency='USD'"
                    . ", Last_Fixed_Price='" . $recordValue_array[$k][4] . "'"
                    . ", Last_Current_Price='" . $recordValue_array[$k][5] . "'"
                    . ", Start_Price='" . $recordValue_array[$k][6] . "'"
                    . ", Last_Trade_Time='" . $recordValue_array[$k][7] . "'"
                    . ", Last_Trade_Date='" . strtok($recordValue_array[$k][9], 'T') . "'"
                    . ", Last_Trade_TimeStamp='" . $recordValue_array[$k][9] . "'"
                    . ", Change_Value='" . $recordValue_array[$k][10] . "'"
                    . ", Change_Fix='" . $recordValue_array[$k][11] . "'"
                    . ", Change_Percentage='" . $recordValue_array[$k][12] . "'"
                    . ", Change_Percentage_Fix='" . $recordValue_array[$k][13] . "'"
                    . ", ccol='" . $recordValue_array[$k][14] . "'"
                    . ", pcls_fix='" . $recordValue_array[$k][15] . "'"
                    . " WHERE Ticker='" . $recordValue_array[$k][1] . "'";
        } elseif ($recordValue_array[$k][2] == 'NSE') {
            $data.=$recordValue_array[$k][13] . "      ";

            $sql2 = "UPDATE stockDetails SET Google_Stock_Id='" . $recordValue_array[$k][0] . "'"
                    . ", Exchange_Name='" . $recordValue_array[$k][2] . "'"
                    . ", Last_Price='" . $recordValue_array[$k][3] . "'"
                    . ", Currency='INR'"
                    . ", Last_Fixed_Price='" . $recordValue_array[$k][4] . "'"
                    . ", Last_Current_Price='" . $recordValue_array[$k][5] . "'"
                    . ", Start_Price='" . $recordValue_array[$k][6] . "'"
                    . ", Last_Trade_Time='" . $recordValue_array[$k][7] . "'"
                    . ", Last_Trade_Date='" . strtok($recordValue_array[$k][9], 'T') . "'"
                    . ", Last_Trade_TimeStamp='" . $recordValue_array[$k][9] . "'"
                    . ", Change_Value='" . $recordValue_array[$k][10] . "'"
                    . ", Change_Fix='" . $recordValue_array[$k][11] . "'"
                    . ", Change_Percentage='" . $recordValue_array[$k][12] . "'"
                    . ", Change_Percentage_Fix='" . $recordValue_array[$k][13] . "'"
                    . ", ccol='" . $recordValue_array[$k][14] . "'"
                    . ", pcls_fix='" . $recordValue_array[$k][15] . "'"
                    . " WHERE Ticker='" . $recordValue_array[$k][1] . "'";
        }

        //echo 'data::::' . $data;

        if (mysqli_query($conn, $sql2)) {
            echo "Record updated successfully";
            //echo $sql3;
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }




//echo "recordValue_array::::".$recordValue_array[1][3];
//echo "recordName_array::::".$recordName_array[1][3];
    //echo implode(',', $tickerArray);
} else {
    echo "0 results";
}



mysqli_close($conn);
?>