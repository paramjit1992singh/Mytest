<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <?php
        error_reporting(E_ALL ^ E_NOTICE);
        require 'db.php';
        ?>
    </head>
    <script src="js/jquery-1.12.3.min.js" type="text/javascript"></script>
    <script src="js/script.js" type="text/javascript"></script>
    <link href="css/style.css" rel="stylesheet" type="text/css"/>
    <body>
        <?php /*
          $sql = "SELECT Ticker FROM stockDetails WHERE 1";
          $result = mysqli_query($conn, $sql);
          $tickerArray = array();

          function clean($string) {
          $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

          return preg_replace('/[^A-Za-z0-9-+.:\-]/', '', $string); // Removes special chars.
          }

          if (mysqli_num_rows($result) > 0) {

          while ($row = mysqli_fetch_assoc($result)) {
          $tickerArray[] = $row['Ticker'];
          }

          $var = '';
          for ($i = 0; $i < count($tickerArray); $i++) {
          $recordValue_array = array();
          $recordName_array = array();

          $data = file_get_contents('http://finance.google.com/finance/info?client=ig&q=NSE:' . $tickerArray[$i]);

          $data = substr($data, 7, strlen($data) - 7 - 4);
          $records = explode(',', $data);
          for ($j = 0; $j < count($records); $j++) {
          $pair = explode(": ", $records[$j]);
          $var = trim($pair[1], '"');
          $var = trim($var, '" ');
          $var = clean($var);
          $recordName_array[] = clean($pair[0]);
          $recordValue_array[] = $var;
          }



          $sql2 = "UPDATE stockDetails SET Google_Stock_Id='" . $recordValue_array[0] . "'"
          . ", Exchange_Name='" . $recordValue_array[2] . "'"
          . ", Last_Price='" . $recordValue_array[3] . "'"
          . ", Currency='INR'"
          . ", Last_Fixed_Price='" . $recordValue_array[4] . "'"
          . ", Last_Current_Price='" . $recordValue_array[5] . "'"
          . ", Start_Price='" . $recordValue_array[6] . "'"
          . ", Last_Trade_Time='" . str_replace("ltt", "", $recordName_array[7]). "'"
          . ", Last_Trade_Date='" .  strtok($recordValue_array[10] , 'T'). "'"
          . ", Last_Trade_TimeStamp='" . $recordValue_array[10] . "'"
          . ", Change_Value='" . $recordValue_array[11] . "'"
          . ", Change_Fix='" . $recordValue_array[12] . "'"
          . ", Change_Percentage='" . $recordValue_array[13] . "'"
          . ", Change_Percentage_Fix='" . $recordValue_array[14] . "'"
          . ", ccol='" . $recordValue_array[15] . "'"
          . ", pcls_fix='" . $recordValue_array[16] . "'"
          . " WHERE Ticker='" . $recordValue_array[1] . "'";

          if (mysqli_query($conn, $sql2)) {
          echo "Record updated successfully";
          } else {
          echo "Error updating record: " . mysqli_error($conn);
          }
          }






          echo implode(',', $tickerArray);
          } else {
          echo "0 results";
          }



          mysqli_close($conn);
         */ ?>

        <div class="mainClass">

            <div class="charts">
                <div class="chart1"><a href="https://www.google.com/finance?cid=207437" target="_blank">NIFTY</a></div>
                <div class="chart2"><a href="https://www.google.com/finance?cid=15173681" target="_blank">S&P BSE SENSEX</a></div>

            </div>

            <div class="table">
                <div class="thParent">

                    <div class="th floatLeft">Google Stock Id</div>   
                    <div class="th floatLeft">Ticker</div>   
                    <div class="th floatLeft">Exchange Name</div>   
                    <div class="th floatLeft">Last Closing Price</div>   
                    <div class="th floatLeft">Currency</div>   
                    <div class="th floatLeft">Start Price</div>   
                    <div class="th floatLeft">Last Trade Time</div>   
                    <div class="th floatLeft">Last Trade Date</div>   
                    <div class="th floatLeft">Change Value</div>   
                    <div class="th floatLeft">Change Percentage</div>
                    <div class="th floatLeft">Analytics</div>
                    <div class="th floatLeft">Chart</div>
                    <div class="th floatLeft">Options</div>
                    <div class="clear"></div>
                </div>
                <div class="trParent">


                </div>

            </div>


            <div class="popup-box" id="popup-box-1">
                <div class="close">X</div>
                <div class="top">
                    <div class="chartHeader">Stock Market Chart For: </div>
                </div>
                <div class="bottom">
                <div><img class="chartImage" src="" />
                </div>
                </div>
            </div>

        </div>







        <?php
// put your code here
        ?>
    </body>
</html>
