-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2016 at 02:33 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockMarketApplication`
--

-- --------------------------------------------------------

--
-- Table structure for table `stockDetails`
--

CREATE TABLE `stockDetails` (
  `id` int(11) NOT NULL,
  `Google_Stock_Id` varchar(100) NOT NULL,
  `Ticker` varchar(100) NOT NULL,
  `Exchange_Name` varchar(100) NOT NULL,
  `Last_Price` varchar(100) NOT NULL,
  `Currency` varchar(100) NOT NULL,
  `Last_Fixed_Price` varchar(100) NOT NULL,
  `Last_Current_Price` varchar(100) NOT NULL,
  `Start_Price` varchar(100) NOT NULL,
  `Last_Trade_Time` varchar(100) NOT NULL,
  `Last_Trade_Date` varchar(100) NOT NULL,
  `Last_Trade_TimeStamp` varchar(100) NOT NULL,
  `Change_Value` varchar(100) NOT NULL,
  `Change_Fix` varchar(100) NOT NULL,
  `Change_Percentage` varchar(100) NOT NULL,
  `Change_Percentage_Fix` varchar(100) NOT NULL,
  `ccol` varchar(100) NOT NULL,
  `pcls_fix` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stockDetails`
--

INSERT INTO `stockDetails` (`id`, `Google_Stock_Id`, `Ticker`, `Exchange_Name`, `Last_Price`, `Currency`, `Last_Fixed_Price`, `Last_Current_Price`, `Start_Price`, `Last_Trade_Time`, `Last_Trade_Date`, `Last_Trade_TimeStamp`, `Change_Value`, `Change_Fix`, `Change_Percentage`, `Change_Percentage_Fix`, `ccol`, `pcls_fix`) VALUES
(1, '16134436', 'COALINDIA', 'NSE', '277.50', 'INR', '277.50', 'Rs.277.50', '0', '3:40PM GMT+5:30', '2016-04-13', '2016-04-13T15:40:56Z', '+3.10', '3.10', '1.13', '1.13', 'chg', '274.4'),
(2, '9708440', 'TATAMOTORS', 'NSE', '408.65', 'INR', '408.65', 'Rs.408.65', '0', '3:40PM GMT+5:30', '2016-04-13', '2016-04-13T15:40:48Z', '+12.85', '12.85', '3.25', '3.25', 'chg', '395.8'),
(3, '5301348', 'TATAPOWER', 'NSE', '69.95', 'INR', '69.95', 'Rs.69.95', '0', '3:54PM GMT+5:30', '2016-04-13', '2016-04-13T15:54:03Z', '+2.10', '2.10', '3.10', '3.10', 'chg', '67.85'),
(4, '11539104', 'TATASTEEL', 'NSE', '332.55', 'INR', '332.55', 'Rs.332.55', '0', '3:50PM GMT+5:30', '2016-04-13', '2016-04-13T15:50:12Z', '+8.05', '8.05', '2.48', '2.48', 'chg', '324.5'),
(5, '22144', 'AAPL', 'NASDAQ', '109.85', 'USD', '109.85', '109.85', '0', '4:00PM EDT', '2016-04-15', '2016-04-15T16:00:02Z', '-2.25', '-2.25', '-2.01', '-2.01', 'chr', '112.1'),
(6, '304466804484872', 'GOOG', 'NASDAQ', '759.00', 'USD', '759.00', '759.00', '0', '4:00PM EDT', '2016-04-15', '2016-04-15T16:00:01Z', '+5.80', '5.80', '0.77', '0.77', 'chg', '753.2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stockDetails`
--
ALTER TABLE `stockDetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stockDetails`
--
ALTER TABLE `stockDetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
