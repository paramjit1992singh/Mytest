var path = require('path');
var pdfUtil = require('pdf-to-text');
var pdf_path = path.join(__dirname, 'data/data.pdf');

//Omit option to extract all text from the pdf file
pdfUtil.pdfToText(pdf_path, function(err, data) {
    if (err) throw(err);
    console.log(data); //print all text
});
