$(document).ready(function () {

    $.ajax({
        type: 'post',
        url: 'getData.php',
        success: function (response) {
            //alert("response: " + response);
            $(".playersList").html(response);

            $("input[type='checkbox']").change(function () {

                var maxAllowed = 4;

                var cnt = $("input[type='checkbox']:checked").length;

                if (cnt > maxAllowed)

                {

                    $(this).prop("checked", "");

                    alert('Select maximum ' + maxAllowed + ' Players!');

                }

            });

            var target = 0;

            $(".teams").click(function () {

                target = $(this).attr("target");

                var noOfDivChildren = $(".team" + target).children().size();
                var noOfCheckedCheckboxes = $("#playersList input:checkbox:checked").length;
                var sum = noOfDivChildren + noOfCheckedCheckboxes;
                //alert("noOfDivChildren: " + noOfDivChildren);
                //alert("noOfCheckedCheckboxes: " + noOfCheckedCheckboxes);



                if (noOfCheckedCheckboxes > 0)
                {
                    //alert("sum: " + sum);
                    //alert("target: "+target);
                    //if (noOfDivChildren < 4 && sum == 4) {
                    if (sum <= 4) {

                        $(".teamsSet").removeClass("currentSelectedTeam");
                        $(".team" + target).addClass("currentSelectedTeam");

                        $(".addToTeam").removeClass("activateAddToTeam");
                        $(".addToTeam" + target).addClass("activateAddToTeam");

                        alert("You Can Add These Players");
                        //limitSelectiongCheckboxex();
                        //limitSelectiongCheckboxex2();

                    } else {
                        alert("Each Team Can Hold Only 4 Players");
                    }

                } else
                {
                    alert("select some players");
                }



            });

            $(".addToTeam").click(function () {
                if ($(this).hasClass("activateAddToTeam")) {

                    var noOfDivChildren = $(".team" + target).children().size();
                    var noOfCheckedCheckboxes = $("#playersList input:checkbox:checked").length;
                    var sum = noOfDivChildren + noOfCheckedCheckboxes;
                    //alert("noOfDivChildren: " + noOfDivChildren);
                    //alert("noOfCheckedCheckboxes: " + noOfCheckedCheckboxes);


                    if (noOfCheckedCheckboxes > 0)
                    {
                        //alert("sum: " + sum);
                        //alert("target: "+target);
                        //if (noOfDivChildren < 4 && sum == 4) {
                        if (sum <= 4) {


                            var selectedIds = $("#playersList :checkbox:checked").map(function () {
                                return $(this).val();
                            }).get();
                            alert(selectedIds);

                            $.each(selectedIds, function (i, val) {
                                $(".team" + target).append("<div target2=" + val + "><div class='btn btn-default' style='width: 35%;'>" + val + "</div><select class='selectTag'><option value='volvo'>Volvo</option><option value='saab'>Saab</option><option value='opel'>Opel</option><option value='audi'>Audi</option></select><div class='btn btn-primary edit'>Edit</div><div class='btn btn-danger remove'>Remove</div><div class='clear'></div></div>");
                            });

                            $(".checkbox input:checked").parent().remove();
                            $(".teamsSet").removeClass("currentSelectedTeam");
                            $(".addToTeam").removeClass("activateAddToTeam");

                            alert("Players Added");
                            $('#playersList').find('input[type=checkbox]:checked').removeAttr('checked');


                        } else {
                            alert("Each Team Can Hold Only 4 Players");
                        }

                    } else
                    {
                        alert("select some players");
                    }

                    $(".remove").click(function (e) {
                        alert("remove clicked");
                        var target2 = $(this).parent().attr("target2");
                        alert("target2: " + target2);
                        $("#playersList").append("<label class='checkbox'><input id=" + target2 + "  class='playerDataClass single-checkbox' value=" + target2 + " type='checkbox'>" + target2 + "</label>");
                        $(this).parent().remove();
                        e.stopPropagation();
                    });


                    $('.selectTag').click(function (e) {
                        e.stopPropagation();
                        var value = $(this).val();
                    });

                    $('.selectTag').change(function (e) {
                        e.stopPropagation();
                        var value = $(this).val();
                    });



                } else
                {
                    if ($("#playersList input:checkbox:checked").length > 0) {
                        alert("select some team");
                    } else {
                        alert("select some players");
                    }

                }




            });



        }

    });




});


