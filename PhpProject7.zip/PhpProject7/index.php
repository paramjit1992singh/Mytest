<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap-responsive.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-1.12.3.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/script.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
        //echo "hello";
        ?>


        <div class="container-fluid">
            <div class="container-left floatLeft">

                <ul id="playersList" class="playersList" style="list-style: none;">


                </ul>

            </div>

            <div class="container-middle floatLeft">

                <div class="addToTeam addToTeam1">Add To Team 1</div>
                <div class="addToTeam addToTeam2">Add To Team 2</div>
                <div class="addToTeam addToTeam3">Add To Team 3</div>
                <div class="addToTeam addToTeam4">Add To Team 4</div>

            </div>

            <div class="container-right floatLeft">
                <div class="teams" target="1">Team1: <div class="teamsSet team1"></div></div>
                <div class="teams" target="2">Team2: <div class="teamsSet team2"></div></div>
                <div class="teams" target="3">Team3: <div class="teamsSet team3"></div></div>
                <div class="teams" target="4">Team4: <div class="teamsSet team4"></div></div>
            </div>
            <div class="clear"></div>

        </div>
    </body>
</html>
