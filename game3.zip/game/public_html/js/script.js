$(document).ready(function () {
    var $el;
    var html;
    var txt;
    var txtLen;
    var timeOut;
    var char = 0;

    $('.mag').on('click', function () {
        if ($(this).hasClass("glass1")) {
            $el = $('#map-1 .typing');
            html = $.trim($(".mag1Text").html());
        }
        if ($(this).hasClass("glass2")) {
            $el = $('#map-2 .typing');
            html = $.trim($(".mag2Text").html());
        }
        if ($(this).hasClass("glass3")) {
            $el = $('#map-3 .typing');
            html = $.trim($(".mag3Text").html());
        }
        if ($(this).hasClass("glass4")) {
            $el = $('#map-4 .typing');
            html = $.trim($(".mag4Text").html());
        }
        if ($(this).hasClass("glass5")) {
            $el = $('#map-5 .typing');
            html = $.trim($(".mag5Text").html());
        }
        if ($(this).hasClass("glass6")) {
            $el = $('#map-6 .typing');
            html = $.trim($(".mag6Text").html());
        }
        if ($(this).hasClass("glass7")) {
            $el = $('#map-7 .typing');
            html = $.trim($(".mag7Text").html());
        }
        if ($(this).hasClass("glass8")) {
            $el = $('#map-8 .typing');
            html = $.trim($(".mag8Text").html());
        }
        
        $(".mag").hide();
        $(".overlay").show();
        $(".map-title, .map-desc, .v-line, .h-line").hide();
        $('#' + $(this).data('map-id')).show(500);


        txtLen = html.length;
        timeOut;
        char = 0;
        $el.text('|');
        typeIt();
    });

    $(".overlay").on("click", function () {
        $(".mag").show();
        $(".universal_map").fadeOut('fast');
        $(".overlay").hide();
        $(".map-title, .map-desc, .v-line, .h-line").show();
        clearTimeout(timeOut);


    });

    $(".universal_map").on("click", function () {
        $(this).fadeOut();
        $(".mag").show();
        $(".overlay").hide();
        $(".map-title, .map-desc, .v-line, .h-line").show();
        clearTimeout(timeOut);


    });

    function typeIt() {
        var humanize = Math.round(Math.random() * (100 - 50)) + 50;
        timeOut = setTimeout(function () {
            char++;
            var type = html.substring(0, char);
            //console.log(type);
            $el.html(type + '|');
            typeIt();

            if (char == txtLen) {
                $el.html($el.html().slice(0, -1)); // remove the '|'
                clearTimeout(timeOut);
            }

        }, humanize);
    }

});



document.onreadystatechange = function () {
    var state = document.readyState
    if (state == 'interactive') {
        document.getElementById('container').style.visibility = "hidden";
    } else if (state == 'complete') {
        setTimeout(function () {
            document.getElementById('interactive');
            document.getElementById('load').style.visibility = "hidden";
            document.getElementById('container').style.visibility = "visible";
        }, 1150);
    }
}

$(document).ready(function () {
    if ($(window).width() > 1024) {
        $(".zoomContainer").mousemove(function (event) {
            var pageCoords = "( " + event.pageX + ", " + event.pageY + " )";
            $(".h-line").css('top', event.pageY + 'px');
            $(".v-line").css('left', event.pageX + 'px');

        });
    }
});