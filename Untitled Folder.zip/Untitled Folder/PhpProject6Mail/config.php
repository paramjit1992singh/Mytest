<?php
/* Script Ayarları */

// smtp ayarları
define("SMTP_HOST", '');
define("SMTP_USERNAME", '');
define("SMTP_PASSWORD", '');
define("SMTP_PORT", '');

?>