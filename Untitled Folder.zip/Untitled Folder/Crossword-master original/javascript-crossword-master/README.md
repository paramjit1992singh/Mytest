javascript-crossword
====================

A browser-based crossword puzzle implemented in JavaScript.

The puzzle data is in json format in puzzle.js. Open index.html in a browser to view.
