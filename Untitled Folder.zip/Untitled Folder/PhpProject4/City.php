
<?php

$conn = mysql_connect("localhost", "root", "");
$db = mysql_select_db("testdb", $conn);

$id = $_REQUEST['id'];
//$sql_city = "SELECT project_info FROM projects WHERE id = '".$id."'";
$sql_city = "SELECT Project.project_name ,Risk.* FROM Project INNER JOIN Risk on Risk.project_Id ='".$id."'";
//$result_city = mysql_result(mysql_query($sql_city),0);
//$result_city = mysql_query($sql) or die(mysql_error());


//echo '<div>'.  $result_city.'</div>';

//$sql = "SELECT * FROM cartable";
$result = mysql_query($sql_city) or die(mysql_error());

// Print the column names as the headers of a table
echo "<table><tr>";
for($i = 0; $i < mysql_num_fields($result); $i++) {
    $field_info = mysql_fetch_field($result, $i);
    echo "<th>{$field_info->name}</th>";
}

// Print the data
while($row = mysql_fetch_row($result)) {
    echo "<tr>";
    foreach($row as $_column) {
        echo "<td>{$_column}</td>";
    }
    echo "</tr>";
}

echo "</table>";


/*
echo "<select name='city'>";
while($row_city = mysql_fetch_array($result_city))
{
    echo "<option value='".$row_city['id']."'>".$row_city['project']."</option>";
}
echo "</select>";*/
?>