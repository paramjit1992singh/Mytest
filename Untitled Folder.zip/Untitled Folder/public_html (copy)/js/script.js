(function ($) {
    $(function () {
        var puzzleData = [
            {
                clue: "Capital of Afghanistan:Kabul",
                answer: "Kabul",
                position: 1,
                orientation: "across",
                startx: 1,
                starty: 1
            },
            {
                clue: "Belgium:Brussels",
                answer: "Brussels",
                position: 3,
                orientation: "across",
                startx: 7,
                starty: 1
            },
            {
                clue: "Canada:Ottawa",
                answer: "Ottawa",
                position: 5,
                orientation: "across",
                startx: 1,
                starty: 3
            },
            {
                clue: "Denmark:Copenhagen",
                answer: "Copenhagen",
                position: 8,
                orientation: "across",
                startx: 1,
                starty: 5
            },
            {
                clue: "Finland:Helsinki",
                answer: "Helsinki",
                position: 10,
                orientation: "across",
                startx: 2,
                starty: 7
            },
            {
                clue: "Germany:Berlin",
                answer: "Berlin",
                position: 13,
                orientation: "across",
                startx: 1,
                starty: 9
            },
            {
                clue: "Israel:Jerusalem",
                answer: "Jerusalem",
                position: 16,
                orientation: "across",
                startx: 1,
                starty: 11
            },
            {
                clue: "Japan:Tokyo",
                answer: "Tokyo",
                position: 17,
                orientation: "across",
                startx: 7,
                starty: 11
            },
            {
                clue: "Pakistan:Islamabad",
                answer: "Islamabad",
                position: 1,
                orientation: "down",
                startx: 1,
                starty: 1
            },
            {
                clue: "Russia",
                answer: "Moscow",
                position: 2,
                orientation: "down",
                startx: 5,
                starty: 1
            },
            {
                clue: "Control system strategy that tries to replicate the human through process (abbr.)",
                answer: "ann",
                position: 4,
                orientation: "down",
                startx: 9,
                starty: 1
            },
            {
                clue: "Greek variable that usually describes rotor positon",
                answer: "theta",
                position: 6,
                orientation: "down",
                startx: 7,
                starty: 3
            },
            {
                clue: "Electromagnetic (abbr.)",
                answer: "em",
                position: 7,
                orientation: "down",
                startx: 11,
                starty: 3
            },
            {
                clue: "No. 13 across does this to a voltage",
                answer: "steps",
                position: 9,
                orientation: "down",
                startx: 5,
                starty: 5
            },
            {
                clue: "Emits a lout wailing sound",
                answer: "siren",
                position: 11,
                orientation: "down",
                startx: 11,
                starty: 7
            },
            {
                clue: "Information technology (abbr.)",
                answer: "it",
                position: 12,
                orientation: "down",
                startx: 1,
                starty: 8
            },
            {
                clue: "Asynchronous transfer mode (abbr.)",
                answer: "atm",
                position: 14,
                orientation: "down",
                startx: 3,
                starty: 9
            },
            {
                clue: "Offset current control (abbr.)",
                answer: "occ",
                position: 15,
                orientation: "down",
                startx: 7,
                starty: 9
            }
	

        ]

        $('#puzzle-wrapper').crossword(puzzleData);

    })

})(jQuery)
