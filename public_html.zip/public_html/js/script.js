document.getElementById('links').onclick = function (event) {
    event = event || window.event;
    var target = event.target || event.srcElement,
            link = target.src ? target.parentNode : target,
            options = {
                index: link,
                event: event
            },
    links = this.getElementsByTagName('a');
    blueimp.Gallery(links, options);
};


$(document).ready(function () {

    var data = [["http://placehold.it/400x400&text=Photo+1", "http://placehold.it/400x400&text=Photo+2", "http://placehold.it/400x400&text=Photo+3", "http://placehold.it/400x400&text=Photo+4"],
        ["http://placehold.it/400x400&text=Photo+5", "http://placehold.it/400x400&text=Photo+6", "http://placehold.it/400x400&text=Photo+7", "http://placehold.it/400x400&text=Photo+8"],
        ["http://placehold.it/400x400&text=Photo+9", "http://placehold.it/400x400&text=Photo+10", "http://placehold.it/400x400&text=Photo+11", "http://placehold.it/400x400&text=Photo+12"],
        ["http://placehold.it/400x400&text=Photo+13", "http://placehold.it/400x400&text=Photo+14", "http://placehold.it/400x400&text=Photo+15", "http://placehold.it/400x400&text=Photo+16"]];


    var dataThumb = [["http://placehold.it/100x100&text=Thumbnail-1", "http://placehold.it/100x100&text=Thumbnail-2", "http://placehold.it/100x100&text=Thumbnail-3", "http://placehold.it/100x100&text=Thumbnail-4"],
        ["http://placehold.it/100x100&text=Thumbnail-5", "http://placehold.it/100x100&text=Thumbnail-6", "http://placehold.it/100x100&text=Thumbnail-7", "http://placehold.it/100x100&text=Thumbnail-8"],
        ["http://placehold.it/100x100&text=Thumbnail-9", "http://placehold.it/100x100&text=Thumbnail-10", "http://placehold.it/100x100&text=Thumbnail-11", "http://placehold.it/100x100&text=Thumbnail-12"],
        ["http://placehold.it/100x100&text=Thumbnail-13", "http://placehold.it/100x100&text=Thumbnail-14", "http://placehold.it/100x100&text=Thumbnail-15", "http://placehold.it/100x100&text=Thumbnail-16"]];




    $(".divData").click(function () {

        var target2 = $(this).attr("target");
        alert("target: " + target2);
        target2 = target2 - 1;

        $("#links1row").html(" ");

        for (var i = 0; i < data[target2].length; i++) {

            $("#links1row").append("<a href='" + data[target2][i] + "' title='Banana'><div class='floatLeft thumbs'><img src='" + dataThumb[target2][i] + "'  alt='Banana' class='img-thumbnail'></div></a>");

        }

        $("#links1row").append("<div class='clear'></div>")

    });



});
