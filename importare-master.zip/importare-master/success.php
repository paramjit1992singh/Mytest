<?php
echo "Records have been successfully imported";
 ?>
