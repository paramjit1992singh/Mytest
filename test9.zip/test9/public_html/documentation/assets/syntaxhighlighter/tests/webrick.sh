#!/bin/sh
ruby webrick.rb
