$(document).ready(function () {
    $("#submitBtn").click(function () {
        var firstName = $.trim($(".text6span2").val());
        var gender = $.trim($(".text7span2 #gender").val());
        var age = $.trim($(".text8span2").val());
        var mearning = $.trim($(".text9span2").val());
        var mexpenses = $.trim($(".text10span2").val());
        var rAge = 60;
        if (firstName.length && gender.length && age.length && mearning.length
                && mexpenses.length) { // zero-length string AFTER a trim
            console.log(firstName);
            console.log(gender);
            console.log(age);
            console.log(mearning);
            console.log(mexpenses);

            var jsonData = {
                "data": [
                    {
                        "page": 1,
                        "image": [
                            {
                                "male": "images/Retirement_Assets/Screen_2.jpg"
                            },
                            {
                                "female": "images/Retirement_Assets/Screen_2_2\n\
.jpg"
                            }
                        ],
                        "image_transition": "random",
                        "captions": [
                            {
                                "caption": 1,
                                "x_position": "76",
                                "y_position": "176",
                                "data": "Hello " + firstName + " !",
                                "data_transition": "expandDown"
                            }, {
                                "caption": 2,
                                "x_position": "76",
                                "y_position": "272",
                                "data": "Did you know that when you retire in <span style='color:rgb(0,51,160);'>" + (rAge - age) + "</span> years, you will need Rs. <span style='color:rgb(0,51,160);'>" + (mearning - mexpenses) + "</span> every month to live the life you are living now?",
                                "data_transition": "expandDown"
                            }
                        ]

                    }, {
                        "page": 2,
                        "image": [
                            {
                                "male": "images/Retirement_Assets/Screen_3.jpg"
                            },
                            {
                                "female": "images/Retirement_Assets/Screen_3.jpg"
                            }
                        ],
                        "image_transition": "random",
                        "captions": [
                            {
                                "caption": 1,
                                "x_position": "49",
                                "y_position": "265",
                                "data": "And you should have Rs. " + mearning + " in your bank account <br><span style='font-size: 20px;'>to splurge a bit and be secure or incidents?</span>",
                                "data_transition": "expandLeft"
                            }
                        ]
                    }, {
                        "page": 3,
                        "image": [
                            {
                                "male": "images/Retirement_Assets/Screen_4.jpg"
                            },
                            {
                                "female": "images/Retirement_Assets/Screen_4.jpg"
                            }
                        ],
                        "image_transition": "random",
                        "captions": [
                            {
                                "caption": 1,
                                "x_position": "545",
                                "y_position": "195",
                                "data": "For that, " + firstName + " you need to start today",
                                "data_transition": "expandRight"
                            },
                            {
                                "caption": 2,
                                "x_position": "545",
                                "y_position": "218",
                                "data": "and save Rs. " + mexpenses + " every month!",
                                "data_transition": "expandRight"
                            }
                        ]
                    }, {
                        "page": 4,
                        "image": [
                            {
                                "male": "images/Retirement_Assets/Screen_5.jpg"
                            },
                            {
                                "female": "images/Retirement_Assets/Screen_5.jpg"
                            }
                        ],
                        "image_transition": "random",
                        "captions": [
                            {
                                "caption": 1,
                                "x_position": "52",
                                "y_position": "180",
                                "data": "Take a closer look at your avaliable",
                                "data_transition": "expandLeft"
                            },
                            {
                                "caption": 2,
                                "x_position": "52",
                                "y_position": "200",
                                "data": "saving and earning options",
                                "data_transition": "expandLeft"
                            }
                        ]
                    }, {
                        "page": 5,
                        "image": [
                            {
                                "male": "images/Retirement_Assets/Screen_6.jpg"
                            },
                            {
                                "female": "images/Retirement_Assets/Screen_6.jpg"
                            }
                        ],
                        "image_transition": "random",
                        "captions": [
                            {
                                "caption": 1,
                                "x_position": "52",
                                "y_position": "290",
                                "data": "Talk to financial experts on how best you can",
                                "data_transition": "expandLeft"
                            },
                            {
                                "caption": 2,
                                "x_position": "52",
                                "y_position": "310",
                                "data": "grow and use your hard earned money",
                                "data_transition": "expandLeft"
                            }
                        ]
                    }, {
                        "page": 6,
                        "image": [
                            {
                                "male": "images/Retirement_Assets/Screen_7.jpg"
                            },
                            {
                                "female": "images/Retirement_Assets/Screen_7.jpg"
                            }
                        ],
                        "image_transition": "random",
                        "captions": [
                            {
                                "caption": 1,
                                "x_position": "466",
                                "y_position": "132",
                                "data": "And plan your retirement for a good life even after you stop working.",
                                "data_transition": "expandLeft"
                            }
                        ]
                    }, {
                        "page": 7,
                        "image": [
                            {
                                "male": "images/Retirement_Assets/Screen_8.jpg"
                            },
                            {
                                "female": "images/Retirement_Assets/Screen_8.jpg"
                            }
                        ],
                        "image_transition": "random",
                        "captions": [
                            {
                                "caption": 1,
                                "x_position": "52",
                                "y_position": "200",
                                "data": "So what are you waiting for?<br>It's never to late to plan your retirement!",
                                "data_transition": "expandLeft"
                            },{
                                "caption": 2,
                                "x_position": "52",
                                "y_position": "256",
                                "data": "Start today!",
                                "data_transition": "expandLeft"
                            }
                        ]
                    }
                ]
            };


            $(".introScreen").hide();
            $("#cont").show();

            var htmlText = "", indexValue = 1;
            $('#cont .container #iview').html("");

            $.each(jsonData.data, function (index, element) {

                htmlText = "";

                if (gender == "Male") {
                    console.log("hii");
                    htmlText = '<div data-iview:thumbnail="' + element.image[0].male + '" data-iview:image="' + element.image[0].male + '" data-iview:transition="' + element.image_transition + '">';
                } else {
                    htmlText = '<div data-iview:thumbnail="' + element.image[1].female + '" data-iview:image="' + element.image[1].female + '" data-iview:transition="' + element.image_transition + '">';
                }

                $.each(element.captions, function (index, ele) {
                    console.log(ele);
                    htmlText += '<div class="iview-caption caption' + indexValue + '" data-x="' + ele.x_position + '" data-y="' + ele.y_position + '" data-width="auto" data-transition="' + ele.data_transition + '">' + ele.data + '</div>';
                    indexValue++;
                });

                htmlText += "</div>";

                console.log("htmlText: " + htmlText);
                $('#cont .container #iview').append(htmlText);

            });


//            $.ajax({
//                type: 'GET',
//                url: jsonData,
//                data: {get_param: 'value'},
//                dataType: 'json',
//                async: false,
//                success: function (data) {
//                    console.log(data);
//                    $.each(data.data, function (index, element) {
//
//                        //console.log(element);
//
//                        htmlText = "";
//
//                        if (gender == "Male") {
//                            alert("hii");
//                            htmlText = '<div data-iview:thumbnail="' + element.image[0].male + '" data-iview:image="' + element.image[0].male + '" data-iview:transition="' + element.image_transition + '">';
//                        } else {
//                            htmlText = '<div data-iview:thumbnail="' + element.image[1].female + '" data-iview:image="' + element.image[1].female + '" data-iview:transition="' + element.image_transition + '">';
//                        }
//
//                        $.each(element.captions, function (index, ele) {
//                            console.log(ele);
//                            htmlText += '<div class="iview-caption caption' + indexValue + '" data-x="' + ele.x_position + '" data-y="' + ele.y_position + '" data-width="auto" data-transition="' + ele.data_transition + '">' + ele.data + '</div>';
//                            indexValue++;
//                        });
//
//                        htmlText += "</div>";
//
//                        console.log("htmlText: " + htmlText);
//                        $('#cont .container #iview').append(htmlText);
//
//                    });
//                }
//            });


            $('#iview').iView({
//                    pauseTime: 3000,
//                    pauseOnHover: false,
//                    directionNavHoverOpacity: 0,
////                    timer: "Pie",
////                    timerDiameter: "50%",
////                    timerPadding: 0,
////                    timerStroke: 7,
////                    timerBarStroke: 0,
////                    timerColor: "#FFF",
////                    timerPosition: "bottom-right"
//                    directionNav: true,
//                    controlNav: true,
//                    tooltipY: -100

                fx: 'random', // Specify sets like: 'left-curtain,fade,zigzag-top,strip-left-fade'
                easing: 'easeOutQuad', // for the complete list http://jqueryui.com/demos/effect/easing.html
                strips: 20, // Number of strips for strip animations
                blockCols: 10, // Number of block columns for block animations
                blockRows: 5, // Number of block rows for block animations
                captionSpeed: 500, // Caption transition speed
                captionEasing: 'easeInOutSine', // Caption transition easing effect
                captionOpacity: 1, // Caption opacity
                animationSpeed: 1000, // Slide transition speed
                pauseTime: 5000, // How long each slide will show
                startSlide: 0, // Set starting Slide (0 index)
                directionNav: true, // Next & Previous navigation
                directionNavHoverOpacity: 0.6, // Fade on hover
                controlNav: false, // 1,2,3,4... navigation
                controlNavNextPrev: true, // previous,next navigation
                controlNavHoverOpacity: 0.6, // Navigation fade on hover
                controlNavThumbs: false, // Show thumbs navigation
                controlNavTooltip: true, // Show tooltip image previewer
                autoAdvance: true, // Force auto transitions
                keyboardNav: true, // Use left & right arrows
                touchNav: true, // Use Touch swipe to change slides
                pauseOnHover: false, // Stop slider while hovering
                nextLabel: "Next", // To set the string of the next button (Multilanguage use)
                previousLabel: "Previous", // To set the string of the previous button (Multilanguage use)
                playLabel: "Play", // To set the string of the play button (Multilanguage use)
                pauseLabel: "Pause", // To set the string of the pause button (Multilanguage use)
                closeLabel: "Close", // To set the string of the close button (Multilanguage use)
                randomStart: false, // Start on a random slide
                timer: 'Pie', // Timer style: "Pie", "360Bar" or "Bar"
                timerBg: '#000', // Timer background
                timerColor: '#EEE', // Timer color
                timerOpacity: 0.5, // Timer opacity
                timerDiameter: 30, // Timer diameter
                timerPadding: 4, // Timer padding
                timerStroke: 3, // Timer stroke width
                timerBarStroke: 1, // Timer Bar stroke width
                timerBarStrokeColor: '#EEE', // Timer Bar stroke color
                timerBarStrokeStyle: 'solid', // Timer Bar stroke style
                timerX: 10, // Timer X position threshold
                timerY: 10, // Timer Y position threshold
                tooltipX: 5, // Tooltip X position threshold
                tooltipY: -5, // Tooltip Y position threshold
                onBeforeChange: function () {
                }, // Triggers before a slide transition
                onAfterChange: function () {
                }, // Triggers after a slide transition
                onSlideshowEnd: function () {
                }, // Triggers after all slides have been shown
                onLastSlide: function () {
                }, // Triggers when last slide is shown
                onAfterLoad: function () {
                }, // Triggers when slider has loaded
                onPause: function () {
                }, // Triggers when slider has paused
                onPlay: function () {
                } // Triggers when slider has played

            });

        } else {
            alert("Enter all the fields");
        }
    });
});