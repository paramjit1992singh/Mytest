// Code goes here

var app = angular.module("webapp", ["ngRoute"]);

app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider){

    $routeProvider.
        when('/', {
            templateUrl: 'home.html'
        }).
        when('/first', {
            templateUrl: 'example.html',
            controller  : 'firstController'
        }).
        when('/second', {
            templateUrl: 'example.html',
            controller  : 'secondController'
        }).
        when('/third', {
            templateUrl: 'example.html',
            controller  : 'thirdController'
        }).
        otherwise({
            redirectTo: '/'
        });

        // $locationProvider.html5Mode(true);
    }
]);


app.controller("NavController", function ($scope, $location, $log) {
  var active_view = 0,
      paths = ["home", "first", "second", "third"],
      max_active = paths.length - 1;
      
  function gotoActiveView() {
    var view = paths[active_view];
    $location.path(view);
  }
  
  $scope.goBack = function () {
    if (active_view <= 0) {
      active_view = max_active;
    } else {
      active_view -= 1;
    }
    $log.log("goBack active_view: " + active_view);
    gotoActiveView();
  };
  
  $scope.goNext = function () {
    if (active_view >= max_active) {
      active_view = 0;
    } else {
      active_view += 1;
    }
    $log.log("goNext active_view: " + active_view);
    gotoActiveView();
  }
  
  
});

app.controller("firstController", function ($scope) {
  $scope.message = "firstController";
});

app.controller("secondController", function ($scope) {
  $scope.message = "secondController";
});

app.controller("thirdController", function ($scope) {
  $scope.message = "thirdController";
});
