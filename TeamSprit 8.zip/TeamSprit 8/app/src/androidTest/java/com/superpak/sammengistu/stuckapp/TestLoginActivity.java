package com.superpak.sammengistu.stuckapp;

import com.superpak.sammengistu.stuckapp.activities.StuckLoginActivity;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import android.support.test.espresso.Espresso;
import android.support.test.espresso.action.ViewActions;
import android.support.test.espresso.assertion.ViewAssertions;
import android.support.test.espresso.matcher.ViewMatchers;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.ActivityInstrumentationTestCase2;
import android.test.suitebuilder.annotation.LargeTest;


@RunWith(AndroidJUnit4.class)
@LargeTest
public class TestLoginActivity extends ActivityInstrumentationTestCase2<StuckLoginActivity> {

    private String mEmail;
    private String mPassword;

    public TestLoginActivity() {
        super(StuckLoginActivity.class);
    }

    @Rule
    public ActivityTestRule<StuckLoginActivity> mActivityRule = new ActivityTestRule<>(
        StuckLoginActivity.class);

    @Before
    public void initValidString() {
        // Specify a valid string.
        mEmail = "f@f.com";
        mPassword = "123456";
    }

    @Test
    public void changeText_sameActivity() {

        Espresso.onView(ViewMatchers.withId(R.id.login_email_edit_text))
            .perform(ViewActions.typeText(mEmail));
        // Type text and then press the button.
        Espresso.onView(ViewMatchers.withId(R.id.login_password_edit_text))
            .perform(ViewActions.typeText(mPassword), ViewActions.closeSoftKeyboard());

//        Espresso.onView(ViewMatchers.withId(R.id.login_button))
//            .perform(ViewActions.click());

        // Check that the text was changed.
        Espresso.onView(ViewMatchers.withId(R.id.login_password_edit_text))
            .check(ViewAssertions.matches(ViewMatchers.withText(mPassword)));
    }
}
