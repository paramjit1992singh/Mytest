package com.superpak.sammengistu.stuckapp;

import com.superpak.sammengistu.stuckapp.activities.StuckSignUpActivity;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;
import com.superpak.sammengistu.stuckapp.stuck_offline_db.ContentProviderStuck;
import com.superpak.sammengistu.stuckapp.stuck_offline_db.StuckDBConverter;

import android.content.ContentProvider;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.net.Uri;
import android.test.ProviderTestCase2;

import java.util.Date;
import java.util.HashMap;


public class TestContentProviderStuck extends ProviderTestCase2<ContentProviderStuck> {

    public TestContentProviderStuck() {
        super(ContentProviderStuck.class, ContentProviderStuck.class.getName());
    }

    protected void setUp() throws Exception {
        super.setUp();
    }


    /**
     * Very basic query test.
     *
     * Prerequisites:
     * <ul>
     * <li>A provider set up by the test framework
     * </ul>
     *
     * Expectations:
     * <ul>
     * <li> a simple query without any parameters, before any inserts returns a
     * non-null cursor
     * <li> a wrong uri results in {@link IllegalArgumentException}
     * </ul>
     */
    public void testQueryAndInsert(){

        long time = 499494;

        StuckPostSimple stuckPostSimple = new StuckPostSimple("Sam@gmail,com",
            "What school should I go to?",
            "College park, Maryland", "UMD", "Salsibury", "","",0,0,0,0,
            new HashMap<String, Object>(),
            time);

        ContentProvider provider = getProvider();

        Uri uri = Uri.withAppendedPath(ContentProviderStuck.CONTENT_URI,
            StuckConstants.TABLE_OFFLINE_POST);

        //insert item
        provider.insert(uri,
            StuckDBConverter.insertStuckPostToDB(stuckPostSimple, StuckConstants.FALSE));

        Cursor cursor = provider.query(uri, null, null, null, null);
        try {

            cursor.moveToFirst();

            //Loads posts that were saved offline
            if (cursor.getString(cursor.getColumnIndex(StuckConstants.COLUMN_MOST_RECENT_POST))
                .equals(StuckConstants.FALSE)) {

                String stuckEmail = cursor.getString(cursor
                    .getColumnIndex(StuckConstants.COLUMN_EMAIL));

                String stuckQuestion = cursor.getString(cursor
                    .getColumnIndex(StuckConstants.COLUMN_QUESTION));

                String stuckLocation = cursor.getString(cursor
                    .getColumnIndex(StuckConstants.COLUMN_LOCATION));

                String stuckChoice1 = cursor.getString(cursor
                    .getColumnIndex(StuckConstants.COLUMN_CHOICE_ONE));

                String stuckChoice2 = cursor.getString(cursor
                    .getColumnIndex(StuckConstants.COLUMN_CHOICE_TWO));

                String stuckChoice3 = cursor.getString(cursor
                    .getColumnIndex(StuckConstants.COLUMN_CHOICE_THREE));

                String stuckChoice4 = cursor.getString(cursor
                    .getColumnIndex(StuckConstants.COLUMN_CHOICE_FOUR));

                StuckPostSimple stuckPostSimple2 = new StuckPostSimple(
                    StuckSignUpActivity.encodeEmail(stuckEmail), stuckQuestion,
                    stuckLocation,
                    stuckChoice1, stuckChoice2, stuckChoice3, stuckChoice4,
                    StuckConstants.ZERO_VOTES, StuckConstants.ZERO_VOTES,
                    StuckConstants.ZERO_VOTES, StuckConstants.ZERO_VOTES,
                    new HashMap<String, Object>(), (-1 * new Date().getTime()));


                //test if insert item matches output
                assertEquals(stuckPostSimple.getEmail(), stuckPostSimple2.getEmail());
            }

        } catch (NullPointerException e) {

        }
    }

    public void testQueryAndDelete(){

        long time = 499494;

        StuckPostSimple stuckPostSimple = new StuckPostSimple("Sam@gmail,com",
            "What school should I go to?",
            "College park, Maryland", "UMD", "Salsibury", "","",0,0,0,0,
            new HashMap<String, Object>(),
            time);

        ContentProvider provider = getProvider();

        Uri uri = Uri.withAppendedPath(ContentProviderStuck.CONTENT_URI,
            StuckConstants.TABLE_OFFLINE_POST);

        //insert item
        provider.insert(uri,
            StuckDBConverter.insertStuckPostToDB(stuckPostSimple, StuckConstants.TRUE));

        //Delete
        provider.delete(uri,
            StuckConstants.COLUMN_QUESTION + " = ?", new String[]{stuckPostSimple.getQuestion()});

        Cursor cursor = provider.query(uri, null, null, null, null);

        try {

            cursor.moveToFirst();

            //Loads posts that were saved offline
            if (cursor.getString(cursor.getColumnIndex(StuckConstants.COLUMN_MOST_RECENT_POST))
                .equals(StuckConstants.TRUE)) {
                //if cursor finds a item then assert false
                assertFalse(false);
            }

        } catch (CursorIndexOutOfBoundsException e) {
            assertTrue(true);
        }

        cursor.close();
    }
}