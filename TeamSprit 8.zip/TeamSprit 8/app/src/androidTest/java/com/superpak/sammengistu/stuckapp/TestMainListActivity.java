package com.superpak.sammengistu.stuckapp;

import com.superpak.sammengistu.stuckapp.activities.StuckMainListActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.test.espresso.Espresso;
import android.support.test.espresso.action.ViewActions;
import android.support.test.espresso.assertion.ViewAssertions;
import android.support.test.espresso.matcher.BoundedMatcher;
import android.support.test.espresso.matcher.ViewMatchers;
import android.support.test.rule.ActivityTestRule;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.ImageView;


public class TestMainListActivity extends ActivityInstrumentationTestCase2<StuckMainListActivity> {
    public TestMainListActivity() {
        super(StuckMainListActivity.class);
    }

    @Rule
    public ActivityTestRule<StuckMainListActivity> mStuckMainListActivityActivityTestRule =
        new ActivityTestRule<>(StuckMainListActivity.class);

    @Test
    public void testTabImageViewOnRightClickLeftChange() throws Exception {
        //When on left
        Drawable leftGroupClearDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeShaded= ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();
        //Click right
        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_middle_imageview_background))
            .perform(ViewActions.click());
        Thread.sleep(getBestSleepTimeForOneRequest());
        //When right is clicked
        Drawable leftGroupShadedDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeClear = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();

        Thread.sleep(getBestSleepTimeForOneRequest());

        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_left_imageview_background))
            .check(ViewAssertions.matches(isImageTheSame(leftGroupShadedDrawable)));
    }

    @Test
    public void testTabImageViewOnLeftClickRightChange() throws Exception {

        //When on left
        Drawable leftGroupClearDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeShaded= ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();
        //Click right
        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_middle_imageview_background))
            .perform(ViewActions.click());
        Thread.sleep(getBestSleepTimeForOneRequest());
        //When right is clicked
        Drawable leftGroupShadedDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeClear = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();

        //Click left
        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_left_imageview_background))
            .perform(ViewActions.click());
        Thread.sleep(getBestSleepTimeForOneRequest());

        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_middle_imageview_background))
            .check(ViewAssertions.matches(isImageTheSame(rightMeShaded)));
    }

    @Test
    public void testTabImageViewOnLeftClickLeftSame() throws Exception {

        //When on left
        Drawable leftGroupClearDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeShaded= ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();
        //Click right
        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_middle_imageview_background))
            .perform(ViewActions.click());
        Thread.sleep(getBestSleepTimeForOneRequest());
        //When right is clicked
        Drawable leftGroupShadedDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeClear = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();

        //Click left
        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_left_imageview_background))
            .perform(ViewActions.click());
        Thread.sleep(getBestSleepTimeForOneRequest());

        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_left_imageview_background))
            .check(ViewAssertions.matches(isImageTheSame(leftGroupClearDrawable)));
    }

    @Test
    public void testTabImageViewOnRightClickRightSame() throws Exception {

        //When on left
        Drawable leftGroupClearDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeShaded= ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();
        //Click right
        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_middle_imageview_background))
            .perform(ViewActions.click());
        Thread.sleep(getBestSleepTimeForOneRequest());
        //When right is clicked
        Drawable leftGroupShadedDrawable = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_left_imageview_background)).getDrawable();
        Drawable rightMeClear = ((ImageView)getActivity().findViewById(
            R.id.main_toolbar_middle_imageview_background)).getDrawable();

        Espresso.onView(ViewMatchers.withId(R.id.main_toolbar_middle_imageview_background))
            .check(ViewAssertions.matches(isImageTheSame(rightMeClear)));
    }

    private long getBestSleepTimeForOneRequest() {
        return 750;
    }

    public static Matcher isImageTheSame(final Drawable drawable) {
        return new BoundedMatcher(ImageView.class) {

            @Override
            protected boolean matchesSafely(Object item) {
                if (item instanceof ImageView){
                    Bitmap bitmapCompare = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                    Drawable drawable = ((ImageView)item).getDrawable();
                    Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
                    return bitmapCompare.sameAs(bitmap);
                }else {
                    return false;
                }
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("is image the same as: ");
                description.appendValue(drawable);
            }
        };
    }
}
