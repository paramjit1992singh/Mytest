package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;
import com.superpak.sammengistu.stuckapp.model.User;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class UpdateEmailActivity extends AppCompatActivity {

    private User mTempUser;

    @BindView(R.id.update_email_dialog_one)
    EditText mTypedEmail1;
    @BindView(R.id.update_email_dialog_two)
    EditText mTypedEmail2;
    @BindView(R.id.spinnerProgress)
    LinearLayout mSpinnerProgress;
    @BindView(R.id.dialog_update_email_reset_email)
    Button mResetEmail;
    @BindView(R.id.dialog_update_email_current_email)
    TextView mCurrentEmailTV;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.update_email_cancel)
    TextView mCancelTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_email);
        ButterKnife.bind(this);
        setUpToolBar();

        mSpinnerProgress.setVisibility(View.INVISIBLE);

        mResetEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkIfEmailsMatch() && StuckSignUpActivity.validEmail(mTypedEmail1.getText().toString())) {
                    final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                    if (user != null) {

                        if (user.getProviders().get(0).equals(StuckConstants.PASSWORD_PROVIDER)) {

                            mSpinnerProgress.setVisibility(View.VISIBLE);
                            user.updateEmail(mTypedEmail1.getText().toString())
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if (task.isSuccessful()) {

                                            String prevEncodedEmail = StuckSignUpActivity
                                                .encodeEmail(mCurrentEmailTV.getText().toString());

                                        Toast.makeText(UpdateEmailActivity.this,
                                            R.string.success_resetting_email,
                                            Toast.LENGTH_SHORT).show();

                                        updateAllUsersPost(prevEncodedEmail,
                                            mTypedEmail2.getText().toString());

                                    } else {
                                            mSpinnerProgress.setVisibility(View.GONE);
                                        Toast.makeText(UpdateEmailActivity.this,
                                            R.string.failed_resetting_email,
                                            Toast.LENGTH_LONG).show();

                                        showErrorResettingAlertDialog(UpdateEmailActivity.this,
                                            getString(R.string.email_already_exists));
                                    }
                                }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
                    } else {
                        showErrorDialog();
                    }
                }
            }else {
                Toast.makeText(UpdateEmailActivity.this, R.string.there_was_an_error,
                    Toast.LENGTH_LONG).show();
            }
        }
    });

    setCurrentEmailView();
}

    private void updateUsersVote(final String prevEmail) {
        final DatabaseReference userEmailInDb = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_USERS_VOTES)
            .child(prevEmail);

        final String newEmail = StuckSignUpActivity.encodeEmail(mTypedEmail1.getText().toString());

        final Map<String, Integer> votedForPosts = new HashMap<>();

        userEmailInDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot voteSnap : dataSnapshot.getChildren()) {
                    votedForPosts.put(voteSnap.getKey(), voteSnap.getValue(Integer.class));
                }

                for (String key : votedForPosts.keySet()) {
                    //set new posts value
                    FirebaseDatabase.getInstance().getReference()
                        .child(StuckConstants.FIREBASE_URL_USERS_VOTES).child(newEmail)
                        .child(key).setValue(votedForPosts.get(key));

                }

                userEmailInDb.removeValue();

                updateStarredPosts(prevEmail);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void updateStarredPosts(String prevEmail) {
        final DatabaseReference userEmailInDb = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_STARRED_POST)
            .child(prevEmail);

        final String newEmail = StuckSignUpActivity.encodeEmail(mTypedEmail1.getText().toString());

        final Map<String, String> starredForPosts = new HashMap<>();

        userEmailInDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot voteSnap : dataSnapshot.getChildren()) {
                    starredForPosts.put(voteSnap.getKey(), voteSnap.getValue(String.class));
                }

                for (String key : starredForPosts.keySet()) {
                    //set new posts value
                    FirebaseDatabase.getInstance().getReference()
                        .child(StuckConstants.FIREBASE_STARRED_POST).child(newEmail)
                        .child(key).setValue(starredForPosts.get(key));
                }

                userEmailInDb.removeValue();

                FirebaseAuth.getInstance().signOut();
                StuckMainListActivity.takeUserToLoginScreen(UpdateEmailActivity.this);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void updateUsersEmailInDb(final String previousEmail) {
        final DatabaseReference userEmailInDb = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_USERS)
            .child(previousEmail);

        final String newEmail = StuckSignUpActivity.encodeEmail(mTypedEmail1.getText().toString());

        userEmailInDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                userEmailInDb.removeValue();

                User user = dataSnapshot.getValue(User.class);
                mTempUser = new User(newEmail, user.getTimestampJoined());

                FirebaseDatabase.getInstance().getReference()
                    .child(StuckConstants.FIREBASE_URL_USERS)
                    .child(newEmail).setValue(mTempUser);

                updateUsersVote(previousEmail);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });

    }

    private void setCurrentEmailView() {
        String currentEmail = UpdateEmailActivity.this.getApplicationContext()
            .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0)
            .getString(StuckConstants.KEY_ENCODED_EMAIL, "");

        currentEmail = currentEmail.replace(",", ".");
        mCurrentEmailTV.setText(currentEmail);
    }

    public static void showErrorResettingAlertDialog(Activity activity, String additional) {
        new AlertDialog.Builder(activity)
            .setTitle(R.string.error)
            .setMessage(activity.getString(R.string.error_updating_account_default_dialog) + additional)
            .setNegativeButton(activity.getString(R.string.cancel), null)
            .show();
    }

    private boolean checkIfEmailsMatch() {
        String typedEmail1 = mTypedEmail1.getText().toString();
        String typedEmail2 = mTypedEmail2.getText().toString();

        return typedEmail1.equals(typedEmail2);

    }

    private void showErrorDialog() {
        new AlertDialog.Builder(UpdateEmailActivity.this)
            .setPositiveButton(getString(R.string.cancel), null)
            .setTitle(getString(R.string.error))
            .setMessage(R.string.error_signed_in_with_google_cant_change_password)

            .show();
    }

    private void setUpToolBar() {
        mToolbar.inflateMenu(R.menu.menu_main);

        setSupportActionBar(mToolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void updateAllUsersPost(final String userEncodedEmail, final String newEmail) {
        Query queryRef = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_ACTIVE_POSTS)
            .orderByChild(StuckConstants.FIREBASE_EMAIL)
            .equalTo(userEncodedEmail);

        final List<DatabaseReference> userPosts = new ArrayList<>();

        queryRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot stuckSnap : dataSnapshot.getChildren()) {

                    StuckPostSimple stuckPostSimple =
                        stuckSnap.getValue(StuckPostSimple.class);

                    stuckPostSimple.setDatabaseReference(stuckSnap.getRef());

                    userPosts.add(stuckSnap.getRef());
                }

                for (DatabaseReference userPostRef : userPosts) {
                    userPostRef.child(StuckConstants.FIREBASE_EMAIL).setValue(
                        StuckSignUpActivity.encodeEmail(newEmail));
                }
                mSpinnerProgress.setVisibility(View.INVISIBLE);

                updateUsersEmailInDb(userEncodedEmail);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                mSpinnerProgress.setVisibility(View.INVISIBLE);
                Toast.makeText(UpdateEmailActivity.this, getString(R.string.there_was_an_error),
                    Toast.LENGTH_LONG).show();
            }
        });
    }

    @OnClick(R.id.update_email_cancel)
    public void mCancelEmail() {
        Intent intent = new Intent(this, AccountSettingsActivity.class);
        startActivity(intent);
    }
}

