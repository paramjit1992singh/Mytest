package com.superpak.sammengistu.stuckapp;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;

/**
 * Gets the network status
 */
public class NetworkStatus {

    public static boolean isOnline(Context context) {
        ConnectivityManager cm =
            (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    public static void showOffLineDialog(Context context){
        new AlertDialog.Builder(context)
            .setTitle(context.getString(R.string.you_are_offline))
            .setMessage(context.getString(R.string.please_connect_the_internet))
            .setPositiveButton(android.R.string.ok, null)
            .show();
    }
}
