package com.superpak.sammengistu.stuckapp.services;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import com.superpak.sammengistu.stuckapp.NotifyUser;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private final String TAG = "FbMessagingService55";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // Handles message that is received from FCM
        handleMessage(remoteMessage.getNotification().getBody());
    }

    private void handleMessage(String message) {
        NotifyUser.notifyUset(this, message);
    }
}
