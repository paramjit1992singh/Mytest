package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.NetworkStatus;
import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.model.User;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class StuckLoginActivity extends AppCompatActivity
    implements GoogleApiClient.OnConnectionFailedListener {

    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseAuth mAuth;
    private ProgressDialog mProgressDialog;
    private GoogleApiClient mGoogleApiClient;
    private boolean mSignedInWithGoogle;
    private String mEncodedEmail;

    @BindView(R.id.login_email_edit_text)
    EditText mEmailEditText;
    @BindView(R.id.login_password_edit_text)
    EditText mPasswordEditText;
    @BindView(R.id.login_sign_up_account)
    TextView mLoggingTextView;
    @BindView(R.id.login_button)
    Button mLoginButton;
    @BindView(R.id.login_forgot_password_account)
    TextView mForgotPasswordTextView;
    @BindView(R.id.log_in_button_google)
    SignInButton mSignInButton;

    private DatabaseReference.CompletionListener mCompletionListenerSignUp =
        new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError databaseError,
                                   DatabaseReference databaseReference) {

                if (databaseError != null) {
                    Toast.makeText(StuckLoginActivity.this,
                        R.string.account_created, Toast.LENGTH_SHORT).show();
                }
            }
        };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        mAuth = FirebaseAuth.getInstance();

        mProgressDialog = new ProgressDialog(StuckLoginActivity.this);
        mSignedInWithGoogle = false;

        connectWithGoogle();

        //If user logs in this will get called
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {

                    if (!mSignedInWithGoogle) {
                        mEncodedEmail = StuckSignUpActivity.encodeEmail(
                            mEmailEditText.getText().toString().toLowerCase());
                    }

                    //Creates user if they don't have an account and signed in with google
                    if (mSignedInWithGoogle) {
                        createUserInFBHelper(mEncodedEmail.toLowerCase());
                    }

                    // User is signed in
                    mProgressDialog.dismiss();

                    //Store users email
                    StuckSignUpActivity.putEmailInSharedPref(mEncodedEmail,
                        StuckLoginActivity.this,
                        user.getProviders().get(0));

                    Intent intent = new Intent(StuckLoginActivity.this,
                        StuckMainListActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);

                } else {
                    // User is signed out
                    mProgressDialog.dismiss();
                }
            }
        };
    }

    /**
     * Builds a googleApi client
     */
    private void connectWithGoogle() {

        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build();

        // Build a GoogleApiClient with access to the Google Sign-In API and the
        // options specified by gso.
        mGoogleApiClient = new GoogleApiClient.Builder(this)
            .enableAutoManage(this /* FragmentActivity */, this /* OnConnectionFailedListener */)
            .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
            .build();
    }

    /**
     * Checks to see if user already has an account before creating them another one
     *
     * @param emailUser - email to search for
     */
    private void createUserInFBHelper(String emailUser) {
        final String encodedEmail = StuckSignUpActivity.encodeEmail(emailUser);
        final DatabaseReference userLocation = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_USERS)
            .child(encodedEmail);

        /**
         * See if there is already a user (for example, if they already logged in with an associated
         * Google account.
         */
        userLocation.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                /* If there is no user, make one */
                if (dataSnapshot.getValue() == null) {
                    /* Set raw version of date to the ServerValue.TIMESTAMP
                     value and save into dateCreatedMap */
                    HashMap<String, Object> timestampJoined = new HashMap<>();
                    timestampJoined.put(StuckConstants.FIREBASE_PROPERTY_TIMESTAMP,
                        ServerValue.TIMESTAMP);

                    User newUser = new User(encodedEmail, timestampJoined);
                    userLocation.setValue(encodedEmail);

                    userLocation.setValue(newUser, mCompletionListenerSignUp);
                }
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {
            }
        });
    }

    /**
     * Authenticates the user to through email and password
     * then updates the shared preference based on whether then launches the next activity
     */
    private void loginEmailPassword() {

        if (allFieldsAreEntered() && StuckSignUpActivity.validEmail(mEmailEditText.getText().toString())) {

            FirebaseAuth auth = FirebaseAuth.getInstance();

            auth.signInWithEmailAndPassword(
                mEmailEditText.getText().toString(), mPasswordEditText.getText().toString())
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            mProgressDialog.dismiss();
                            Toast.makeText(StuckLoginActivity.this, R.string.login_failed,
                                Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        mProgressDialog.dismiss();
                    }
                });
        } else {
            mProgressDialog.dismiss();
            Toast.makeText(this, R.string.invailid_email_or_all_fields_were_not_entered_toast,
                Toast.LENGTH_LONG).show();
        }
    }

    private boolean allFieldsAreEntered() {
        return !mEmailEditText.getText().toString().equals("") &&
            !mPasswordEditText.getText().toString().equals("");
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, StuckConstants.RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == StuckConstants.RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess()) {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = result.getSignInAccount();
                mSignedInWithGoogle = true;
                mEncodedEmail = StuckSignUpActivity.encodeEmail(account.getEmail());
                firebaseAuthWithGoogle(account);
            } else {
                // Google Sign In failed, update UI appropriately
                Toast.makeText(this, R.string.google_sign_in_fail, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Signs the user in with their google account
     */
    private void firebaseAuthWithGoogle(final GoogleSignInAccount acct) {

        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential)
            .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {

                    // If sign in fails, display a message to the user. If sign in succeeds
                    // the auth state listener will be notified and logic to handle the
                    // signed in user can be handled in the listener.
                    if (!task.isSuccessful()) {
                        Toast.makeText(StuckLoginActivity.this, "Authentication failed.",
                            Toast.LENGTH_SHORT).show();
                    }
                }
            });
    }

    @OnClick(R.id.login_forgot_password_account)
    public void setForgotPasswordTextView() {
        Intent intent = new Intent(StuckLoginActivity.this, ForgotPasswordActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.login_sign_up_account)
    public void onClickLoginActivity() {
        Intent intent = new Intent(this, StuckSignUpActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    @OnClick(R.id.login_button)
    public void loginButton() {
        mProgressDialog.setMessage(getString(R.string.logging_in_dialog));
        mProgressDialog.show();
        if (NetworkStatus.isOnline(this)) {
            loginEmailPassword();

        } else {
            mProgressDialog.dismiss();
            NetworkStatus.showOffLineDialog(this);

        }
    }

    @OnClick(R.id.log_in_button_google)
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.log_in_button_google:
                signIn();
                break;
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }
}
