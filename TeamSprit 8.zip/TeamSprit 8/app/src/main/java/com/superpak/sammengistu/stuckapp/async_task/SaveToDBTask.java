package com.superpak.sammengistu.stuckapp.async_task;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.NetworkStatus;
import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.activities.StuckMainListActivity;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;
import com.superpak.sammengistu.stuckapp.stuck_offline_db.ContentProviderStuck;
import com.superpak.sammengistu.stuckapp.stuck_offline_db.StuckDBConverter;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;


public class SaveToDBTask extends AsyncTask<Void, Void, Void> {

    private StuckPostSimple mStuckPostSimple;
    private boolean mPostToFirebase;
    private Activity mActivity;
    private LinearLayout mDialog;

    public SaveToDBTask(StuckPostSimple stuckPostSimple, Activity activity, LinearLayout dialog) {
        mStuckPostSimple = stuckPostSimple;
        mPostToFirebase = true;
        mActivity = activity;
        mDialog = dialog;
    }

    @Override
    protected Void doInBackground(Void... params) {

        if (!NetworkStatus.isOnline(mActivity)) {

            mPostToFirebase = false;

            Uri contentUri = Uri.withAppendedPath(ContentProviderStuck.CONTENT_URI,
                StuckConstants.TABLE_OFFLINE_POST);

            mActivity.getContentResolver().insert(contentUri,
                StuckDBConverter.insertStuckPostToDB(mStuckPostSimple, StuckConstants.FALSE));
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        mDialog.setVisibility(View.GONE);

        SharedPreferences pref = mActivity.getApplicationContext()
            .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0);

        SharedPreferences.Editor editor = pref.edit();

        if (mPostToFirebase) {
            FirebaseDatabase.getInstance().getReference()
                .child(StuckConstants.FIREBASE_URL_ACTIVE_POSTS).push().setValue(mStuckPostSimple);

            final DatabaseReference locRef = FirebaseDatabase.getInstance().getReference()
                .child(StuckConstants.FIREBASE_POST_LOCATION)
                .child(mStuckPostSimple.getLocation());

            locRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getValue() == null) {

                        locRef.setValue(mStuckPostSimple.getLocation());
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

            editor.putBoolean(StuckConstants.USER_MADE_OFFLINE_POST,
                false);

            editor.apply();
        } else {

            editor.putBoolean(StuckConstants.USER_MADE_OFFLINE_POST,
                true);

            editor.apply();

            Toast.makeText(mActivity,
                R.string.oofline_will_make_post_later, Toast.LENGTH_LONG).show();
        }

        Intent intent = new Intent(mActivity, StuckMainListActivity.class);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mActivity.startActivity(intent,
                ActivityOptions.makeSceneTransitionAnimation(mActivity).toBundle());
        } else {
            mActivity.startActivity(intent);
        }
    }
}
