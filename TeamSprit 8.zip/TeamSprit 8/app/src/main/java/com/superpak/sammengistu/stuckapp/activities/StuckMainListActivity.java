package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.GeneralArea;
import com.superpak.sammengistu.stuckapp.NetworkStatus;
import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.adapters.CardViewPostAdapter;
import com.superpak.sammengistu.stuckapp.dialogs.FilterDialog;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;
import com.superpak.sammengistu.stuckapp.services.NotificationService;
import com.superpak.sammengistu.stuckapp.stuck_offline_db.ContentProviderStuck;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlarmManager;
import android.app.LoaderManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.transition.Explode;
import android.transition.Slide;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class StuckMainListActivity extends AppCompatActivity
    implements LoaderManager.LoaderCallbacks<Cursor>,
    GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener,
    AdapterView.OnItemSelectedListener {

    private final String TAG = "StuckMainList55";
    private int mDeductByDeletedPosts;
    private String mEmail;
    private RecyclerView.Adapter mAdapter;
    private List<StuckPostSimple> stuckPostsLoaded;
    private GoogleApiClient mGoogleApiClient;
    private FirebaseAuth mAuth;
    private DatabaseReference mActivePostsRef;
    private String mLocationToFilterBy;
    private int mSetUpStarredPostsAdapterCounter;
    public static List<String> mStarPostRefs;
    private int mTabSection;
    private SharedPreferences mSharedPreferences;

    @BindView(R.id.main_list_stuck_toolbar)
    Toolbar mMainListToolbar;
    @BindView(R.id.fab_add)
    FloatingActionButton mNewPostFAB;
    @BindView(R.id.swipe_refresh_layout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.recycler_view_question_post)
    RecyclerView mRecyclerViewQuestions;
    @BindView(R.id.main_toolbar_left_imageview_background)
    ImageView mToolbarImageViewLeft;
    @BindView(R.id.main_toolbar_middle_imageview_background)
    ImageView mToolbarImageViewMiddle;
    @BindView(R.id.main_toolbar_left_view_background)
    View mToolbarViewLeft;
    @BindView(R.id.main_toolbar_middle_view_background)
    View mToolbarViewMiddle;
    @BindView(R.id.main_toolbar_right_imageview_background)
    ImageView mToolbarImageViewRight;
    @BindView(R.id.main_toolbar_right_view_background)
    View mToolbarViewRight;
    @BindView(R.id.main_list_filtered_view)
    FrameLayout mFilteredView;
    @BindView(R.id.spinnerProgress)
    LinearLayout mProgressSpinnerDialog;
    @BindView(R.id.empty_list_create_a_post)
    TextView mEmptyListCreateAPost;

    private FirebaseAuth.AuthStateListener mAuthStateListener = new FirebaseAuth.AuthStateListener() {
        @Override
        public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if (user == null) {
                takeUserToLoginScreen(StuckMainListActivity.this);
            }
        }
    };

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindowAnimations();
        setContentView(R.layout.activity_stuck_main_list);
        ButterKnife.bind(this);

        mAuth = FirebaseAuth.getInstance();

        mEmptyListCreateAPost.setVisibility(View.INVISIBLE);

        mActivePostsRef = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_ACTIVE_POSTS);

        mAuth.addAuthStateListener(mAuthStateListener);

        mSharedPreferences = getApplicationContext()
            .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0); // 0 - for private mode

        mEmail = mSharedPreferences.getString(StuckConstants.KEY_ENCODED_EMAIL, "");

        connectWithGoogle();

        // use a linear layout manager
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);

        if (mRecyclerViewQuestions != null) {
            // use this setting to improve performance if you know that changes
            // in content do not change the layout size of the RecyclerView
            mRecyclerViewQuestions.setHasFixedSize(true);
            mRecyclerViewQuestions.setLayoutManager(layoutManager);
        }

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (mLocationToFilterBy != null) {
                    setLocationPostAdapter(mLocationToFilterBy);
                } else {
                    refreshPosts();
                }
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });

        setUpFilterView(false);
        showHelpDialog();
        retieveAllUsersStarredPostRefsAndInitializeAdapter(mEmail);
        setUpToolbar();
    }

    private void startTimedNotification(){
        Intent notificationIntent = new Intent(this, NotificationService.class);
        PendingIntent contentIntent = PendingIntent.getService(this, 0, notificationIntent,
            PendingIntent.FLAG_CANCEL_CURRENT);

        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        am.cancel(contentIntent);
        long threeDays = AlarmManager.INTERVAL_DAY * 3;
        am.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()
            + threeDays, threeDays, contentIntent);

    }

    private void showHelpDialog() {
        if (mSharedPreferences.getBoolean(StuckConstants.SHOW_USER_HOW_USE_MAIN_DIALOG, false)) {
            new AlertDialog.Builder(this).setTitle(getString(R.string.how_to_use))
                .setMessage(getString(R.string.main_list_dialog_message))
                .setPositiveButton(getString(R.string.got_it), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SharedPreferences.Editor editor = mSharedPreferences.edit();
                        editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_MAIN_DIALOG, false);
                        editor.apply();
                    }
                }).show();
        }
    }

    /**
     * Sets up floating action bar based on the screen size
     * if the width of the screen is less then 600pixels it
     * will show th action button on the top of the screen
     */
    private void setUpFilterView(boolean setFilteredView) {

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        //Device is a 7" tablet
        int actionBarHeight = 10;
        // Calculate ActionBar height
        TypedValue tv = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {

            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data,
                getResources().getDisplayMetrics());
        }

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = Gravity.CENTER_HORIZONTAL;

        if (setFilteredView) {

            params.setMargins(0, actionBarHeight, 0, 0);
        } else {
            params.setMargins(0, 0, 0, 0);
        }
        mFilteredView.setLayoutParams(params);

    }

    private void connectWithGoogle() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
            .addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .addApi(LocationServices.API)
            .build();

        mGoogleApiClient.connect();
    }

    public static void takeUserToLoginScreen(Activity activity) {
        Intent intent = new Intent(activity, StuckLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        activity.startActivity(intent);
    }

    /**
     * Checks network status then loads all active posts
     */
    private void initializeAdapter(final List<String> starredPostRefs) {

        mProgressSpinnerDialog.setVisibility(View.VISIBLE);

        Query byTimeStampQueryRef = mActivePostsRef.orderByChild(StuckConstants.DATE_TIME_STAMP);

        final List<StuckPostSimple> stuckPostSimples = new ArrayList<>();

        if (!NetworkStatus.isOnline(StuckMainListActivity.this)) {
            NetworkStatus.showOffLineDialog(StuckMainListActivity.this);
            // HIDE THE SPINNER AFTER LOADING FEEDS
            mProgressSpinnerDialog.setVisibility(View.GONE);
        } else {

            byTimeStampQueryRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    for (DataSnapshot stuckSnap : dataSnapshot.getChildren()) {

                        StuckPostSimple stuckPostSimple = stuckSnap.getValue(StuckPostSimple.class);
                        stuckPostSimple.setDatabaseReference(stuckSnap.getRef());

                        stuckPostSimples.add(stuckPostSimple);
                    }

                    mAdapter = new CardViewPostAdapter(stuckPostSimples, StuckMainListActivity.this,
                        starredPostRefs);
                    // HIDE THE SPINNER AFTER LOADING FEEDS
                    mProgressSpinnerDialog.setVisibility(View.GONE);
                    mRecyclerViewQuestions.setAdapter(mAdapter);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // HIDE THE SPINNER AFTER LOADING FEEDS
                    mProgressSpinnerDialog.setVisibility(View.GONE);
                }
            });

            mAdapter = new CardViewPostAdapter(stuckPostSimples, StuckMainListActivity.this,
                starredPostRefs);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        mMainListToolbar.inflateMenu(R.menu.menu_main);
        mMainListToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                return onOptionsItemSelected(item);

            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_log_out:
                FirebaseAuth.getInstance().signOut();
                break;

            case R.id.action_filter_by_location:
                showFilteredListByLocation();
                break;

            case R.id.action_account_settings:
                Intent intent = new Intent(this, AccountSettingsActivity.class);
                startActivity(intent);
                break;

            case R.id.action_help:
                resetHelpPreference();

                break;

            case R.id.action_report_issue:
               startGmailToReportAppIssue();

            default:
                break;
        }

        return true;
    }

    /**
     * Changes all help preference to true so user can get help dialogs
     */
    private void resetHelpPreference() {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_MAIN_DIALOG, true);
        editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_VOTE_DIALOG, true);
        editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_NEW_POST_DIALOG, true);
        editor.putBoolean(StuckConstants.SHOW_USER_HOW_TO_USE_FILTER, true);

        editor.apply();
        showHelpDialog();
    }

    /**
     * Starts up gmail compose so user can email issues with the app
     */
    private void startGmailToReportAppIssue(){
        Intent sendIntent = new Intent(Intent.ACTION_VIEW);
        sendIntent.setType("plain/text");
        sendIntent.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
        sendIntent.putExtra(Intent.EXTRA_EMAIL, new String[] { getString(R.string.my_email) });
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.report_issue_stuck_app));
        startActivity(sendIntent);
    }

    private void showFilteredListByLocation() {
        mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
        FilterDialog filterDialog = new FilterDialog();
        filterDialog.setDialogResult(new FilterDialog.OnMyDialogResult() {
            @Override
            public void finish(String result) {
                if (mSharedPreferences.getBoolean(StuckConstants.SHOW_USER_HOW_TO_USE_FILTER, false)) {
                    new AlertDialog.Builder(StuckMainListActivity.this)
                        .setTitle(getString(R.string.how_to_use))
                        .setMessage(getString(R.string.how_to_use_filter_posts))
                        .setPositiveButton(getString(R.string.got_it), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                SharedPreferences.Editor editor = mSharedPreferences.edit();
                                editor.putBoolean(StuckConstants.SHOW_USER_HOW_TO_USE_FILTER, false);
                                editor.apply();
                            }
                        })
                        .show();
                }
                mLocationToFilterBy = result;
                setLocationPostAdapter(mLocationToFilterBy);
                adjustToolbarByClickedImageTab(0);
                setUpFilterView(true);
            }
        });

        filterDialog.show(getSupportFragmentManager(), "Location");
    }

    /**
     * querys all posts that are equal to the filtered post
     * then flips the returned results so the most recent post is showed first
     */
    private void setLocationPostAdapter(String cityStateName) {

        mProgressSpinnerDialog.setVisibility(View.VISIBLE);

        Query queryRef = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_ACTIVE_POSTS)
            .orderByChild(StuckConstants.FIREBASE_POST_LOCATION)
            .equalTo(cityStateName);

        queryRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                List<StuckPostSimple> stuckPostSimpleList = new ArrayList<>();
                for (DataSnapshot filterPost : dataSnapshot.getChildren()) {
                    StuckPostSimple stuckPostSimple = filterPost.getValue(StuckPostSimple.class);
                    stuckPostSimple.setDatabaseReference(filterPost.getRef());

                    stuckPostSimpleList.add(stuckPostSimple);
                }

                List<StuckPostSimple> temp = new ArrayList<>();
                //reverses the list to show most recent first
                for (int i = stuckPostSimpleList.size() - 1; i >= 0; i--) {
                    temp.add(stuckPostSimpleList.get(i));
                }

                // HIDE THE SPINNER AFTER LOADING FEEDS
                mProgressSpinnerDialog.setVisibility(View.GONE);
                mAdapter = new CardViewPostAdapter(temp, StuckMainListActivity.this, mStarPostRefs);
                mRecyclerViewQuestions.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                mProgressSpinnerDialog.setVisibility(View.GONE);

            }
        });
    }

    /**
     * querys all posts that are equal to the users email
     * then flips the returned results so the posts are in timestamp order
     */
    private void setMyPostAdapter() {

        mProgressSpinnerDialog.setVisibility(View.VISIBLE);

        Query queryRef = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_ACTIVE_POSTS)
            .orderByChild(StuckConstants.FIREBASE_EMAIL)
            .equalTo(StuckSignUpActivity.encodeEmail(mEmail));

        queryRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                List<StuckPostSimple> stuckPostSimplesList = new ArrayList<>();
                // HIDE THE SPINNER AFTER LOADING FEEDS
                mProgressSpinnerDialog.setVisibility(View.GONE);
                for (DataSnapshot myPostSnap : dataSnapshot.getChildren()) {

                    StuckPostSimple stuckPostSimple = myPostSnap.getValue(StuckPostSimple.class);
                    stuckPostSimple.setDatabaseReference(myPostSnap.getRef());
                    stuckPostSimplesList.add(stuckPostSimple);
                }

                List<StuckPostSimple> temp = new ArrayList<>();
                //reverses the list to show most recent first
                for (int i = stuckPostSimplesList.size() - 1; i >= 0; i--) {
                    temp.add(stuckPostSimplesList.get(i));
                }

                if (temp.size() == 0) {
                    mEmptyListCreateAPost.setText(
                        getString(R.string.you_have_no_posts_create_one_by_tapping_on_the_add_button));
                    mEmptyListCreateAPost.setVisibility(View.VISIBLE);
                } else {
                    mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
                }

                mAdapter = new CardViewPostAdapter(temp, StuckMainListActivity.this, mStarPostRefs);
                mRecyclerViewQuestions.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // HIDE THE SPINNER AFTER LOADING FEEDS
                mProgressSpinnerDialog.setVisibility(View.GONE);
            }
        });
    }

    /**
     * If user selects show my posts calls the appropriate method to update the adapter
     */
    private void refreshPosts() {

        switch (mTabSection) {
            case 0:
                retieveAllUsersStarredPostRefsAndInitializeAdapter(mEmail);
                break;
            case 1:
                setMyPostAdapter();
                break;
            default:
                setMyStarPostAdapter();
        }
    }

    private void setUpToolbar() {
        mMainListToolbar.inflateMenu(R.menu.menu_main);

        setSupportActionBar(mMainListToolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private Location getLastKnownLocation() {

        if (ActivityCompat.checkSelfPermission(this
            , Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {

            return null;
        }

        return LocationServices.FusedLocationApi.getLastLocation(
            mGoogleApiClient);
    }

    /**
     * If their are posts in the local database, add them to firebase then delete them
     * from the local database
     */
    private void addNewPostsToFirebase() {

        if (stuckPostsLoaded.size() > 0 && NetworkStatus.isOnline(this)) {
            if (getLastKnownLocation() != null) {
                for (int i = 0; i < stuckPostsLoaded.size(); i++) {
                    StuckPostSimple stuckPostSimple = stuckPostsLoaded.get(i);

                    if (getLastKnownLocation() != null) {
                        stuckPostSimple.setLocation(GeneralArea.getAddressOfCurrentLocation(
                            getLastKnownLocation(), this));
                    } else {
                        stuckPostSimple.setLocation("N/A");
                        StuckNewPostActivity.showErrorLocationDialog(this);
                    }
                    //Push the post straight to firebase
                    FirebaseDatabase.getInstance().getReference().child(
                        StuckConstants.FIREBASE_URL_ACTIVE_POSTS).push().setValue(stuckPostSimple);

                    Uri contentUri = Uri.withAppendedPath(ContentProviderStuck.CONTENT_URI,
                        StuckConstants.TABLE_OFFLINE_POST);

                    this.getContentResolver().delete(contentUri,
                        StuckConstants.COLUMN_QUESTION + " = ?", new String[]{stuckPostSimple.getQuestion()});

                    SharedPreferences pref = getApplicationContext()
                        .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0); // 0 - for private mode
                    mAuth.addAuthStateListener(mAuthStateListener);

                    SharedPreferences.Editor editor = pref.edit();

                    editor.putBoolean(StuckConstants.USER_MADE_OFFLINE_POST, false);
                    editor.apply();

                    retieveAllUsersStarredPostRefsAndInitializeAdapter(mEmail);
                }

                getLoaderManager().restartLoader(StuckConstants.LOADER_ID, null, this);
            } else {
                StuckNewPostActivity.showErrorLocationDialog(this);
            }
        }
    }

    private void retieveAllUsersStarredPostRefsAndInitializeAdapter(String encodedEmail) {
        mProgressSpinnerDialog.setVisibility(View.VISIBLE);
        mStarPostRefs = new ArrayList<>();

        DatabaseReference userStarredVotes = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_STARRED_POST)
            .child(encodedEmail);

        Log.i(TAG, "user starred votes = " + userStarredVotes.toString());
        if (NetworkStatus.isOnline(this)) {

            userStarredVotes.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    mProgressSpinnerDialog.setVisibility(View.GONE);
                    final List<String> refsUserStarredPosts = new ArrayList<>();

                    for (DataSnapshot postRefSnapShot : dataSnapshot.getChildren()) {

                        refsUserStarredPosts.add(postRefSnapShot.getKey());
                    }

                    mStarPostRefs = refsUserStarredPosts;

                    initializeAdapter(refsUserStarredPosts);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    mProgressSpinnerDialog.setVisibility(View.GONE);
                }
            });
        } else {
            NetworkStatus.showOffLineDialog(this);
            mProgressSpinnerDialog.setVisibility(View.GONE);
        }
    }

    private void setMyStarPostAdapter() {
        mDeductByDeletedPosts = 0;
        mProgressSpinnerDialog.setVisibility(View.VISIBLE);

        mSetUpStarredPostsAdapterCounter = 0;
        final String encodedEmail = StuckSignUpActivity.encodeEmail(mEmail);
        DatabaseReference userStarredVotes = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_STARRED_POST)
            .child(encodedEmail);

        userStarredVotes.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mProgressSpinnerDialog.setVisibility(View.GONE);

                final List<String> refsStarredPosts = new ArrayList<>();
                final List<String> refsStarredPostsKey = new ArrayList<String>();

                for (DataSnapshot postRefSnapShot : dataSnapshot.getChildren()) {
                    refsStarredPosts.add(postRefSnapShot.getValue(String.class));
                    refsStarredPostsKey.add(postRefSnapShot.getKey());
                }

                ifRefsAreEmptyShowEmptyStarMessage(
                    refsStarredPosts, new ArrayList<StuckPostSimple>(), refsStarredPostsKey);

                retrieveStarredPostsAndUpdateList(refsStarredPosts, refsStarredPostsKey);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                mProgressSpinnerDialog.setVisibility(View.GONE);

            }
        });
    }

    /**
     * Gets all star posts and display it and will remove deleted posts that were starred
     * @param refsStarredPosts - ref to active posts url
     * @param refsStarredPostsKey - starred posts key
     */
    private void retrieveStarredPostsAndUpdateList(final List<String> refsStarredPosts,
                                                   final List<String> refsStarredPostsKey) {

        final List<StuckPostSimple> stuckPostSimplesStarred = new ArrayList<>();
        for (int i = 0; i < refsStarredPosts.size(); i++) {
            DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReferenceFromUrl(refsStarredPosts.get(i));

            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    if (dataSnapshot != null) {

                        StuckPostSimple starredPost = dataSnapshot.getValue(
                            StuckPostSimple.class);
                        //Check if star posts were deleted
                        try {
                            starredPost.setDatabaseReference(dataSnapshot.getRef());
                            mSetUpStarredPostsAdapterCounter++;
                            stuckPostSimplesStarred.add(starredPost);
                        } catch (Exception e) {
                            mDeductByDeletedPosts++;
                            DatabaseReference databaseReferenceRemove =
                                FirebaseDatabase.getInstance().getReference()
                                    .child(StuckConstants.FIREBASE_STARRED_POST)
                                    .child(mEmail).child(dataSnapshot.getKey());
                            databaseReferenceRemove.removeValue();
                        }

                        List<StuckPostSimple> temp = new ArrayList<>();

                        //reverse the order to show most recent placed first
                        if (mSetUpStarredPostsAdapterCounter ==
                            refsStarredPosts.size() - mDeductByDeletedPosts) {

                            for (int i = stuckPostSimplesStarred.size() - 1; i >= 0; i--) {
                                temp.add(stuckPostSimplesStarred.get(i));
                            }
                            mProgressSpinnerDialog.setVisibility(View.GONE);

                            if (temp.size() == 0){
                                mEmptyListCreateAPost.setVisibility(View.VISIBLE);
                                mEmptyListCreateAPost.setText(R.string.dont_have_starred_posts);
                            }
                            mAdapter = new CardViewPostAdapter(temp,
                                StuckMainListActivity.this, refsStarredPostsKey);
                            mRecyclerViewQuestions.setAdapter(mAdapter);
                            mAdapter.notifyDataSetChanged();
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    mProgressSpinnerDialog.setVisibility(View.GONE);

                }
            });
        }
    }

    /**
     * Shows no starred posts message if list is empty
     * @param refsStarredPosts - starred refs size
     * @param stuckPostSimplesStarred - empty filler list for adapter
     * @param refsStarredPostsKey - empty filler list for adapter
     */
    private void ifRefsAreEmptyShowEmptyStarMessage(List<String> refsStarredPosts,
                                                    List<StuckPostSimple> stuckPostSimplesStarred,
                                                    List<String> refsStarredPostsKey) {
        if (refsStarredPosts.size() == 0) {
            mEmptyListCreateAPost.setVisibility(View.VISIBLE);
            mEmptyListCreateAPost.setText(R.string.dont_have_starred_posts);

            //makes empty list and sets the adapter
            mAdapter = new CardViewPostAdapter(stuckPostSimplesStarred,
                StuckMainListActivity.this, refsStarredPostsKey);
            mRecyclerViewQuestions.setAdapter(mAdapter);
            mAdapter.notifyDataSetChanged();
        } else {
            mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
        }
    }

    @SuppressWarnings("deprecation")
    private void adjustToolbarByClickedImageTab(int pos) {
        if (pos == 0) {
            mToolbarViewLeft.setBackgroundColor(getResources().getColor(R.color.colorWhite));
            mToolbarImageViewLeft.setImageResource(R.mipmap.icons_stuck_group_clear);

            mToolbarViewMiddle.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            mToolbarImageViewMiddle.setImageResource(R.mipmap.icons_stuck_shaded_me);

            mToolbarViewRight.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            mToolbarImageViewRight.setImageResource(R.mipmap.filled_star_white);
        } else if (pos == 1) {
            mToolbarViewLeft.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            mToolbarImageViewLeft.setImageResource(R.mipmap.icons_stuck_group_shaded);

            mToolbarViewMiddle.setBackgroundColor(getResources().getColor(R.color.colorWhite));
            mToolbarImageViewMiddle.setImageResource(R.mipmap.icons_stuck_me_clear);

            mToolbarViewRight.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            mToolbarImageViewRight.setImageResource(R.mipmap.filled_star_white);
        } else {
            mToolbarViewLeft.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            mToolbarImageViewLeft.setImageResource(R.mipmap.icons_stuck_group_shaded);

            mToolbarViewMiddle.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            mToolbarImageViewMiddle.setImageResource(R.mipmap.icons_stuck_shaded_me);

            mToolbarViewRight.setBackgroundColor(getResources().getColor(R.color.colorWhite));
            mToolbarImageViewRight.setImageResource(R.mipmap.filled_star_blue);
        }
    }

    /**
     * Sets up window animation if build version is greater than 21
     * Uses explode to enter or exit
     */
    private void setupWindowAnimations() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Explode explode = new Explode();
            explode.setDuration(500);
            // inside your activity (if you did not enable transitions in your theme)
            getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);

            getWindow().setEnterTransition(explode);

            Slide slide = new Slide();
            slide.setDuration(500);
            getWindow().setReturnTransition(slide);

            // set an exit transition
            getWindow().setExitTransition(new Explode());
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri contentUri = Uri.withAppendedPath(ContentProviderStuck.CONTENT_URI,
            StuckConstants.TABLE_OFFLINE_POST);

        return new CursorLoader(
            this,
            contentUri,
            null,
            null,
            null,
            null);
    }


    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        stuckPostsLoaded = new ArrayList<>();
        if (data == null) {
            return;
        }
        data.moveToFirst();
        //Got from http://stackoverflow.com/questions/10111166/get-all-rows-from-sqlite
        if (data.moveToFirst()) {

            while (!data.isAfterLast()) {

                //Loads posts that were saved offline
                if (data.getString(data.getColumnIndex(StuckConstants.COLUMN_MOST_RECENT_POST))
                    .equals(StuckConstants.FALSE)) {

                    String stuckEmail = data.getString(data
                        .getColumnIndex(StuckConstants.COLUMN_EMAIL));

                    String stuckQuestion = data.getString(data
                        .getColumnIndex(StuckConstants.COLUMN_QUESTION));

                    String stuckLocation = data.getString(data
                        .getColumnIndex(StuckConstants.COLUMN_LOCATION));

                    String stuckChoice1 = data.getString(data
                        .getColumnIndex(StuckConstants.COLUMN_CHOICE_ONE));

                    String stuckChoice2 = data.getString(data
                        .getColumnIndex(StuckConstants.COLUMN_CHOICE_TWO));

                    String stuckChoice3 = data.getString(data
                        .getColumnIndex(StuckConstants.COLUMN_CHOICE_THREE));

                    String stuckChoice4 = data.getString(data
                        .getColumnIndex(StuckConstants.COLUMN_CHOICE_FOUR));

                    StuckPostSimple stuckPostSimple = new StuckPostSimple(
                        StuckSignUpActivity.encodeEmail(stuckEmail), stuckQuestion,
                        stuckLocation,
                        stuckChoice1, stuckChoice2, stuckChoice3, stuckChoice4,
                        StuckConstants.ZERO_VOTES, StuckConstants.ZERO_VOTES,
                        StuckConstants.ZERO_VOTES, StuckConstants.ZERO_VOTES,
                        new HashMap<String, Object>(), (-1 * new Date().getTime()));

                    stuckPostsLoaded.add(stuckPostSimple);
                }
                data.moveToNext();
            }
        }
        addNewPostsToFirebase();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {}

    @OnClick(R.id.fab_add)
    public void setNewPostFAB(View view) {
        Intent intent = new Intent(this, StuckNewPostActivity.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            startActivity(intent,
                ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
        } else {
            startActivity(intent);
        }
    }

    @OnClick(R.id.main_toolbar_left_view_background)
    public void leftToolbarViewClick() {
        mTabSection = 0;
        mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
        mLocationToFilterBy = null;
        adjustToolbarByClickedImageTab(mTabSection);
        retieveAllUsersStarredPostRefsAndInitializeAdapter(mEmail);
        setUpFilterView(false);
    }

    @SuppressWarnings("deprecation")
    @OnClick(R.id.main_toolbar_left_imageview_background)
    public void leftToolbarClick(View v) {
        mTabSection = 0;
        mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
        mLocationToFilterBy = null;
        adjustToolbarByClickedImageTab(mTabSection);
        retieveAllUsersStarredPostRefsAndInitializeAdapter(mEmail);
        setUpFilterView(false);
    }

    @OnClick(R.id.main_toolbar_middle_view_background)
    public void middleToolbarViewClick() {
        mTabSection = 1;
        mLocationToFilterBy = null;
        adjustToolbarByClickedImageTab(mTabSection);
        setMyPostAdapter();
        setUpFilterView(false);
    }

    @SuppressWarnings("deprecation")
    @OnClick(R.id.main_toolbar_middle_imageview_background)
    public void middleToolbarClick(View v) {
        mTabSection = 1;
        mLocationToFilterBy = null;
        adjustToolbarByClickedImageTab(1);
        mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
        setMyPostAdapter();
        setUpFilterView(false);
    }

    @OnClick(R.id.main_toolbar_right_view_background)
    public void rightToolbarViewClick() {
        mTabSection = 2;
        mLocationToFilterBy = null;
        mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
        adjustToolbarByClickedImageTab(mTabSection);
        setMyStarPostAdapter();
        setUpFilterView(false);
    }


    @SuppressWarnings("deprecation")
    @OnClick(R.id.main_toolbar_right_imageview_background)
    public void rightToolbarClick(View v) {
        mTabSection = 2;
        mLocationToFilterBy = null;
        mEmptyListCreateAPost.setVisibility(View.INVISIBLE);
        adjustToolbarByClickedImageTab(mTabSection);
        setMyStarPostAdapter();
        setUpFilterView(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences pref = getApplicationContext()
            .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0); // 0 - for private mode
        mAuth.addAuthStateListener(mAuthStateListener);

        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
        }

        if (pref.getBoolean(StuckConstants.USER_MADE_OFFLINE_POST, true)) {
            //Check if db has user posts
            getLoaderManager().initLoader(StuckConstants.LOADER_ID, null, this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mAuthStateListener != null) {
            mAuth.removeAuthStateListener(mAuthStateListener);
        }

        startTimedNotification();
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthStateListener != null) {
            mAuth.removeAuthStateListener(mAuthStateListener);
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
