package com.superpak.sammengistu.stuckapp.dialogs;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.adapters.FilterListAdapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class FilterDialog extends DialogFragment {

    private EditText mEditText;
    private ListView mFilteredItemsLV;
    private DatabaseReference mDatabaseRefLocation;
    private List<String> mPostLocations;
    OnMyDialogResult mDialogResult; // the callback
    private List<String> mFilteredLocationNames;
    private TextView mNoPostTextView;

    private TextWatcher mFilterTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}

        @Override
        public void afterTextChanged(Editable typedInWord) {
            new SearchForLocationTask().execute(typedInWord.toString());
        }
    };

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        View filterView = getActivity().getLayoutInflater()
            .inflate(R.layout.dialog_filter_location, null);


        mFilteredLocationNames = new ArrayList<>();

        mEditText = (EditText) filterView.findViewById(R.id.filter_location_edit_text);
        mFilteredItemsLV = (ListView) filterView.findViewById(android.R.id.list);
        mNoPostTextView = (TextView) filterView.findViewById(R.id.couldnt_find_location_text);

        mNoPostTextView.setVisibility(View.INVISIBLE);

        mDatabaseRefLocation = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_POST_LOCATION);

        mPostLocations = new ArrayList<>();

        mDatabaseRefLocation.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot locSnap: dataSnapshot.getChildren()) {
                    String location = locSnap.getValue(String.class);
                    mPostLocations.add(location);

                }
                mFilteredLocationNames =  new ArrayList<>(mPostLocations);
                mFilteredItemsLV.setAdapter(new FilterListAdapter(mFilteredLocationNames, getActivity()));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        mEditText.addTextChangedListener(mFilterTextWatcher);

        mFilteredItemsLV.setOnItemClickListener(new LocationSelectedListener());

        return new AlertDialog.Builder(getActivity())
            .setView(filterView)
            .setNegativeButton(android.R.string.cancel, null)
            .show();
    }

    /**
     * This listener sends the selected location back to StuckMainListActivity
     */
    private class LocationSelectedListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if (mDialogResult != null ) {
                if (mFilteredLocationNames == null) {
                    mFilteredLocationNames = mPostLocations;
                }
                mDialogResult.finish(mFilteredLocationNames.get(position));
            }
            FilterDialog.this.dismiss();
        }
    }

    /**
     * SearchForLocationTask Class finds all the locations that have the passed in word in them
     */
    private class SearchForLocationTask extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... params) {

            mFilteredLocationNames.clear();

            for (String locationName : mPostLocations ) {

                if (doesItContainWord(locationName, params[0])){

                    mFilteredLocationNames.add(locationName);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (mFilteredLocationNames.size() == 0) {
                mNoPostTextView.setVisibility(View.VISIBLE);
            } else {
                mNoPostTextView.setVisibility(View.INVISIBLE);
            }
            mFilteredItemsLV.setAdapter(new FilterListAdapter(mFilteredLocationNames, getActivity()));
        }
    }

    public boolean doesItContainWord(String locationName , String typedInWord){
        return locationName != null && typedInWord != null
            && locationName.toLowerCase().contains(typedInWord.toLowerCase());
    }

    public void setDialogResult(OnMyDialogResult dialogResult){
        mDialogResult = dialogResult;
    }

    public interface OnMyDialogResult{
        void finish(String result);
    }
}
