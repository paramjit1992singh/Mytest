package com.superpak.sammengistu.stuckapp.dialogs;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import com.superpak.sammengistu.stuckapp.R;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;

public class PopUpMapDialog extends DialogFragment {

    private static final String ADDRESS_TO_SHOW_ON_MAP = "Address for map";

    private GoogleMap mGoogleMap;

    private MapView mMapView;
    private List<android.location.Address> geocodeMatches;

    private String mAddress;

    @NonNull
    @SuppressWarnings("deprecation")
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        View v = getActivity().
            getLayoutInflater()
            .inflate(R.layout.fragment_location_info_dialog, null);

        mMapView = (MapView) v.findViewById(R.id.mapView);
        mMapView.onCreate(savedInstanceState);

        mMapView.onResume();// needed to get the map to display immediately

        mAddress = getArguments().getString(ADDRESS_TO_SHOW_ON_MAP);

        TextView title = ((TextView) v.findViewById(R.id.fragment_location_pop_title_of_location));
        title.setText(getArguments().getString(ADDRESS_TO_SHOW_ON_MAP));


        geocodeMatches = null;

        try {
            MapsInitializer.initialize(getActivity().getApplicationContext());
        } catch (Exception e) {
            e.printStackTrace();
        }

        mGoogleMap = mMapView.getMap();

        showAddressOnMap(mAddress);

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(v);

        builder.setNeutralButton(getString(R.string.cancel), null);

        AlertDialog alertDialog = builder.create();

        alertDialog.show();

        return alertDialog;
    }

    private void showAddressOnMap(String address) {
        double latitude;
        double longitude;

        try {
            geocodeMatches =
                new Geocoder(getActivity()).getFromLocationName(
                    address, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!geocodeMatches.isEmpty()) {
            latitude = geocodeMatches.get(0).getLatitude();
            longitude = geocodeMatches.get(0).getLongitude();

            // Changing marker icon
            mGoogleMap.addMarker(
                new MarkerOptions().position(new LatLng(latitude, longitude))
                    .visible(true));

            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 15));
        }
    }

    public static PopUpMapDialog newInstance(String address) {
        Bundle bundle = new Bundle();
        bundle.putString(ADDRESS_TO_SHOW_ON_MAP, address);

        PopUpMapDialog popUpMapDialog = new PopUpMapDialog();
        popUpMapDialog.setArguments(bundle);

        return popUpMapDialog;
    }
}
