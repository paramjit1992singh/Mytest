package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.NetworkStatus;
import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.model.User;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class StuckSignUpActivity extends AppCompatActivity implements
    GoogleApiClient.OnConnectionFailedListener {

    private GoogleApiClient mGoogleApiClient;
    private String mEncodedEmail;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseAuth mAuth;

    @BindView(R.id.name_edit_text)
    EditText mNameField;
    @BindView(R.id.email_edit_text)
    EditText mEmailField;
    @BindView(R.id.password_edit_text)
    EditText mPasswordField;
    @BindView(R.id.reenter_password_edit_text)
    EditText mRE_EnterField;
    @BindView(R.id.companyName_edit_text)
    EditText mCompanyNameField;
    @BindView(R.id.mobileNumber_edit_text)
    EditText mMobileNumberField;
    @BindView(R.id.create_account_button)
    Button mCreateAccountButton;
    @BindView(R.id.go_to_login_account)
    TextView mLoginTextView;
    @BindView(R.id.sign_in_button_google)
    SignInButton mSignInButtonGoogle;

    private DatabaseReference.CompletionListener mCompletionListenerSignUp =
        new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError databaseError,
                                   DatabaseReference databaseReference) {
                if (databaseError != null) {

                } else {
                    Toast.makeText(StuckSignUpActivity.this,
                        R.string.account_created, Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(StuckSignUpActivity.this,
                        StuckLoginActivity.class);
                    StuckSignUpActivity.this.startActivity(intent);
                }
            }
        };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        ButterKnife.bind(this);

        connectWithGoogle();

        mAuth = FirebaseAuth.getInstance();
        mRE_EnterField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    putEmailInSharedPref(user.getEmail().toLowerCase(), StuckSignUpActivity.this,
                        user.getProviders().get(0));
                    createUserInFBHelper(mEncodedEmail);

                }
            }
        };
    }

    private void connectWithGoogle(){
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build();

        // Build a GoogleApiClient with access to the Google Sign-In API and the
        // options specified by gso.
        mGoogleApiClient = new GoogleApiClient.Builder(this)
            .enableAutoManage(this /* FragmentActivity */, this /* OnConnectionFailedListener */)
            .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
            .build();
    }

    public static void putEmailInSharedPref(String email, Activity activity, String provider) {
        SharedPreferences pref = activity.getApplicationContext()
            .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0);
        SharedPreferences.Editor editor = pref.edit();
        //on the login store the login
        editor.putString(StuckConstants.KEY_ENCODED_EMAIL, encodeEmail(email.toLowerCase()));
        editor.putString(StuckConstants.PROVIDER, provider);
        editor.apply();
    }

    /**
     * Checks to see if user already has an account before creating them another one
     * @param emailUser - email to search for
     */
      private void createUserInFBHelper(String emailUser) {
        final String encodedEmail = encodeEmail(emailUser);
        final DatabaseReference userLocation = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_USERS)
            .child(encodedEmail);

        /**
         * See if there is already a user (for example, if they already logged in with an associated
         * Google account.
         */
        userLocation.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                /* If there is no user, make one */
                if (dataSnapshot.getValue() == null) {
                    /* Set raw version of date to the ServerValue.TIMESTAMP
                     value and save into dateCreatedMap */
                    HashMap<String, Object> timestampJoined = new HashMap<>();
                    timestampJoined.put(StuckConstants.FIREBASE_PROPERTY_TIMESTAMP,
                        ServerValue.TIMESTAMP);

                    User newUser = new User(encodedEmail, timestampJoined);
                    userLocation.setValue(encodedEmail);

                    userLocation.setValue(newUser,mCompletionListenerSignUp);
                    final SharedPreferences pref = getApplicationContext()
                        .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0); // 0 - for private mode

                    SharedPreferences.Editor editor = pref.edit();
                    editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_NEW_POST_DIALOG, true);
                    editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_MAIN_DIALOG, true);
                    editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_VOTE_DIALOG, true);
                    editor.putBoolean(StuckConstants.SHOW_USER_HOW_TO_USE_FILTER, true);
                    editor.apply();
                } else {

                    Intent intent = new Intent(StuckSignUpActivity.this, StuckMainListActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {}
        });
    }

    /**
     * Actually creates the user in the auth section of firebase
     * @param dialog - dialog to dismiss
     */
    private void createUser(final ProgressDialog dialog) {

        final String email = mEmailField.getText().toString().toLowerCase();
        final String name = mNameField.getText().toString().toLowerCase();
        final String companyName = mCompanyNameField.getText().toString().toLowerCase();
        final String mobileNumber = mMobileNumberField.getText().toString().toLowerCase();
        String password = mPasswordField.getText().toString();

        mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    dialog.dismiss();

                    // If sign in fails, display a message to the user. If sign in succeeds
                    // the auth state listener will be notified and logic to handle the
                    // signed in user can be handled in the listener.
                    if (!task.isSuccessful()) {
                        Toast.makeText(StuckSignUpActivity.this,
                            StuckSignUpActivity.this.getString(R.string.authentication_failed),
                            Toast.LENGTH_SHORT).show();

                        new AlertDialog.Builder(StuckSignUpActivity.this)
                            .setTitle(getString(R.string.error_creating_account_title))
                            .setMessage(getString(R.string.error_creating_account_message))
                            .setPositiveButton(getString(R.string.okay), null)
                            .show();
                    } else {
                        mEncodedEmail = encodeEmail(email);
                    }
                }
            })
            .addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    dialog.dismiss();
                }
            });
    }

    /**
     * Firebase doesnt allow periods so the period is replaced with a comma
     *
     * @param userEmail - normal email
     * @return - encoded email
     */
    public static String encodeEmail(String userEmail) {
        if (userEmail == null){
            return "";
        }
        return userEmail.replace(".", ",");
    }

    public static boolean validEmail(String email) {
        return email != null && email.contains("@") && email.contains(".") && !email.contains(" ");
    }

    private boolean isValidMobile(String phone) {
        return android.util.Patterns.PHONE.matcher(phone).matches();
    }

    public static boolean passwordsMatch(String passwordField, String reenterField) {
        return passwordField != null && reenterField != null && passwordField.equals(reenterField);
    }

    private boolean allFieldsAreEntered() {

        return !mEmailField.getText().toString().equals("") &&
            !mEmailField.getText().toString().equals("") &&
                !mEmailField.getText().toString().equals("") &&
                !mNameField.getText().toString().equals("") &&
                !mCompanyNameField.getText().toString().equals("")&&
                !mMobileNumberField.getText().toString().equals("");
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, StuckConstants.RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == StuckConstants.RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess()) {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = result.getSignInAccount();
                mEncodedEmail = StuckSignUpActivity.encodeEmail(account.getEmail().toLowerCase());

            } else {
                // Google Sign In failed, update UI appropriately
                Toast.makeText(this, R.string.google_signin_failed, Toast.LENGTH_LONG).show();
            }
        }
    }

    @OnClick(R.id.go_to_login_account)
    public void onClickLoginActivity() {
        Intent intent = new Intent(this, StuckLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }


    @OnClick(R.id.create_account_button)
    public void onClickCreate() {
        final ProgressDialog dialog = new ProgressDialog(this);
        dialog.setMessage("Creating account");
        dialog.show();

        mEncodedEmail = encodeEmail(mEmailField.getText().toString().toLowerCase());

        if (NetworkStatus.isOnline(this)) {
            if (allFieldsAreEntered() && passwordsMatch(mPasswordField.getText().toString(),
                mRE_EnterField.getText().toString()) && validEmail(mEmailField.getText().toString()) && isValidMobile(mMobileNumberField.getText().toString())) {

                if (mPasswordField.getText().toString().length() >= 5) {

                    createUser(dialog);

                } else {
                    Toast.makeText(this, R.string.make_password_longer, Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                }
            } else {
                new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.error))
                    .setMessage(getString(R.string.error_in_sign_up))
                    .setPositiveButton(getString(R.string.okay), null)
                    .show();
                dialog.dismiss();
            }
        } else {
            NetworkStatus.showOffLineDialog(this);
            dialog.dismiss();
        }
    }

    @OnClick(R.id.sign_in_button_google)
    public void onClick(View v){
        switch (v.getId()) {
            case R.id.sign_in_button_google:
                signIn();
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
        FirebaseAuth.getInstance().signOut();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
