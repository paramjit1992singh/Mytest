package com.superpak.sammengistu.stuckapp.adapters;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.NetworkStatus;
import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.activities.StuckSignUpActivity;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;
import com.superpak.sammengistu.stuckapp.model.VoteChoice;
import com.superpak.sammengistu.stuckapp.viewHolders.VoteChoicesADViewHolder;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;

import java.util.List;


public class VoteChoicesAdapter extends RecyclerView.Adapter<VoteChoicesADViewHolder> {

    private List<VoteChoice> mStuckPostChoices;
    private Context mContext;
    private int mShowAnimation;
    private DatabaseReference mFireBaseRefForVotes;
    private StuckPostSimple mStuckPostSimple;
    private String mUserEmail;
    private DatabaseReference mUsersVoteValue;

    // Provide a suitable constructor (depends on the kind of dataset)
    public VoteChoicesAdapter(List<VoteChoice> myDataset, Context context,
                              String fireBaseRef, StuckPostSimple stuckPostSimple, String postKey) {
        mStuckPostChoices = myDataset;
        mContext = context;
        mShowAnimation = 0;
        mFireBaseRefForVotes = FirebaseDatabase.getInstance()
            .getReferenceFromUrl(fireBaseRef);
        mStuckPostSimple = stuckPostSimple;

        SharedPreferences preferences = mContext.getApplicationContext()
            .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0);

        mUserEmail = StuckSignUpActivity.encodeEmail(
            preferences.getString(StuckConstants.KEY_ENCODED_EMAIL, ""));

        mUsersVoteValue = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_USERS_VOTES).child(mUserEmail)
            .child(postKey);
    }

    // Create new views (invoked by the layout manager)
    @Override
    public VoteChoicesADViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.stuck_view_choice, parent, false);
        // set the view's size, margins, padding and layout parameters

        return new VoteChoicesADViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @SuppressWarnings("deprecation")
    @Override
    public void onBindViewHolder(VoteChoicesADViewHolder holder, int position) {

        final int pos = position;
        final VoteChoicesADViewHolder currentViewHolder = holder;
        final VoteChoice currentChoice = mStuckPostChoices.get(position);

        mUsersVoteValue.addListenerForSingleValueEvent(
            new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {

                    if (snapshot != null) {
                        Integer integer = snapshot.getValue(Integer.class);

                        if (integer == null) {
                            mUsersVoteValue.setValue(4);
                        } else {
                            if (integer == pos) {
                                currentChoice.setVotedFor(true);
                                currentViewHolder.mCardViewChoice.setBackgroundColor(
                                    mContext.getResources().getColor(R.color.colorVoted));
                            } else {
                                currentViewHolder.mCardViewChoice.setBackgroundColor(
                                    mContext.getResources().getColor(R.color.colorWhite));
                            }
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {}
            }
        );

        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        holder.mChoice.setText(currentChoice.getChoice());
        holder.mChoice.setTextColor(mContext.getResources().getColor(R.color.textColor));
        holder.mNumberOfVotes.setText(currentChoice.getVotes() + "");

        if (!mStuckPostSimple.getEmail().replaceAll("\\s", "").equals(
            mUserEmail.replaceAll("\\s", ""))) {
            holder.mCardViewChoice.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (NetworkStatus.isOnline(mContext)) {
                        //Change previous selected vote back down to one
                        adjustVotes();

                        updateVotes(currentChoice, pos, mUsersVoteValue, currentViewHolder);

                        notifyDataSetChanged();

                    } else {
                        NetworkStatus.showOffLineDialog(mContext);
                    }
                }
            });
        }

        showAnimation(holder, position);
    }

    private void showAnimation(VoteChoicesADViewHolder holder, int position) {
        //Shows animation when created and not notified
        if (mShowAnimation < mStuckPostChoices.size()) {
            mShowAnimation++;
            Animation fadeIn = new AlphaAnimation(0, 1);
            fadeIn.setInterpolator(new DecelerateInterpolator()); //add this
            fadeIn.setDuration(400 * position);

            holder.mCardViewChoice.startAnimation(fadeIn);
        }
    }

    private void adjustVotes() {
        for (int pos = 0; pos < mStuckPostChoices.size(); pos++) {
            VoteChoice currentChoice = mStuckPostChoices.get(pos);
            if (currentChoice.isVotedFor()) {
                currentChoice.setVotes(currentChoice.getVotes() - 1);

                if (pos == 0) {
                    mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_ONE_VOTES)
                        .setValue(currentChoice.getVotes());
                } else if (pos == 1) {
                    mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_TWO_VOTES)
                        .setValue(currentChoice.getVotes());
                } else if (pos == 2) {
                    mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_THREE_VOTES)
                        .setValue(currentChoice.getVotes());
                } else {
                    mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_FOUR_VOTES)
                        .setValue(currentChoice.getVotes());
                }
            }
        }
    }

    @SuppressWarnings("deprecation")
    private void updateVotes(VoteChoice currentChoice, int pos, DatabaseReference changeVoteValue,
                             VoteChoicesADViewHolder currentViewHolder) {

        if (currentChoice.isVotedFor()) {
            currentChoice.setVotedFor(false);
            changeVoteValue.setValue(4);
            currentViewHolder.mCardViewChoice.setBackgroundColor(
                mContext.getResources().getColor(R.color.colorWhite));

        } else {
            currentChoice.setVotedFor(true);
            currentChoice.setVotes(currentChoice.getVotes() + 1);

            if (pos == 0) {
                mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_ONE_VOTES)
                    .setValue(currentChoice.getVotes());
            } else if (pos == 1) {
                mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_TWO_VOTES)
                    .setValue(currentChoice.getVotes());
            } else if (pos == 2) {
                mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_THREE_VOTES)
                    .setValue(currentChoice.getVotes());
            } else {
                mFireBaseRefForVotes.child(StuckConstants.CHILD_CHOICE_FOUR_VOTES)
                    .setValue(currentChoice.getVotes());
            }

            changeVoteValue.setValue(pos);
        }
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mStuckPostChoices.size();
    }

}
