package com.superpak.sammengistu.stuckapp.adapters;

import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.model.Choice;
import com.superpak.sammengistu.stuckapp.viewHolders.MyPostChoiceADViewHolder;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.PorterDuff;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.List;


public class MyPostChoiceAdapter extends RecyclerView.Adapter<MyPostChoiceADViewHolder> {
    private List<Choice> mChoiceDataSet;
    private Context mAppContext;
    private FloatingActionButton mFloatingActionButton;
    private RecyclerView mCurrentRecyclerView;

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyPostChoiceAdapter(List<Choice> myDataset, Context appContext,
                               FloatingActionButton floatingActionButton,
                               RecyclerView currentRecyclerView) {
        mChoiceDataSet = myDataset;
        mAppContext = appContext;
        mFloatingActionButton = floatingActionButton;
        mCurrentRecyclerView = currentRecyclerView;

    }

    public void setRecyclerView (RecyclerView currentRecyclerView){
        mCurrentRecyclerView = currentRecyclerView;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyPostChoiceADViewHolder onCreateViewHolder(ViewGroup parent,
                                                       int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View v = inflater.inflate(R.layout.card_view_my_choice, parent, false);

        return new MyPostChoiceADViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @SuppressWarnings("deprecation")
    @Override
    public void onBindViewHolder(final MyPostChoiceADViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        final int pos = holder.getAdapterPosition();

        View.OnLongClickListener deleteChoiceListener = new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (mChoiceDataSet.size() > 2) {

                    AlertDialog.Builder deleteChoiceDialog =
                        new AlertDialog.Builder(mAppContext);

                    displayAndBuildDialog(deleteChoiceDialog, pos, holder);

                } else {
                    //Make toast cant
                    Toast.makeText(mAppContext, R.string.cant_delete_choice,
                        Toast.LENGTH_SHORT).show();
                }

                return false;
            }
        };

        holder.mChoiceEditText.setOnLongClickListener(deleteChoiceListener);
        holder.mChoiceEditText.getBackground().mutate().setColorFilter(mAppContext.getResources()
            .getColor(R.color.shade), PorterDuff.Mode.SRC_ATOP);

        holder.mChoiceEditText.setText(mChoiceDataSet.get(pos).getChoice());
        holder.mChoiceEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    mChoiceDataSet.get(pos).setChoice(s.toString());
                } catch (IndexOutOfBoundsException e){}
            }
        });

        holder.mChoiceCardView.setOnLongClickListener(deleteChoiceListener);
    }

    private void displayAndBuildDialog(AlertDialog.Builder deleteChoiceDialog, final int pos,
                                       MyPostChoiceADViewHolder holder) {
        deleteChoiceDialog.setTitle(mAppContext.getString(R.string.warning_delete_choice));
        deleteChoiceDialog.setMessage(mChoiceDataSet.get(pos).getChoice());
        deleteChoiceDialog.setPositiveButton(mAppContext.getString(R.string.delete),
            new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    mChoiceDataSet.remove(pos);

                    mCurrentRecyclerView.removeViewAt(pos);
                    mCurrentRecyclerView.getAdapter().notifyItemRemoved(pos);
                    mCurrentRecyclerView.getAdapter().notifyItemRangeChanged(pos,
                        mChoiceDataSet.size());

                    notifyDataSetChanged();
                    mFloatingActionButton.setVisibility(View.VISIBLE);
                    mFloatingActionButton.setEnabled(true);
                }
            });
        deleteChoiceDialog.setMessage(holder.mChoiceEditText.getText().toString());
        deleteChoiceDialog.setNegativeButton(mAppContext.getString(R.string.cancel), null);
        deleteChoiceDialog.show();
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mChoiceDataSet.size();
    }

}
