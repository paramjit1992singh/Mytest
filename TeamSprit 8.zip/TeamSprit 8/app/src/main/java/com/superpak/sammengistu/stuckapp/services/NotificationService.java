package com.superpak.sammengistu.stuckapp.services;

import com.superpak.sammengistu.stuckapp.NotifyUser;

import android.app.IntentService;
import android.content.Intent;
import android.os.IBinder;

import java.util.Random;


public class NotificationService extends IntentService {
    private final static String TAG = "ShowNotification";

    public NotificationService(){
        super("NotificationService");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        NotifyUser.notifyUset(this, pickRandomMessage());
    }

    private String pickRandomMessage(){
        String [] messages = new String[]{
            "Can't decide your next activity? Post it on TeamSpirit",
                "You must of been stuck about something in the past couple days",
            "Requesting back up, TeamSpirit users need your vote",
            "What language to learn next, lets find out!",
            "Place some votes on TeamSpirit"
        };
        Random random = new Random();

        return messages[random.nextInt(3)];
    }
}
