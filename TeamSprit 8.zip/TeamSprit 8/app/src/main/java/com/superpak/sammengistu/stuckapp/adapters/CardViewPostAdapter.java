package com.superpak.sammengistu.stuckapp.adapters;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.NetworkStatus;
import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.activities.StuckSignUpActivity;
import com.superpak.sammengistu.stuckapp.activities.StuckVoteActivity;
import com.superpak.sammengistu.stuckapp.dialogs.PopUpMapDialog;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;


public class CardViewPostAdapter extends RecyclerView
    .Adapter<CardViewPostAdapter.CardViewListADViewHolder> {

    private List<StuckPostSimple> mStuckPostSimples;
    private static Activity mActivity;
    private static String mUserEmailEncoded;
    public static List<String> mStarredPostRefs;

    public CardViewPostAdapter(List<StuckPostSimple> stuckPostSimples,
                               Activity activity, List<String > starredPostRefs){
        mStuckPostSimples = stuckPostSimples;
        mActivity = activity;
        mStarredPostRefs = starredPostRefs;

        try {
            mUserEmailEncoded = StuckSignUpActivity.encodeEmail(
                FirebaseAuth.getInstance().getCurrentUser().getEmail());
        } catch (NullPointerException e){
            FirebaseAuth.getInstance().signOut();
        }
    }

    @Override
    public CardViewListADViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View v = inflater.inflate(R.layout.stuck_single_item_question, parent, false);
        return new CardViewListADViewHolder(v);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBindViewHolder(final CardViewListADViewHolder cardViewListADViewHolder, int position) {

        cardViewListADViewHolder.mCardViewPostAdapter = this;

        final int pos = cardViewListADViewHolder.getAdapterPosition();
        final StuckPostSimple stuckPostSimple = mStuckPostSimples.get(pos);

        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        cardViewListADViewHolder.mStuckPostQuestion.setText(stuckPostSimple.getQuestion());
        cardViewListADViewHolder.mStuckPostQuestion.setTextColor(mActivity.getResources()
            .getColor(R.color.textColor));
        cardViewListADViewHolder.mStuckPostLocation.setText(stuckPostSimple.getLocation());

        setUpStar(stuckPostSimple.getDatabaseReference(),
            cardViewListADViewHolder.mStarredImageView,
            cardViewListADViewHolder);

        cardViewListADViewHolder.mStarredImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mStarredPostRefs.contains(cardViewListADViewHolder.mRef.getKey())){
                    CardViewPostAdapter.addPostToStarredPosts(cardViewListADViewHolder.mRef, false);
                    cardViewListADViewHolder.mStarredImageView.setImageResource(R.mipmap.empty_star);
                } else {

                    CardViewPostAdapter.addPostToStarredPosts(cardViewListADViewHolder.mRef, true);
                    cardViewListADViewHolder.mStarredImageView.setImageResource(R.mipmap.filled_star);
                }
            }
        });

        String choiceOne = stuckPostSimple.getChoiceOne();

        setUpChoiceOneView(choiceOne, cardViewListADViewHolder);

        cardViewListADViewHolder.mRef = stuckPostSimple.getDatabaseReference();

        DatabaseReference databaseReference = FirebaseDatabase.getInstance()
            .getReferenceFromUrl(cardViewListADViewHolder.mRef.toString());

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot != null) {

                    try {
                        StuckPostSimple stuckPostSimpleTemp = dataSnapshot.getValue(StuckPostSimple.class);
                        int totalVotesLive = stuckPostSimpleTemp.getChoiceOneVotes() +
                            stuckPostSimpleTemp.getChoiceTwoVotes() +
                            stuckPostSimpleTemp.getChoiceThreeVotes() + stuckPostSimpleTemp.getChoiceFourVotes();

                        String totalVote = totalVotesLive + "";
                        cardViewListADViewHolder.mStuckPostTotalVotes.setText(totalVote);
                    } catch (Exception e) {
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        int totalVotes = stuckPostSimple.getChoiceOneVotes() + stuckPostSimple.getChoiceTwoVotes() +
            stuckPostSimple.getChoiceThreeVotes() + stuckPostSimple.getChoiceFourVotes();

        String totalVote = totalVotes + "";
        cardViewListADViewHolder.mStuckPostTotalVotes.setText(totalVote);

        //Set up stuck info for stuck vote activity
        cardViewListADViewHolder.mCurrentStuckPost = stuckPostSimple;

    }

    private void setUpChoiceOneView(String choiceOne, CardViewListADViewHolder cardViewListADViewHolder) {
        //Shows preview of the first choice
        if (choiceOne.length() > 9) {
            String sneakPeak = choiceOne.substring(0, 9) + "...";
            cardViewListADViewHolder.mStuckPostSneakPeakChoice.setText(sneakPeak);
        } else {
            cardViewListADViewHolder.mStuckPostSneakPeakChoice.setText(choiceOne);

        }
    }

    public static boolean isPostStarred(DatabaseReference postRef){
        return mStarredPostRefs.contains(postRef.getKey());
    }

    public static void addPostToStarredPosts(DatabaseReference ref, boolean addPost){

        if (addPost){
            mStarredPostRefs.add(ref.getKey());
            DatabaseReference starredVotes =
                FirebaseDatabase.getInstance().getReference()
                    .child(StuckConstants.FIREBASE_STARRED_POST);

            starredVotes.child(mUserEmailEncoded)
                .child(ref.getKey())
                .setValue(ref.toString());
        } else {
            for (int i = 0; i < mStarredPostRefs.size(); i++) {

                if (mStarredPostRefs.get(i).contains(ref.getKey())) {
                    mStarredPostRefs.remove(i);

                    DatabaseReference starredVotes =
                        FirebaseDatabase.getInstance().getReference()
                            .child(StuckConstants.FIREBASE_STARRED_POST);

                    starredVotes.child(mUserEmailEncoded)
                        .child(ref.getKey()).removeValue();
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return mStuckPostSimples.size();
    }

    public void setUpStar(DatabaseReference currentPostRef, ImageView starredImageView,
                          CardViewListADViewHolder cardViewListADViewHolder) {

        if (mStarredPostRefs.contains(currentPostRef.getKey())) {
            cardViewListADViewHolder.mStar = true;
            starredImageView.setImageResource(R.mipmap.filled_star);
        } else {
            cardViewListADViewHolder.mStar  = false;
            starredImageView.setImageResource(R.mipmap.empty_star);

        }
    }

    /**
     * ViewHolder for adapter items
     */
    public static class CardViewListADViewHolder extends RecyclerView.ViewHolder {

        public final TextView mStuckPostQuestion;
        public final TextView mStuckPostLocation;
        public final TextView mStuckPostSneakPeakChoice;
        public final TextView mStuckPostFromTitle;
        public final TextView mStuckPostTotalVotes;
        public DatabaseReference mRef;
        public final ImageView mStarredImageView;
        public boolean mStar;

        public CardViewPostAdapter mCardViewPostAdapter;

        public StuckPostSimple mCurrentStuckPost;

        public CardViewListADViewHolder(View v) {
            super(v);
            mStuckPostQuestion = (TextView) v.findViewById(R.id.single_item_question_text_view);
            mStuckPostFromTitle = (TextView) v.findViewById(R.id.post_from_title);
            mStuckPostLocation = (TextView) v.findViewById(R.id.post_location_name);
            mStuckPostSneakPeakChoice = (TextView) v.findViewById(R.id.sneak_peak_choice_1);
            mStuckPostTotalVotes = (TextView) v.findViewById(R.id.stuck_question_total_votes);
            mStarredImageView = (ImageView) v.findViewById(R.id.starred_post);

            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent stuckVoteIntent = new Intent(CardViewPostAdapter.mActivity,
                        StuckVoteActivity.class);

                    stuckVoteIntent.putExtra(StuckConstants.STUCK_POST, mCurrentStuckPost);

                    stuckVoteIntent.putExtra(StuckConstants.FIREBASE_REF, mRef.toString());

                    stuckVoteIntent.putExtra(StuckConstants.STARRED, mStar);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        // only for gingerbread and newer versions
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            CardViewPostAdapter.mActivity.startActivity(stuckVoteIntent,
                                ActivityOptions.makeSceneTransitionAnimation(
                                    CardViewPostAdapter.mActivity).toBundle());
                        } else {
                            CardViewPostAdapter.mActivity.startActivity(stuckVoteIntent);
                        }
                    }
                }
            });

            mStuckPostFromTitle.setOnClickListener(mLocationGoogleMap);
            mStuckPostLocation.setOnClickListener(mLocationGoogleMap);
        }

        private View.OnClickListener mLocationGoogleMap = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkStatus.isOnline(mActivity)) {
                    FragmentManager fm = CardViewPostAdapter.mActivity.getFragmentManager();
                    PopUpMapDialog popUpMapDialog = PopUpMapDialog.newInstance(
                        mStuckPostLocation.getText().toString());
                    popUpMapDialog.show(fm, "");
                } else {
                    NetworkStatus.showOffLineDialog(mActivity);
                }
            }
        };
    }
}
