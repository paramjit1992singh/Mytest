package com.superpak.sammengistu.stuckapp;

import com.superpak.sammengistu.stuckapp.activities.StuckMainListActivity;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.NotificationCompat;


public class NotifyUser {

    /**
     * Builds a notification
     * Then sends a notification to the user
     * @param appContext - context needed to build the notification and get resources
     * @param message - message to display in notification
     */
    public static void notifyUset(Context appContext, String message) {
        // Creates an explicit intent for an ResultActivity to receive.
        Intent resultIntent = new Intent(appContext, StuckMainListActivity.class);

        PendingIntent resultPendingIntent = PendingIntent.getActivity(appContext,0,resultIntent,
            PendingIntent.FLAG_UPDATE_CURRENT);

        Bitmap icon = BitmapFactory.decodeResource(appContext.getResources(),
            R.mipmap.ic_launcher);

        // Create the final Notification object.
        Notification myNotification = new NotificationCompat.Builder(appContext)
            .setSmallIcon(R.drawable.stuck_small_icon_two)
            .setLargeIcon(icon)
            .setAutoCancel(true)
            .setContentIntent(resultPendingIntent)
            .setContentTitle(appContext.getResources().getString(R.string.app_name))
            .setContentText(message)
            .setDefaults(Notification.DEFAULT_ALL)
            .setTicker(message)
            .setWhen(System.currentTimeMillis())
            .addAction(R.drawable.stuck_small_icon_two,
                appContext.getString(R.string.start_app), resultPendingIntent).build();

        NotificationManager notificationManager = (NotificationManager)
            appContext.getSystemService(appContext.NOTIFICATION_SERVICE);

        notificationManager.notify(0, myNotification);
    }
}
