package com.superpak.sammengistu.stuckapp.stuck_offline_db;

import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;

import android.content.ContentValues;


public class StuckDBConverter {

    /**
     * Converts a movie into a ContentValues Object
     */
    public static ContentValues insertStuckPostToDB(StuckPostSimple stuckPostSimple, String mostRecentPost) {

        ContentValues contentValues = new ContentValues();
        contentValues.put(StuckConstants.COLUMN_EMAIL, stuckPostSimple.getEmail());
        contentValues.put(StuckConstants.COLUMN_QUESTION, stuckPostSimple.getQuestion());
        contentValues.put(StuckConstants.COLUMN_LOCATION, stuckPostSimple.getLocation());
        contentValues.put(StuckConstants.COLUMN_CHOICE_ONE, stuckPostSimple.getChoiceOne());
        contentValues.put(StuckConstants.COLUMN_CHOICE_TWO, stuckPostSimple.getChoiceTwo());
        contentValues.put(StuckConstants.COLUMN_CHOICE_THREE, stuckPostSimple.getChoiceThree());
        contentValues.put(StuckConstants.COLUMN_CHOICE_FOUR, stuckPostSimple.getChoiceFour());
        contentValues.put(StuckConstants.COLUMN_MOST_RECENT_POST, mostRecentPost);

        return contentValues;
    }

}
