package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.adapters.FilterListAdapter;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AccountSettingsActivity extends AppCompatActivity {

    private List<String> mAccountSettingsOption;

    @BindView(android.R.id.list)
    ListView mSettingsOptionLV;
    @BindView(R.id.accout_settings_toolbar)
    Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle onSavedInstantState) {
        super.onCreate(onSavedInstantState);
        setContentView(R.layout.activity_account_setting);
        ButterKnife.bind(this);

        setUpToolbar();

        mAccountSettingsOption = new ArrayList<>();

        mAccountSettingsOption.add(getString(R.string.update_email));
        mAccountSettingsOption.add(getString(R.string.change_password));
        mAccountSettingsOption.add(getString(R.string.delete_account));
        mAccountSettingsOption.add(getString(R.string.log_out));

        mSettingsOptionLV.setAdapter(new FilterListAdapter(mAccountSettingsOption, this));

        mSettingsOptionLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                handleOnClick(position);
            }
        });
    }


    @SuppressWarnings("deprecation")
    private void setUpToolbar() {
        setSupportActionBar(mToolbar);

        // Get a support ActionBar corresponding to this toolbar
        ActionBar ab = getSupportActionBar();

        if (ab != null) {
            final Drawable upArrow = getResources()
                .getDrawable(R.drawable.abc_ic_ab_back_mtrl_am_alpha);
            upArrow.setColorFilter(getResources().getColor(R.color.colorWhite),
                PorterDuff.Mode.SRC_ATOP);

            // Enable the Up button
            ab.setDisplayHomeAsUpEnabled(true);

            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setHomeAsUpIndicator(upArrow);
        }
    }

    /**
     * Handles the lists on click event based on the clicked position
     *
     * @param position - list item clicked position
     */
    private void handleOnClick(int position) {
        switch (position) {
            case 0:
                Intent updateEmailIntent = new Intent(this, UpdateEmailActivity.class);
                startActivity(updateEmailIntent);
                break;

            case 1:
                Intent intent = new Intent(this, StuckResetPasswordActivity.class);
                startActivity(intent);
                break;

            case 2:
                new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.delete_account_dialog_title))
                    .setMessage(getString(R.string.delete_account_dialog_message))
                    .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            if (user != null) {
                                if (user != null) {
                                    String userEncodedEmail = StuckSignUpActivity.encodeEmail(user.getEmail());

                                    deleteAccount(user, userEncodedEmail);
                                }
                            } else {
                                Toast.makeText(AccountSettingsActivity.this,
                                    R.string.error_please_try_again, Toast.LENGTH_LONG).show();
                                StuckMainListActivity.takeUserToLoginScreen(
                                    AccountSettingsActivity.this);
                            }
                        }
                    })
                    .setNegativeButton(getString(R.string.no_thanks), null)
                    .show();
                break;

            case 3:
                FirebaseAuth.getInstance().signOut();
                StuckMainListActivity.takeUserToLoginScreen(
                    AccountSettingsActivity.this);
                break;
        }
    }

    /**
     * Deletes the users account from Auth
     * Deletes users saved votes
     * Deletes users account off the database
     * @param user             - used to delete user
     * @param userEncodedEmail - to delete votes and account info from db
     */
    private void deleteAccount(final FirebaseUser user, final String userEncodedEmail) {

        new AlertDialog.Builder(this)
            .setTitle("Delete Account")
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //Delete user votes
                    DatabaseReference userVoteRef = FirebaseDatabase.getInstance().getReference()
                        .child(StuckConstants.FIREBASE_URL_USERS_VOTES)
                        .child(userEncodedEmail);

                    //delete user account from db
                    DatabaseReference userRef = FirebaseDatabase.getInstance().getReference()
                        .child(StuckConstants.FIREBASE_URL_USERS)
                        .child(userEncodedEmail);

                    DatabaseReference usersFav = FirebaseDatabase.getInstance().getReference()
                        .child(StuckConstants.FIREBASE_STARRED_POST)
                        .child(userEncodedEmail);

                    usersFav.removeValue();
                    userVoteRef.removeValue();
                    userRef.removeValue();

                    deleteAllUsersStuckPosts(userEncodedEmail);

                    // Delete user auth
                    user.delete()
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {

                                    StuckMainListActivity
                                        .takeUserToLoginScreen(AccountSettingsActivity.this);

                                    Toast.makeText(AccountSettingsActivity.this,
                                        R.string.account_was_deleted,
                                        Toast.LENGTH_LONG).show();

                                } else {
                                    UpdateEmailActivity
                                        .showErrorResettingAlertDialog(AccountSettingsActivity.this, "");
                                }
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                            }
                        });
                }
            }).show();
    }

    /**
     * Deletes users posts by first querying all their posts and using the ref to remove values
     *
     * @param encodedEmail - email to delete all posts
     */
    private void deleteAllUsersStuckPosts(String encodedEmail) {

        Query queryRef = FirebaseDatabase.getInstance().getReference()
            .child(StuckConstants.FIREBASE_URL_ACTIVE_POSTS)
            .orderByChild(StuckConstants.FIREBASE_EMAIL)
            .equalTo(encodedEmail);

        final List<DatabaseReference> userPosts = new ArrayList<>();

        queryRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot stuckSnap : dataSnapshot.getChildren()) {

                    StuckPostSimple stuckPostSimple =
                        stuckSnap.getValue(StuckPostSimple.class);

                    stuckPostSimple.setDatabaseReference(stuckSnap.getRef());

                    userPosts.add(stuckSnap.getRef());
                }

                for (DatabaseReference userPostRef : userPosts) {
                    userPostRef.removeValue();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
