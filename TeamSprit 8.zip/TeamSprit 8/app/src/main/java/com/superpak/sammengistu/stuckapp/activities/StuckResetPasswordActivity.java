package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;

public class StuckResetPasswordActivity extends AppCompatActivity {

    @BindView(R.id.password_edit_text)
    EditText mPasswordED;
    @BindView(R.id.reenter_password_edit_text)
    EditText mReenterED;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.update_email_cancel)
    TextView mCancelResetPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stuck_reset_password);
        ButterKnife.bind(this);

        setUpToolBar();

        mPasswordED.setHint(R.string.new_password);

        mCancelResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StuckResetPasswordActivity.this, AccountSettingsActivity.class);
                startActivity(intent);
            }
        });

        Button resetButton = (Button) findViewById(R.id.reset_password_button);

        assert resetButton != null;
        resetButton.setOnClickListener(mResetPasswordOnClickLis);
    }

    private void setUpToolBar() {
        mToolbar.inflateMenu(R.menu.menu_main);

        setSupportActionBar(mToolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    View.OnClickListener mResetPasswordOnClickLis = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (mPasswordED.getText().toString().equals(mReenterED.getText().toString()) &&
                mPasswordED.getText().toString().length() >= 5) {

                final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                String newPassword = mReenterED.getText().toString();

                if (user != null) {

                    if (user.getProviders().get(0).equals(StuckConstants.PASSWORD_PROVIDER)) {
                        user.updatePassword(newPassword)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {

                                        Toast.makeText(StuckResetPasswordActivity.this,
                                            R.string.password_has_been_reset, Toast.LENGTH_LONG).show();

                                        FirebaseAuth.getInstance().signOut();
                                        Intent intent = new Intent(StuckResetPasswordActivity.this,
                                            StuckLoginActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(intent);

                                    } else {
                                        UpdateEmailActivity.showErrorResettingAlertDialog(
                                            StuckResetPasswordActivity.this,
                                            getString(R.string.password_not_complex_enough));
                                    }
                                }
                            });
                    } else {
                        new AlertDialog.Builder(StuckResetPasswordActivity.this)
                            .setPositiveButton(getString(R.string.cancel), null)
                            .setTitle(getString(R.string.error))
                            .setMessage(getString(R.string.signed_in_with_google_cant_reset_password))
                            .show();
                    }
                }
            } else {
                Toast.makeText(StuckResetPasswordActivity.this,
                    R.string.password_doesnt_match_or_isnt_long_enough, Toast.LENGTH_LONG).show();
            }
        }
    };
}
