package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ServerValue;

import com.superpak.sammengistu.stuckapp.GeneralArea;
import com.superpak.sammengistu.stuckapp.R;
import com.superpak.sammengistu.stuckapp.StuckConstants;
import com.superpak.sammengistu.stuckapp.adapters.MyPostChoiceAdapter;
import com.superpak.sammengistu.stuckapp.async_task.SaveToDBTask;
import com.superpak.sammengistu.stuckapp.model.Choice;
import com.superpak.sammengistu.stuckapp.model.StuckPostSimple;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.transition.Explode;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class StuckNewPostActivity extends AppCompatActivity implements
    GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    private RecyclerView.Adapter mAdapter;
    private List<Choice> mChoicesList;
    private String mEmail;
    private GoogleApiClient mGoogleApiClient;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseAuth mAuth;
    private Location mLastLocation;

    @BindView(R.id.my_post_edit_text)
    EditText mQuestionEditText;
    @BindView(R.id.recycler_view_single_choice_view)
    RecyclerView mMyChoicesRecyclerView;
    @BindView(R.id.add_choice_button)
    FloatingActionButton mAddChoiceButton;
    @BindView(R.id.new_post_done)
    TextView mNewPostDone;
    @BindView(R.id.new_stuck_post_toolbar)
    Toolbar mNewPostToolbar;
    @BindView(R.id.spinnerProgress)
    LinearLayout mLinearLayoutSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindowAnimations();
        setContentView(R.layout.activity_new_stuck_post);
        ButterKnife.bind(this);

        setUpToolbar();
        mLinearLayoutSpinner.setVisibility(View.GONE);

        mAuth = FirebaseAuth.getInstance();

        SharedPreferences pref = getApplicationContext()
            .getSharedPreferences(StuckConstants.SHARED_PREFRENCE_USER, 0); // 0 - for private mode
        mEmail = pref.getString(StuckConstants.KEY_ENCODED_EMAIL, "");

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                 /* The user has been logged out */
                if (firebaseAuth == null) {
                    StuckMainListActivity.takeUserToLoginScreen(StuckNewPostActivity.this);
                }
            }
        };

        showHelpDialog(pref);

        mGoogleApiClient = new GoogleApiClient.Builder(this)
            .addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .addApi(LocationServices.API)
            .build();

        mGoogleApiClient.connect();

        mMyChoicesRecyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mMyChoicesRecyclerView.setLayoutManager(layoutManager);

        mChoicesList = new ArrayList<>();

        //User needs at least two choices
        mChoicesList.add(new Choice("", 0));
        mChoicesList.add(new Choice("", 0));

        // specify an adapter (see also next example)
        mAdapter = new MyPostChoiceAdapter(mChoicesList, this, mAddChoiceButton, mMyChoicesRecyclerView);
        mMyChoicesRecyclerView.setAdapter(mAdapter);

    }

    private void showHelpDialog(final SharedPreferences pref) {
        if (pref.getBoolean(StuckConstants.SHOW_USER_HOW_USE_NEW_POST_DIALOG, true)) {
            new AlertDialog.Builder(this).setTitle(getString(R.string.how_to_use))
                .setMessage(getString(com.superpak.sammengistu.stuckapp.R.string.how_to_use_new_post))
                .setPositiveButton(getString(R.string.got_it), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SharedPreferences.Editor editor = pref.edit();
                        editor.putBoolean(StuckConstants.SHOW_USER_HOW_USE_NEW_POST_DIALOG, false);
                        editor.apply();

                    }
                }).show();
        }
    }

    @SuppressWarnings("deprecation")
    private void setUpToolbar() {

        setSupportActionBar(mNewPostToolbar);

        // Get a support ActionBar corresponding to this toolbar
        ActionBar ab = getSupportActionBar();

        if (ab != null) {
            final Drawable upArrow = getResources().getDrawable(R.drawable.abc_ic_ab_back_mtrl_am_alpha);
            upArrow.setColorFilter(getResources().getColor(R.color.colorWhite), PorterDuff.Mode.SRC_ATOP);

            // Enable the Up button
            ab.setDisplayHomeAsUpEnabled(true);

            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setHomeAsUpIndicator(upArrow);
        }
    }

    private boolean isQuestionFilled() {
        return !mQuestionEditText.getText().toString().equals("") ||
            !mQuestionEditText.getText().toString().equals(" ");
    }

    private boolean isAllChoicesFilled() {
        for (Choice choice : mChoicesList) {
            if (choice.getChoice().equals("") ||
                choice.getChoice().equals(" ")) {
                return false;
            }
        }
        return true;
    }

    private void alertUserItemMissing() {
        AlertDialog.Builder fillEveryThingDialog = new AlertDialog.Builder(StuckNewPostActivity.this);
        fillEveryThingDialog.setTitle(getString(R.string.one_or_more_cards_are_empty));
        fillEveryThingDialog.setMessage(getString(R.string.please_fill_all_boxes));
        fillEveryThingDialog.show();
        fillEveryThingDialog.setCancelable(true);
    }

    /**
     * Uses location service to see whether location is on
     * @return - is the location on
     */
    private boolean isLocationOn() {
        LocationManager lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;

        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
        }

        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ex) {
        }

        return gps_enabled && network_enabled;
    }

    /**
     * Creates a stuck post based on users input, gets the general location of the user, and the
     * timethe post was created
     */
    private void createPost() {

        mLinearLayoutSpinner.setVisibility(View.VISIBLE);

        if (isLocationOn()) {
            mNewPostDone.setEnabled(false);

            /**
             * Set raw version of date to the ServerValue.TIMESTAMP value and save into
             * timestampCreatedMap
             */
            HashMap<String, Object> timestampCreated = new HashMap<>();
            timestampCreated.put(StuckConstants.FIREBASE_PROPERTY_TIMESTAMP, ServerValue.TIMESTAMP);

            StuckPostSimple stuckPost = new StuckPostSimple(
                StuckSignUpActivity.encodeEmail(mEmail),
                mQuestionEditText.getText().toString(),
                GeneralArea.getAddressOfCurrentLocation(mLastLocation, this),
                mChoicesList.get(0).getChoice(),
                mChoicesList.get(1).getChoice(),
                (mChoicesList.size() == 3 || mChoicesList.size() == 4 ?
                    mChoicesList.get(2).getChoice() : ""),
                (mChoicesList.size() == 4 ? mChoicesList.get(3).getChoice() : ""),
                StuckConstants.ZERO_VOTES, StuckConstants.ZERO_VOTES,
                StuckConstants.ZERO_VOTES, StuckConstants.ZERO_VOTES,
                timestampCreated,
                //Later helps put in proper date order
                (-1 * new Date().getTime()));
            new SaveToDBTask(stuckPost, this, mLinearLayoutSpinner).execute();
        } else {
            mLinearLayoutSpinner.setVisibility(View.INVISIBLE);
            showErrorLocationDialog(this);
        }
    }

    public static void showErrorLocationDialog(Activity activity) {
        new AlertDialog.Builder(activity)
            .setTitle(activity.getString(R.string.location))
            .setMessage(activity.getString(R.string.turn_on_location_message))
            .setPositiveButton(android.R.string.ok, null)
            .show();
    }

    private void setupWindowAnimations() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // inside your activity (if you did not enable transitions in your theme)
            getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);

            Explode explode = new Explode();
            explode.setDuration(400);

            getWindow().setEnterTransition(explode);

            // set an exit transition
            getWindow().setExitTransition(new Explode());
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @OnClick(R.id.add_choice_button)
    public void setAddChoiceButton() {

        mChoicesList.add(new Choice("", 0));

        // specify an adapter (see also next example)
        mAdapter = new MyPostChoiceAdapter(mChoicesList, this, mAddChoiceButton, mMyChoicesRecyclerView);
        mMyChoicesRecyclerView.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();

        if (mChoicesList.size() == 4) {
            mAddChoiceButton.setVisibility(View.INVISIBLE);
            mAddChoiceButton.setEnabled(false);
        }
    }

    @OnClick(R.id.new_post_done)
    public void setNewPostDone() {

        if (isQuestionFilled() && isAllChoicesFilled()) {

            createPost();
        } else {
            alertUserItemMissing();
        }
    }


    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
            mGoogleApiClient);
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
