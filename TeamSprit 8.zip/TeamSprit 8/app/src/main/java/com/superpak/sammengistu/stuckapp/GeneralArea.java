package com.superpak.sammengistu.stuckapp;

import android.content.Context;
import android.location.Geocoder;
import android.location.Location;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Gets the users general area
 */
public class GeneralArea {

    public static String getAddressOfCurrentLocation(Location location, Context context) {

        double longitude;
        double latitude;

        if(location != null){
            longitude = location.getLongitude();
            latitude = location.getLatitude();
        }else{
            latitude=22.572645;
            longitude=88.363892;

        }

        String currentLocationAddress = "";


        //Builder to get only the city and state of the user
        StringBuilder builder = new StringBuilder();
        try {
            List<android.location.Address> address =
                new Geocoder(context, Locale.getDefault()).getFromLocation(latitude, longitude, 1);

            if (address.get(0).getLocality() != null){
                builder.append(address.get(0).getLocality());
                builder.append(", ");
            }

            if (address.get(0).getAdminArea() != null) {
                builder.append(address.get(0).getAdminArea());
            }
            currentLocationAddress = builder.toString(); //This is the complete address.
        } catch (IOException e) {
        } catch (NullPointerException e) {
        }

        return currentLocationAddress;
    }
}
