package com.superpak.sammengistu.stuckapp.activities;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

import com.superpak.sammengistu.stuckapp.NetworkStatus;
import com.superpak.sammengistu.stuckapp.R;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ForgotPasswordActivity extends AppCompatActivity {

    private ProgressDialog dialog;

    @BindView(R.id.forgot_pass_email_edit_text)
    EditText mEmailEditText;
    @BindView(R.id.send_temp_button)
    Button mSendTempEmailButton;
    @BindView(R.id.forgot_password_sign_up_account)
    TextView mSignUpButton;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle onSavedInstanceState){
        super.onCreate(onSavedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        ButterKnife.bind(this);

        setUpToolbar();

        dialog = new ProgressDialog(this);
        dialog.setTitle(getString(R.string.send_reset_email));

        if (NetworkStatus.isOnline(this)) {
            if (StuckSignUpActivity.validEmail(mEmailEditText.getText().toString())) {

                resetPassword();
            }
        } else {
            dialog.dismiss();
            NetworkStatus.showOffLineDialog(this);
        }

        mSignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(ForgotPasswordActivity.this, StuckSignUpActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        mSendTempEmailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
                resetPassword();
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void setUpToolbar() {
        setSupportActionBar(mToolbar);

        // Get a support ActionBar corresponding to this toolbar
        ActionBar ab = getSupportActionBar();

        if (ab != null) {
            final Drawable upArrow = getResources()
                .getDrawable(R.drawable.abc_ic_ab_back_mtrl_am_alpha);
            upArrow.setColorFilter(getResources().getColor(R.color.colorWhite),
                PorterDuff.Mode.SRC_ATOP);

            // Enable the Up button
            ab.setDisplayHomeAsUpEnabled(true);

            getSupportActionBar().setDisplayShowTitleEnabled(false);
            getSupportActionBar().setHomeAsUpIndicator(upArrow);

        }
    }

    /**
     * Sends a reset password email to the user
     */
    private void resetPassword() {
        String email = mEmailEditText.getText().toString();

        FirebaseAuth auth = FirebaseAuth.getInstance();

        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    dialog.dismiss();
                    if (task.isSuccessful()) {
                        Toast.makeText(ForgotPasswordActivity.this, R.string.sent_password_reset_email,
                            Toast.LENGTH_LONG).show();
                        FirebaseAuth.getInstance().signOut();
                      StuckMainListActivity.takeUserToLoginScreen(ForgotPasswordActivity.this);
                    }
                }
            })
            .addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                     dialog.dismiss();
                    new AlertDialog.Builder(ForgotPasswordActivity.this)
                        .setTitle(getString(R.string.error_sending_password_reset_email))
                        .setMessage(getString(R.string.forgot_password_error))
                        .show();
                }
            });
    }

    @Override
    protected void onStop(){
        super.onStop();
        FirebaseAuth.getInstance().signOut();
    }
}
