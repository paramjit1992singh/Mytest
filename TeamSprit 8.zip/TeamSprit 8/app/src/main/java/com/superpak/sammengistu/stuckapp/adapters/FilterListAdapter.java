package com.superpak.sammengistu.stuckapp.adapters;

import com.superpak.sammengistu.stuckapp.R;

import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;


public class FilterListAdapter extends ArrayAdapter<String> {

    private List<String> mFilteredListItems;
    private Activity mMainListActivity;

    public FilterListAdapter(List<String> filterItems, Activity activity) {
        super(activity, 0, filterItems);
        mMainListActivity = activity;
        mFilteredListItems = filterItems;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {

            LayoutInflater inflater = mMainListActivity.getLayoutInflater();
            convertView = inflater.inflate(R.layout.filtered_list_item, parent, false);
        }

        TextView filteredItemText = (TextView) convertView.findViewById(R.id.filtered_list_item_text);
        filteredItemText.setText(mFilteredListItems.get(position));
        filteredItemText.setTextColor(Color.BLACK);

        return convertView;
    }
}
