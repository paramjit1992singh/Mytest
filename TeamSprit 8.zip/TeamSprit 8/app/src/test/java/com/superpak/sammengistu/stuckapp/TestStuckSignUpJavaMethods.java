package com.superpak.sammengistu.stuckapp;

import com.superpak.sammengistu.stuckapp.activities.StuckSignUpActivity;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class TestStuckSignUpJavaMethods {


    /*
    Testing encoded email method
     */

    @Test
    public void testEncodedEmail() throws Exception {

        String email = "John@gmail.com";

        String encodedEmail = StuckSignUpActivity.encodeEmail(email);

        assertEquals("John@gmail,com", encodedEmail);
    }

    @Test
    public void testEncodedEmailSame() throws Exception {
        String email = "Johns@gmail,com";

        String encodedEmail = StuckSignUpActivity.encodeEmail(email);

        assertEquals(email, encodedEmail);
    }

    @Test
    public void testEncodedEmailPassNull() throws Exception {

        String encodedEmail = StuckSignUpActivity.encodeEmail(null);

        assertEquals(encodedEmail, "");
    }

    @Test
    public void testEncodedEmailNonEmailFormat() throws Exception {
        String email = "Johnksdnfl;sanfer.nkgarlkdsm";

        String encodedEmail = StuckSignUpActivity.encodeEmail(email);

        assertEquals("Johnksdnfl;sanfer,nkgarlkdsm", encodedEmail);
    }

    /*
    Testing valid email method
     */

    @Test
    public void testValidEmailWithValidEmail() throws Exception {
        String validEmail = "John@gmail.com";

        assertTrue(StuckSignUpActivity.validEmail(validEmail));
    }

    @Test
    public void testValidEmailWithInvalidEmail() throws Exception {
        String validEmail = "Johngmail.com";

        assertFalse(StuckSignUpActivity.validEmail(validEmail));
    }

    @Test
    public void testValidEmailWithNull() throws Exception {

        assertFalse(StuckSignUpActivity.validEmail(null));
    }

    /*
    Testing password match method
     */

    @Test
    public void testPasswordMatch() throws Exception {
        String password1 = "123456";
        String password2 = "123456";

        assertTrue(password1.equals(password2));
    }

    @Test
    public void testPasswordsDonNotMatch() throws Exception {
        String password1 = "123456";
        String password2 = "12356";

        assertFalse(StuckSignUpActivity.passwordsMatch(password1, password2));
    }

    @Test
    public void testPasswordsDonNotMatchNull() throws Exception {
        String password1 = "123456";
        String password2 = null;

        assertFalse(StuckSignUpActivity.passwordsMatch(password1, password2));
    }

    @Test
    public void testPasswordsDonNotMatchNulls() throws Exception {
        String password1 = null;
        String password2 = null;

        assertFalse(StuckSignUpActivity.passwordsMatch(password1,password2));
    }

    @Test
    public void testPasswordsDonNotMatchFirstNull() throws Exception {
        String password1 = null;
        String password2 = "dasfsaf";

        assertFalse(StuckSignUpActivity.passwordsMatch(password1, password2));
    }
}