package com.superpak.sammengistu.stuckapp;

import com.superpak.sammengistu.stuckapp.dialogs.FilterDialog;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestFilterDialogJava {

    @Test
    public void testDoesItContainSingleCharacter() throws Exception {
        FilterDialog filterDialog = new FilterDialog();

        String typedInLocation = "g";
        String location = "Silver Spring, Maryland";

        assertTrue(filterDialog.doesItContainWord(location, typedInLocation));
    }

    @Test
    public void testDoesItContainWordCityName() throws Exception {
        FilterDialog filterDialog = new FilterDialog();

        String typedInLocation = "Silver Spring";
        String location = "Silver Spring, Maryland";

        assertTrue(filterDialog.doesItContainWord(location, typedInLocation));
    }

    @Test
    public void testDoesItContainWordStateName() throws Exception {
        FilterDialog filterDialog = new FilterDialog();

        String typedInLocation = "Maryland";
        String location = "Silver Spring, Maryland";

        assertTrue(filterDialog.doesItContainWord(location, typedInLocation));
    }

    @Test
    public void testDoesItNotContainWord() throws Exception {
        FilterDialog filterDialog = new FilterDialog();

        String typedInLocation = "zebra";
        String location = "Silver Spring, Maryland";

        assertFalse(filterDialog.doesItContainWord(location, typedInLocation));
    }

    @Test
    public void testDoesItNotContainNull() throws Exception {
        FilterDialog filterDialog = new FilterDialog();

        String location = "Silver Spring, Maryland";

        assertFalse(filterDialog.doesItContainWord(location, null));
    }

    @Test
    public void testDoesItContainInNull () throws Exception {
        FilterDialog filterDialog = new FilterDialog();

        String typedInLocation = "zebra";

        assertFalse(filterDialog.doesItContainWord(null, typedInLocation));
    }
}
