# Stuck-App
Ever get stuck making a decision, or are you just curious about what others think about something, or just want to collect personal data for yourself. With Stuck, you can make an anonymous post with choices and have it available to other Stuck users so they can start voting on your choices. See votes live as they are being made from other users. With Stuck, you can get unstuck.

I had to recreate this project when firebase upgraded their system because when I was using the new code in firebase library
I kept running into issues. Someone I found on stackoverflow suggested that they recreated their project and that solved the
issues for them. I did the same and that solved my issues so here is the link to my previous project before recreating it
https://github.com/sam321pbs/Stuck
