// Code goes here

var app = angular.module("webapp", ["ui.router"]);

app.config(function($urlRouterProvider, $stateProvider){

  $urlRouterProvider.
        when('','view1')
    $stateProvider
        .state('view1',{
            template:'<h1>View1</h1>'
        })
        .state('view2',{
            template:'<h1>View2</h1>'
        })
})


app.controller("NavController", function ($scope, $state) {
     var arrayViews=['view1','view2'];
     var index=0;
    $scope.forward=function(){
        if(index<arrayViews.length-1){
            index=index+1
            $state.go(arrayViews[index]);
        }else{
          index=0
            $state.go(arrayViews[index]);
        }
    };
    $scope.backward=function(){
        if(index>0){
            index=index-1;
            $state.go(arrayViews[index]);
        }else{
            index=arrayViews.length-1;//
            $state.go(arrayViews[index]);
        }
    }

});
