A Pen created at CodePen.io. You can find this one at http://codepen.io/hayatbiralem/pen/KpzjOL.

 A different approach for responsive bootstrap tabs.