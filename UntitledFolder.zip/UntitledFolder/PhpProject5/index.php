
<?php
$conn = mysql_connect("localhost", "root", "");
$db = mysql_select_db("testdb", $conn);

$sql_project = "SELECT project_Id FROM `Allocation` WHERE CID='google'";
$result_project = mysql_query($sql_project);
//echo $result_project;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>project List</title>
        <style>
            th,td{border: 1px solid gray;padding:5px;}
            .tabs{
                margin: 0 auto;
                
            }
            .tab{
                width:100px;
                height: 100px;
                border: 1px solid  red;
            }
            
            .floatLeft{
                float: left;
                
            }
            .clear{
                
               clear: both; 
            }
        </style>
    </head>
    <body>
        <div class="tabs">
            <div class="tab floatLeft" target="1">Risk</div>
            <div class="tab floatLeft" target="2">Issue</div>
            <div class="tab floatLeft" target="3">Action</div>
            <!--<div class="tab floatLeft" target="4">Direction</div>-->
            <div class="clear"></div>
        
        
        
        
        <?php
        
        echo "<select name='project' class='project'><option id='0' value='0'>Select Projects</option>";
        //$var=0;
        while ($row_project = mysql_fetch_array($result_project)) {
            echo "<option value='" . $row_project['project_Id']  . "'>" . $row_project['project_Id'] . "</option>";
          //  $var++;
        }
        echo "</select>";
        
        echo '<div class="project_information">Project Info</div><br>'
        . '<div class="project_info"></div>';
        ?>
            </div>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script type="text/javascript">
            //function get_projects($id) {
            var target=0;
            $(".tab").click(function (){
                target=$(this).attr("target");
                //alert("target: "+target);
                $('.project').val(0);
                $(".projectInfo").hide();
            });

            $('.project').change(function () {
                var selectedProject = $('.project').val();
                if(selectedProject!=0){
                $.ajax({type:"post",url: "projectData.php",data:"target="+target+"&id="+selectedProject,cache: false, success: function (result) {
                        $('.project_info').html(result);
                        $(".projectInfo").show();
                    }});
            }else{
                
                $(".projectInfo").hide();
            }
            });




            //}
            
        </script>
    </body>
</html>