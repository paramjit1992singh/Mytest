
<?php

$conn = mysql_connect("localhost", "root", "");
$db = mysql_select_db("testdb", $conn);

$id = $_POST['id'];
$target=$_POST["target"];
if($target==0 || $target==1 ){
    $sql= "SELECT * FROM `Risk` WHERE project_Id='".$id."'";
}else if ($target==2) {
    $sql= "SELECT * FROM `Issue` WHERE project_Id='".$id."'";
}else if ($target==3) {
    $sql= "SELECT * FROM `Action` WHERE project_Id='".$id."'";
}/*elseif ($target=4) {
    $sql= "SELECT * FROM `Direction` WHERE project_Id='".$id."'";
}*/

//$result_city = mysql_result(mysql_query($sql_city),0);

$result = mysql_query($sql) or die(mysql_error());

//echo '<div>'.  $result_city.'</div>';


echo "<table class='projectInfo'><tr>";
for($i = 0; $i < mysql_num_fields($result); $i++) {
    $field_info = mysql_fetch_field($result, $i);
    echo "<th>{$field_info->name}</th>";
}

// Print the data
while($row = mysql_fetch_row($result)) {
    echo "<tr>";
    foreach($row as $_column) {
        echo "<td>{$_column}</td>";
    }
    echo "</tr>";
}

echo "</table>";



?>