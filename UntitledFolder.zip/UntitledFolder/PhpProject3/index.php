
<?php
$conn = mysql_connect("localhost", "root", "");
$db = mysql_select_db("project_example", $conn);

$sql_project = "SELECT * FROM projects";
$result_project = mysql_query($sql_project);
?>
<!DOCTYPE html>
<html>
    <head>
        <title>project List</title>
    </head>
    <body>
        <?php
        echo "<select name='project' class='project'>";

        while ($row_project = mysql_fetch_array($result_project)) {
            echo "<option value='" . $row_project['id'] . "'>" . $row_project['project'] . "</option>";
        }
        echo "</select>";
        
        echo '<div class="project_information">Project Info</div><br>'
        . '<div class="project_info"></div>';
        ?>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script type="text/javascript">
            //function get_projects($id) {

            $('.project').change(function () {
                var CityNo = $('.project').val();
                $.ajax({url: "City.php?id=" + CityNo, cache: false, success: function (result) {
                        $('.project_info').html(result);
                    }});
            });




            //}
        </script>
    </body>
</html>