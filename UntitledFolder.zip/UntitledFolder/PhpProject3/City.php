
<?php

$conn = mysql_connect("localhost", "root", "");
$db = mysql_select_db("project_example", $conn);

$id = $_REQUEST['id'];
$sql_city = "SELECT project_info FROM projects WHERE id = '".$id."'";
$result_city = mysql_result(mysql_query($sql_city),0);

echo '<div>'.  $result_city.'</div>';

/*
echo "<select name='city'>";
while($row_city = mysql_fetch_array($result_city))
{
    echo "<option value='".$row_city['id']."'>".$row_city['project']."</option>";
}
echo "</select>";*/
?>